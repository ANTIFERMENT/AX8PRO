#!/usr/bin/env python3
"""Sign AX 8 PRO using permanent GitHub Actions secret, validate certificate pin."""
import os,base64,zipfile,io,json,subprocess,tempfile,re,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
secret=os.environ.get('AX8PRO_SIGNING_BUNDLE','').strip()
if not secret: raise SystemExit('Missing Actions secret AX8PRO_SIGNING_BUNDLE')
with zipfile.ZipFile(io.BytesIO(base64.b64decode(secret,validate=True))) as a:
    cfg=json.loads(a.read('signing.json'))
    key=a.read('ax8pro-release.p12')
apks=list((ROOT/'app/build/outputs/apk/release').glob('*.apk'))
if len(apks)!=1:raise SystemExit('Expected one release APK, got '+str(len(apks)))
sdk=Path(os.environ['ANDROID_SDK_ROOT'])/'build-tools'/'36.0.0'
dist=ROOT/'dist';dist.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='ax8pro-sign-') as tmp:
    d=Path(tmp);keystore=d/'release.p12';keystore.write_bytes(key);keystore.chmod(0o600)
    cert=d/'cert.der';env=os.environ.copy();env['KS_PASS']=cfg['keystore_password'];env['KEY_PASS']=cfg['key_password']
    subprocess.run(['keytool','-exportcert','-alias',cfg['alias'],'-keystore',str(keystore),'-storetype','PKCS12','-storepass:env','KS_PASS','-file',str(cert)],env=env,check=True)
    actual=hashlib.sha256(cert.read_bytes()).hexdigest().upper()
    code=(ROOT/'app/src/main/java/ru/xarkon/ax8/UpdateManager.java').read_text()
    match=re.search(r'TRUSTED_CERT_SHA256="([0-9A-F]{64})"',code)
    if not match or actual!=match.group(1) or actual!=cfg['certificate_sha256'].upper():raise SystemExit('Signer is not pinned official AX8PRO identity')
    aligned=d/'aligned.apk'
    subprocess.run([str(sdk/'zipalign'),'-f','-p','4',str(apks[0]),str(aligned)],check=True)
    signed=dist/'AX8PRO.apk'
    subprocess.run([str(sdk/'apksigner'),'sign','--ks',str(keystore),'--ks-type','PKCS12','--ks-key-alias',cfg['alias'],'--ks-pass','env:KS_PASS','--key-pass','env:KEY_PASS','--out',str(signed),str(aligned)],env=env,check=True)
    subprocess.run([str(sdk/'apksigner'),'verify','--verbose','--print-certs',str(signed)],check=True)
print('AX8PRO signed with certificate',actual)
