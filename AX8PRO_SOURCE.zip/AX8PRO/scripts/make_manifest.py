#!/usr/bin/env python3
"""Generate immutable version-specific metadata for the signed release."""
import re,json,hashlib,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1]
apk=root/'dist'/'AX8PRO.apk'
if not apk.exists():raise SystemExit('Missing signed dist/AX8PRO.apk')
import os
badging=subprocess.check_output([str(Path(os.environ['ANDROID_SDK_ROOT'])/'build-tools/36.0.0/aapt'),'dump','badging',str(apk)],text=True)
m=re.search(r"^package: name='([^']+)' versionCode='([0-9]+)' versionName='([^']+)'",badging,re.M)
if not m or m.group(1)!='ru.xarkon.ax8pro':raise SystemExit('Wrong package or missing metadata')
package,code,version=m.groups()
if not re.fullmatch(r'[A-Za-z0-9_.-]+',version):raise SystemExit('Unsafe tag version')
tag='v'+version
manifest={'schema':1,'packageName':package,'versionCode':int(code),'versionName':version,
          'apkUrl':f'https://github.com/ANTIFERMENT/AX8PRO/releases/download/{tag}/AX8PRO.apk',
          'sha256':hashlib.sha256(apk.read_bytes()).hexdigest().upper(),
          'sizeBytes':apk.stat().st_size,'publishedAt':datetime.now(timezone.utc).isoformat(timespec='seconds'),
          'notes':f'AX 8 PRO {version}. Подробности в GitHub Releases.'}
(root/'dist/update.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
with open(os.environ['GITHUB_OUTPUT'],'a') as out:out.write('tag='+tag+'\nversion='+version+'\n')
print('OTA manifest ready:',tag,code)
