#!/usr/bin/env python3
"""Import one AX8PRO_SOURCE.zip under a single Gradle root. No path traversal."""
from pathlib import Path,PurePosixPath
import zipfile,sys
root=Path.cwd();src=root/'AX8PRO_SOURCE.zip'
if (root/'app/src/main/AndroidManifest.xml').exists():print('Native app checked in');sys.exit(0)
if not src.exists():raise SystemExit('Upload AX8PRO_SOURCE.zip to the root first')
with zipfile.ZipFile(src) as z:
  files=[i for i in z.infolist() if not i.is_dir()]
  names=[i.filename for i in files]
  roots=[n[:-len('settings.gradle')] for n in names if n.endswith('settings.gradle')]
  if not roots:raise SystemExit('settings.gradle missing')
  prefix=min(roots,key=len)
  total=0
  for entry in files:
    if not entry.filename.startswith(prefix):continue
    relative=entry.filename[len(prefix):]
    if not relative:continue
    p=PurePosixPath(relative)
    if p.is_absolute() or '..' in p.parts or '\\' in relative or ':' in relative or '\x00' in relative:
      raise SystemExit('Unsafe file name: '+relative)
    if relative.startswith(('.github/','scripts/','.git/','gradle/wrapper/gradle-wrapper.jar')) or relative.endswith(('.p12','.keystore','.jks','.pem','.key')):
      continue
    if relative.startswith(('.gradle/','app/build/','build/')) or '/build/' in relative or relative=='local.properties':continue
    if entry.file_size>80*1024*1024:raise SystemExit('Oversized file')
    total+=entry.file_size
    if total>140*1024*1024:raise SystemExit('Archive exceeds source size limit')
    target=root.joinpath(*p.parts)
    if target.exists():continue  # bootstrap scripts/workflows remain owned by GitHub
    target.parent.mkdir(parents=True,exist_ok=True)
    with z.open(entry) as f,target.open('wb') as out:
      while True:
        b=f.read(65536)
        if not b:break
        out.write(b)
if not (root/'app/src/main/AndroidManifest.xml').exists():raise SystemExit('Android source not extracted')
print('AX 8 PRO source imported')
