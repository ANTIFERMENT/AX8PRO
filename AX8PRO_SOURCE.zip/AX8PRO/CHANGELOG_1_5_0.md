# AX 8 PRO v1.5.0

- Переименование заголовка в «AX 8 PRO» и приложения в Android.
- Визуальное оформление QR LINK: темы, мятный акцент, расширенная палитра 24 оттенков, анимации и Ripple.
- OTA-клиент с безопасной проверкой APK, pinned signing certificate и манифестом GitHub Releases.
- GitHub Actions: импорт исходников, сборка, подпись, release APK, update.json.
- Отдельный `applicationId ru.xarkon.ax8pro` для официальной постоянной подписи.
- Основные функции контроля AX8 сохранены из v1.4.6.
