import javax.tools.*;
import com.sun.source.util.*;
import java.util.*;
/** Syntax check of Java source without Android SDK, using javac parser. */
public class Ax8ParseCheck {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) throw new IllegalArgumentException("Supply Java source file paths");
        JavaCompiler c=ToolProvider.getSystemJavaCompiler();
        if (c == null) throw new IllegalStateException("JDK (not JRE) required");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try (StandardJavaFileManager fm=c.getStandardFileManager(diagnostics,Locale.ROOT,null)) {
            JavacTask task=(JavacTask)c.getTask(null,fm,diagnostics,Arrays.asList("-proc:none","-source","17"),null,fm.getJavaFileObjectsFromStrings(Arrays.asList(args)));
            task.parse();
            boolean valid=true;
            for (Diagnostic<? extends JavaFileObject> d:diagnostics.getDiagnostics())
                if (d.getKind()==Diagnostic.Kind.ERROR) { System.err.println(d);valid=false; }
            if (!valid) System.exit(1);
            System.out.println("Syntax OK: "+args.length+" Java files");
        }
    }
}
