#!/data/data/com.termux/files/usr/bin/python
# AX8 Pro Control v33 - Dual-Stack QoS + Priority Monitor Fix + Full Customization
# OLAX AX8 Pro 4G / Sanechips WebUI
#
# Live TUI:
# - автообновление каждую секунду
# - управление клавишами без Enter
# - штатный SET_LOCK_LTE_BAND_MODE
# - ожидание LockBandSuc
# - штатный REBOOT_DEVICE после смены Band
# - [M] просмотр SMS напрямую через API роутера
# - счётчик SMS в главном меню: [M] SMS [N] и жёлтый [NEW] при непрочитанных
# - открытие непрочитанного SMS автоматически отмечает его прочитанным
# - очистка управляющих символов, ломающих штатный WebUI SMS
# - декодирование SMS из UTF-16BE HEX
# - удаление выбранного SMS с подтверждением
# - [D] удаление всех SMS из списка с подтверждением
# - [C] переподключение мобильной сети
# - [N] включение/выключение мобильной сети
# - [D] подключённые устройства: просмотр, блокировка, временный kick
# - per-device DL/UL через реальные IPv4/IPv6 счётчики Linux роутера
# - [L] dual-stack лимит скорости через tc HTB/u32 + ingress police
# - очистка всего списка блокировок
# - локальные длинные имена устройств без ограничения прошивки, привязка по MAC
# - [K] в списке устройств: временно отключить все клиентские устройства, кроме устройства управления
#
# В текущей версии:
# - [4] AUTO BAND: разрешены все поддерживаемые LTE bands, выбор сети оставлен модему
# - BW читается из native/alias полей и известных кодов AX8
# - автоматический вход в WebUI: root / admin
# - автоматический повторный вход при потере/истечении сессии
# - после reboot скрипт сам восстанавливает авторизацию

import base64
import http.cookiejar
import ipaddress
import hashlib
import json
import math
import os
import re
import select
import socket
import shutil
import sys
import termios
import textwrap
import time
import tty
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

BASE = "http://192.168.150.1"
GET_URL = BASE + "/goform/goform_get_cmd_process"
POST_URL = BASE + "/goform/goform_set_cmd_process"
REQ_GET_URL = BASE + "/reqproc/proc_get"
REQ_POST_URL = BASE + "/reqproc/proc_post"

ROUTER_USER = "root"
ROUTER_PASSWORD = "admin"

COOKIE_JAR = http.cookiejar.CookieJar()
HTTP = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(COOKIE_JAR))

SUPPORTED_BANDS = [1, 3, 7, 8, 20, 28, 38, 40, 41]
ALL_API_BANDS = [1, 2, 3, 4, 5, 7, 8, 17, 20, 28, 34, 38, 39, 40, 41, 66]

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Referer": BASE + "/index.html",
    "Origin": BASE,
    "X-Requested-With": "XMLHttpRequest",
}

RADIO_CMD = ",".join([
    "loginfo",
    "ppp_status",
    "network_provider",
    "network_type",
    "sub_network_type",

    "battery_pers",
    "battery_vol_percent",
    "battery_charging",

    "nv_band",
    "nv_bandwidth",
    "nv_arfcn",
    "nv_globecellid",
    "nv_enodbid",
    "nv_cellid",
    "nv_pci",
    "nv_rsrp",
    "nv_rsrq",
    "nv_sinr",

    "nv_rssi",
    "lte_rssi",
    "rssi",
    "wan_csq",
    "bandwidth",
    "lte_bandwidth",
    "lte_bw",
    "current_bandwidth",
    "CurrentBandwidth",
    "dl_bandwidth",
    "lte_dl_bandwidth",
    "nv_dl_bandwidth",

    "nv_rank",
    "nv_rank_index",
    "rank",
    "rank_index",
    "ri",
    "lte_ri",
    "lte_rank",

    "nv_txpower",
    "nv_tx_power",
    "txpower",
    "tx_power",
    "lte_txpower",
    "lte_tx_power",

    "nv_cqi",
    "nv_cqi0",
    "nv_cqi1",
    "cqi",
    "cqi0",
    "cqi1",
    "tb0_cqi",
    "tb1_cqi",
    "lte_cqi",
    "lte_cqi0",
    "lte_cqi1",

    "nv_ul_mcs",
    "ul_mcs",
    "lte_ul_mcs",
    "tb0_ul_mcs",
    "ul_mcs0",

    "nv_dl_mcs",
    "nv_dl_mcs0",
    "nv_dl_mcs1",
    "dl_mcs",
    "dl_mcs0",
    "dl_mcs1",
    "lte_dl_mcs",
    "lte_dl_mcs0",
    "lte_dl_mcs1",
    "tb0_dl_mcs",
    "tb1_dl_mcs",

    "wifi_access_sta_num",

    "realtime_rx_thrpt",
    "realtime_tx_thrpt",
    "realtime_rx_bytes",
    "realtime_tx_bytes",
])

# ANSI
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
ORANGE = "\033[38;5;208m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
WHITE = "\033[97m"
GRAY = "\033[90m"

CUSTOMIZATION_FILE = Path.home() / ".ax8_customization.json"

CUSTOM_DEFAULTS = {
    # Общий вид
    "title": "AX8 PRO",
    "accent": "cyan",
    "separator": "thin",
    "max_width": 78,
    "bold": True,
    "compact": False,

    # Главный экран
    "show_header_band": True,
    "show_header_battery": True,
    "show_header_connected": True,
    "show_signal": True,
    "show_cell": True,
    "show_speed": True,
    "show_updated": True,
    "signal_colors": True,
    "battery_colors": True,
    "battery_green_min": 50,
    "battery_yellow_min": 20,

    # Скорость
    "speed_kb_decimals": 1,
    "speed_mb_decimals": 2,

    # Устройства
    "show_device_ip": True,
    "show_device_mac": True,
    "show_device_time": True,
    "show_device_speed": True,
    "show_device_limit": True,
    "device_page_size": 5,

    # SMS / монитор
    "sms_page_size": 5,
    "priority_history_count": 5,

    # Частота обновления
    "main_refresh": 1.0,
    "device_refresh": 1.0,
    "sms_badge_refresh": 3.0,
}

CUSTOM = dict(CUSTOM_DEFAULTS)

_COLOR_CODES = {
    "cyan": "\033[96m",
    "blue": "\033[94m",
    "green": "\033[92m",
    "magenta": "\033[95m",
    "orange": "\033[38;5;208m",
    "yellow": "\033[93m",
    "white": "\033[97m",
}

_SEPARATOR_CHARS = {
    "thin": "─",
    "double": "═",
    "ascii": "-",
    "dots": "·",
}


def _validate_customization(data):
    out = dict(CUSTOM_DEFAULTS)
    if isinstance(data, dict):
        for key in out:
            if key in data:
                out[key] = data[key]

    out["title"] = str(out.get("title") or "AX8 PRO").strip()[:32] or "AX8 PRO"
    if out["accent"] not in _COLOR_CODES:
        out["accent"] = "cyan"
    if out["separator"] not in _SEPARATOR_CHARS:
        out["separator"] = "thin"

    try:
        w = int(out["max_width"])
    except Exception:
        w = 78
    out["max_width"] = 0 if w == 0 else max(52, min(w, 120))

    for key in (
        "bold", "compact",
        "show_header_band", "show_header_battery", "show_header_connected",
        "show_signal", "show_cell", "show_speed", "show_updated",
        "signal_colors", "battery_colors",
        "show_device_ip", "show_device_mac", "show_device_time",
        "show_device_speed", "show_device_limit",
    ):
        out[key] = bool(out.get(key))

    for key, default, lo, hi in (
        ("battery_green_min", 50, 1, 100),
        ("battery_yellow_min", 20, 0, 99),
        ("speed_kb_decimals", 1, 0, 3),
        ("speed_mb_decimals", 2, 0, 3),
        ("device_page_size", 5, 3, 9),
        ("sms_page_size", 5, 3, 9),
        ("priority_history_count", 5, 1, 8),
    ):
        try:
            value = int(out.get(key, default))
        except Exception:
            value = default
        out[key] = max(lo, min(value, hi))

    if out["battery_yellow_min"] >= out["battery_green_min"]:
        out["battery_yellow_min"] = max(0, out["battery_green_min"] - 10)

    for key, default, lo, hi in (
        ("main_refresh", 1.0, 0.5, 5.0),
        ("device_refresh", 1.0, 0.5, 5.0),
        ("sms_badge_refresh", 3.0, 1.0, 30.0),
    ):
        try:
            value = float(out.get(key, default))
        except Exception:
            value = default
        out[key] = max(lo, min(value, hi))

    return out


def _load_customization():
    try:
        raw = json.loads(CUSTOMIZATION_FILE.read_text(encoding="utf-8"))
    except Exception:
        raw = {}
    return _validate_customization(raw)


def _save_customization():
    global CUSTOM
    CUSTOM = _validate_customization(CUSTOM)
    CUSTOMIZATION_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = CUSTOMIZATION_FILE.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(CUSTOM, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    tmp.replace(CUSTOMIZATION_FILE)
    _apply_custom_runtime()


def _apply_custom_runtime():
    global CYAN
    CYAN = _COLOR_CODES.get(CUSTOM.get("accent"), "\033[96m")


CUSTOM = _load_customization()
_apply_custom_runtime()


def ui_title():
    return str(CUSTOM.get("title") or "AX8 PRO")


def ui_width():
    terminal = shutil.get_terminal_size((64, 24)).columns
    configured = int(CUSTOM.get("max_width", 78) or 0)
    if configured <= 0:
        return max(52, terminal)
    return max(52, min(terminal, configured))


def ui_line(width=None):
    if width is None:
        width = ui_width()
    char = _SEPARATOR_CHARS.get(CUSTOM.get("separator"), "─")
    return char * width


def ui_on(value):
    return "ВКЛ" if bool(value) else "ВЫКЛ"


def ui_bool_color(value):
    return GREEN if bool(value) else RED


def _cycle_setting(key, values):
    current = CUSTOM.get(key)
    try:
        idx = values.index(current)
    except ValueError:
        idx = -1
    CUSTOM[key] = values[(idx + 1) % len(values)]
    _save_customization()
    return CUSTOM[key]


def _toggle_setting(key):
    CUSTOM[key] = not bool(CUSTOM.get(key))
    _save_customization()
    return CUSTOM[key]


def _set_text_setting(term, key, title, current):
    term.disable()
    try:
        sys.stdout.write("\033[H\033[J")
        sys.stdout.write(f"{ui_title()} | {title}\n")
        sys.stdout.write(ui_line() + "\n\n")
        sys.stdout.write(f"Текущее значение: {current}\n")
        sys.stdout.write("Новое значение: ")
        sys.stdout.flush()
        raw = input()
    finally:
        term.enable()

    raw = str(raw).strip()
    if not raw:
        return False
    CUSTOM[key] = raw[:32]
    _save_customization()
    return True


def ansi(text, color="", bold=False):
    use_bold = bool(bold and CUSTOM.get("bold", True))
    prefix = (BOLD if use_bold else "") + color
    return f"{prefix}{text}{RESET}" if prefix else str(text)


def safe_num(value):
    try:
        return float(str(value).strip().replace(",", "."))
    except Exception:
        return None


def clean_num(value):
    v = safe_num(value)
    if v is None:
        return "?"
    return f"{v:g}"


def metric_grade(kind, value):
    v = safe_num(value)
    if v is None:
        return "N/A", GRAY

    if kind == "rsrp":
        if v >= -90:
            return "EXCELLENT", GREEN
        if v >= -100:
            return "GOOD", GREEN
        if v >= -110:
            return "FAIR", YELLOW
        return "POOR", RED

    if kind == "rsrq":
        if v >= -10:
            return "EXCELLENT", GREEN
        if v >= -15:
            return "GOOD", GREEN
        if v >= -20:
            return "FAIR", YELLOW
        return "POOR", RED

    if kind == "sinr":
        if v >= 20:
            return "EXCELLENT", GREEN
        if v >= 13:
            return "GREAT", GREEN
        if v >= 5:
            return "GOOD", YELLOW
        if v >= 0:
            return "FAIR", YELLOW
        return "POOR", RED

    if kind == "rssi":
        if v >= -65:
            return "EXCELLENT", GREEN
        if v >= -75:
            return "GREAT", GREEN
        if v >= -85:
            return "GOOD", YELLOW
        if v >= -95:
            return "FAIR", YELLOW
        return "POOR", RED

    return "", WHITE


def tui_metric(label, kind, value, unit):
    value_text = "?" if value in ("", "?", None) else f"{value} {unit}".strip()
    _, color = metric_grade(kind, value)
    if not CUSTOM.get("signal_colors", True):
        color = WHITE
    return f" {label}: {ansi(f'{value_text:>10}', color, True)}"


def val(value):
    if value in ("", None):
        return "?"
    return str(value)


def physical_rsrp(raw):
    """
    Родная функция util.js:
        rsrp_format(e) = e - 141
    Для надёжности отрицательное значение считаем уже физическим.
    """
    v = safe_num(raw)
    if v is None:
        return "?"
    if v <= 0:
        return f"{v:g}"
    return f"{v - 141:g}"


def physical_rsrq(raw):
    """
    Родная функция util.js:
        rsrq_format(e) = (e - 40) / 2
    Для надёжности отрицательное значение считаем уже физическим.
    """
    v = safe_num(raw)
    if v is None:
        return "?"
    if v <= 0:
        return f"{v:g}"
    return f"{(v - 40) / 2:g}"


def physical_sinr(raw):
    # nv_sinr на AX8 Pro приходит как готовое значение dB.
    v = safe_num(raw)
    if v is None:
        return "?"
    return f"{v:g}"


def format_speed_human(value):
    """Адаптивная скорость с настраиваемой точностью."""
    v = safe_num(value)
    if v is None:
        return None
    v = max(0.0, float(v))
    kb_dec = int(CUSTOM.get("speed_kb_decimals", 1))
    mb_dec = int(CUSTOM.get("speed_mb_decimals", 2))
    if v >= 1_000_000:
        return f"{v / 1_000_000:.{mb_dec}f} MB/s"
    if v >= 1_000:
        return f"{v / 1_000:.{kb_dec}f} KB/s"
    return f"{v:.0f} B/s"


def format_speed_bytes_per_sec(value):
    # Совместимость со старым именем функции.
    return format_speed_human(value)


def _open_json(req, timeout=5, strict=True):
    with HTTP.open(req, timeout=timeout) as r:
        text = r.read().decode("utf-8", "ignore")
    return json.loads(text, strict=strict)


def http_get(cmd, timeout=3):
    params = urllib.parse.urlencode({
        "isTest": "false",
        "multi_data": "1",
        "cmd": cmd,
    })

    req = urllib.request.Request(
        GET_URL + "?" + params,
        headers=HEADERS,
        method="GET",
    )

    return _open_json(req, timeout=timeout)


def http_post(data, timeout=5):
    payload = dict(data)
    payload.setdefault("isTest", "false")

    body = urllib.parse.urlencode(payload).encode("utf-8")

    headers = dict(HEADERS)
    headers["Content-Type"] = (
        "application/x-www-form-urlencoded; charset=UTF-8"
    )

    req = urllib.request.Request(
        POST_URL,
        data=body,
        headers=headers,
        method="POST",
    )

    return _open_json(req, timeout=timeout)


def router_login(timeout=5):
    """Автоматический вход в OLAX WebUI с сохранением session cookie.

    У OLAX/Sanechips пароль для LOGIN передаётся в Base64. AX8 Pro в WebUI
    использует root/admin. Сначала отправляем root в совместимых полях, затем
    при необходимости повторяем штатный OLAX-вариант только с password.
    """
    encoded_password = base64.b64encode(
        ROUTER_PASSWORD.encode("utf-8")
    ).decode("ascii")

    variants = [
        {
            "isTest": "false",
            "goformId": "LOGIN",
            "user": ROUTER_USER,
            "username": ROUTER_USER,
            "password": encoded_password,
        },
        {
            "isTest": "false",
            "goformId": "LOGIN",
            "password": encoded_password,
        },
    ]

    last_error = None

    for payload in variants:
        # Убираем только локально сохранённые старые cookies. После нового
        # LOGIN роутер выдаст актуальную сессию, если прошивка их использует.
        try:
            COOKIE_JAR.clear()
        except Exception:
            pass

        try:
            http_post(payload, timeout=timeout)
            state = http_get("loginfo", timeout=2)
            if state.get("loginfo") == "ok":
                return True
            last_error = RuntimeError("loginfo != ok")
        except Exception as e:
            last_error = e

    raise RuntimeError(
        f"Автовход root/admin не подтверждён роутером: {last_error}"
    )


def ensure_auth(force=False):
    """Гарантирует активную сессию; при необходимости входит заново."""
    if not force and check_auth():
        return True
    return router_login()


def clean_control_chars(value):
    """Удаляет управляющие символы, которые ломают JSON/WebUI SMS."""
    if value in (None, ""):
        return ""
    return re.sub(r"[\x00-\x1f\x7f-\x9f]", "", str(value))


def decode_sms_content(value):
    """Декодирует UCS2/UTF-16BE HEX, который отдаёт AX8 Pro."""
    if value in (None, ""):
        return ""

    raw = str(value).strip()
    compact = re.sub(r"\s+", "", raw)

    if (
        compact
        and len(compact) % 4 == 0
        and re.fullmatch(r"[0-9A-Fa-f]+", compact)
    ):
        try:
            return bytes.fromhex(compact).decode("utf-16-be", "replace")
        except Exception:
            pass

    return clean_control_chars(raw)


def format_sms_date(value):
    """Приводит YY,MM,DD,HH,MM,SS,TZ к читаемому виду без пересчёта TZ."""
    if value in (None, ""):
        return "?"

    raw = str(value).strip()
    parts = [p.strip() for p in re.split(r"[,;]", raw)]
    if len(parts) < 6:
        return clean_control_chars(raw)

    try:
        yy, mm, dd, hh, minute, sec = [int(x) for x in parts[:6]]
        year = 2000 + yy if yy < 70 else 1900 + yy
        base = f"{dd:02d}.{mm:02d}.{year:04d} {hh:02d}:{minute:02d}:{sec:02d}"
        if len(parts) >= 7 and parts[6]:
            base += f"  TZ {parts[6]}"
        return base
    except Exception:
        return clean_control_chars(raw)


def sms_status(tag):
    tag = str(tag or "")
    return {
        "0": "ПРОЧИТАНО",
        "1": "НОВОЕ",
        "2": "ОТПРАВЛЕНО",
        "4": "ЧЕРНОВИК",
    }.get(tag, f"TAG {tag}" if tag else "?")


def fetch_sms(mem_store=1, timeout=5):
    """Получает SMS отдельным запросом и терпит control chars внутри JSON."""
    ensure_auth()

    params = urllib.parse.urlencode({
        "isTest": "false",
        "cmd": "sms_data_total",
        "page": "0",
        "data_per_page": "500",
        "mem_store": str(mem_store),
        "tags": "10",
        "order_by": "order by id desc",
    })

    req = urllib.request.Request(
        GET_URL + "?" + params,
        headers=HEADERS,
        method="GET",
    )

    with HTTP.open(req, timeout=timeout) as r:
        text = r.read().decode("utf-8", "replace")

    # strict=False специально: у текущих SMS отправитель содержит U+0011,
    # из-за чего обычный json.loads() и штатный WebUI падают.
    payload = json.loads(text, strict=False)
    rows = payload.get("messages", []) if isinstance(payload, dict) else []
    if not isinstance(rows, list):
        rows = []

    messages = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        messages.append({
            "id": clean_control_chars(row.get("id")) or "?",
            "number": clean_control_chars(row.get("number")) or "?",
            "content": decode_sms_content(row.get("content")),
            "date": format_sms_date(row.get("date")),
            "tag": clean_control_chars(row.get("tag")),
            "status": sms_status(row.get("tag")),
        })

    return messages


def mark_sms_read(msg_id):
    """Помечает одно входящее SMS как прочитанное через штатный SET_MSG_READ."""
    msg_id = str(msg_id).strip()
    if not re.fullmatch(r"\d+", msg_id):
        raise RuntimeError("Некорректный ID SMS.")

    ensure_auth()

    result = http_post({
        "goformId": "SET_MSG_READ",
        "msg_id": msg_id + ";",
        "tag": "0",
        "notCallback": "true",
    }, timeout=5)

    if result.get("result") != "success":
        raise RuntimeError(f"SET_MSG_READ: {result}")

    return True


def delete_sms(msg_id):
    """Удаляет ровно одно SMS. ID валидируется перед формированием msg_id."""
    msg_id = str(msg_id).strip()
    if not re.fullmatch(r"\d+", msg_id):
        raise RuntimeError("Некорректный ID SMS.")

    ensure_auth()

    result = http_post({
        "goformId": "DELETE_SMS",
        "msg_id": msg_id + ";",
        "notCallback": "true",
    }, timeout=5)

    if result.get("result") != "success":
        raise RuntimeError(f"DELETE_SMS: {result}")

    return True


def delete_all_sms(messages):
    """Удаляет все SMS из переданного списка по одному через штатный DELETE_SMS.

    Возвращает (deleted_count, failed_ids).
    """
    ids = []
    for sms in messages or []:
        msg_id = str(sms.get("id", "")).strip()
        if re.fullmatch(r"\d+", msg_id) and msg_id not in ids:
            ids.append(msg_id)

    if not ids:
        return 0, []

    deleted = 0
    failed = []

    for msg_id in ids:
        try:
            delete_sms(msg_id)
            deleted += 1
        except Exception:
            failed.append(msg_id)

    return deleted, failed


def _network_post(goform_id, timeout=5):
    """Выполняет штатную команду управления мобильным WAN."""
    ensure_auth()
    result = http_post({
        "goformId": goform_id,
        "notCallback": "true",
    }, timeout=timeout)

    value = str(result.get("result", "")).strip().lower()
    if value not in ("success", "ok", "0"):
        raise RuntimeError(f"{goform_id}: {result}")
    return result


def _read_ppp_status(timeout=2):
    try:
        return str(
            http_get("ppp_status", timeout=timeout).get("ppp_status", "") or ""
        ).strip()
    except Exception:
        return ""


def _wait_network_state(want_connected, timeout, title, phase):
    """Ждёт фактического ppp_status после CONNECT/DISCONNECT."""
    deadline = time.monotonic() + timeout
    last = "?"

    while time.monotonic() < deadline:
        status = _read_ppp_status(timeout=2)
        if status:
            last = status

        connected = status == "ppp_connected"
        changing = status in (
            "ppp_connecting",
            "connecting",
            "ppp_disconnecting",
            "disconnecting",
        )

        if want_connected and connected:
            return status
        if not want_connected and status and not connected and not changing:
            return status

        render_action_screen(
            title,
            [
                ("ДЕЙСТВИЕ", phase, CYAN),
                (
                    "СЕТЬ",
                    last,
                    GREEN if connected else (YELLOW if changing else RED),
                ),
            ],
            "Ожидание состояния сети…",
        )
        time.sleep(1)

    target = "ppp_connected" if want_connected else "отключения"
    raise RuntimeError(
        f"Не дождался {target} за {timeout} сек. Последнее состояние: {last}"
    )


def set_network_enabled(enabled):
    """Включает или отключает мобильное WAN-соединение без перезагрузки."""
    command = "CONNECT_NETWORK" if enabled else "DISCONNECT_NETWORK"
    title = "СЕТЬ: ВКЛ" if enabled else "СЕТЬ: ВЫКЛ"
    phase = "ПОДКЛЮЧЕНИЕ" if enabled else "ОТКЛЮЧЕНИЕ"

    render_action_screen(
        title,
        [
            ("КОМАНДА", command, CYAN),
            ("СЕТЬ", "ОЖИДАНИЕ", YELLOW),
        ],
        "Отправка команды роутеру…",
    )

    _network_post(command)
    _wait_network_state(enabled, 60 if enabled else 20, title, phase)
    return "✓ Сеть включена" if enabled else "✓ Сеть выключена"


def reconnect_network():
    """Переподключает мобильную сеть: DISCONNECT_NETWORK -> CONNECT_NETWORK."""
    title = "ПЕРЕПОДКЛЮЧЕНИЕ СЕТИ"

    render_action_screen(
        title,
        [
            ("ШАГ 1/2", "ОТКЛЮЧЕНИЕ", YELLOW),
            ("ШАГ 2/2", "ОЖИДАНИЕ", GRAY),
        ],
        "Разрываю текущее соединение…",
    )

    _network_post("DISCONNECT_NETWORK")
    _wait_network_state(False, 20, title, "ОТКЛЮЧЕНИЕ")
    time.sleep(1)

    render_action_screen(
        title,
        [
            ("ШАГ 1/2", "ГОТОВО", GREEN),
            ("ШАГ 2/2", "ПОДКЛЮЧЕНИЕ", YELLOW),
        ],
        "Подключаюсь к сети заново…",
    )

    _network_post("CONNECT_NETWORK")
    _wait_network_state(True, 60, title, "ПОДКЛЮЧЕНИЕ")
    return "✓ Сеть переподключена"



def first_nonempty(data, *names):
    for name in names:
        value = data.get(name)
        if value not in ("", None, "?", "--"):
            return value
    return None


def split_pair(value):
    if value in ("", None, "?", "--"):
        return None, None
    parts = re.split(r"[/,;| ]+", str(value).strip())
    parts = [p for p in parts if p]
    if not parts:
        return None, None
    if len(parts) == 1:
        return parts[0], None
    return parts[0], parts[1]


def bandwidth_mhz(data):
    raw = first_nonempty(
        data,
        "lte_bandwidth",
        "lte_bw",
        "current_bandwidth",
        "CurrentBandwidth",
        "dl_bandwidth",
        "lte_dl_bandwidth",
        "nv_dl_bandwidth",
        "bandwidth",
    )

    if raw is not None:
        m = re.search(r"(\d+(?:\.\d+)?)", str(raw).strip())
        if m:
            v = float(m.group(1))
            if v in (1.4, 3, 5, 10, 15, 20):
                return v

    code = str(data.get("nv_bandwidth", "") or "").strip()

    # Наблюдавшиеся на этом AX8 Pro значения:
    # B3 -> raw 1 -> 20 MHz
    # B20 -> raw 2 -> 10 MHz
    observed = {
        "1": 20.0,
        "2": 10.0,
    }
    return observed.get(code)


def format_bandwidth(data):
    bw = bandwidth_mhz(data)
    if bw is None:
        raw = data.get("nv_bandwidth", "")
        return f"RAW {raw}" if raw not in ("", None) else "--"
    return f"{bw:g} MHz"


def battery_percent(data):
    """Return the real battery percentage.

    Important for this AX8 Pro firmware:
      battery_vol_percent = actual 0..100 percentage
      battery_pers        = icon/level value (for example 4), NOT 4%

    Therefore battery_pers must never be interpreted as a percentage.
    """
    raw = data.get("battery_vol_percent")
    if raw in (None, "", "--", "?", "N/A", "n/a", "null", "None"):
        return "?"

    s = str(raw).strip().replace("%", "")
    v = safe_num(s)
    if v is None:
        return "?"

    # Some related ZTE firmwares expose a 0..1 fraction.
    if 0 < v <= 1 and "." in s:
        v *= 100.0

    if 0 <= v <= 100:
        return str(int(round(v)))

    return "?"


def battery_color(percent):
    """Situational battery color using saved customization thresholds."""
    if not CUSTOM.get("battery_colors", True):
        return WHITE
    try:
        value = int(str(percent).strip())
    except Exception:
        return WHITE

    green_min = int(CUSTOM.get("battery_green_min", 50))
    yellow_min = int(CUSTOM.get("battery_yellow_min", 20))
    if value >= green_min:
        return GREEN
    if value >= yellow_min:
        return YELLOW
    return RED


def physical_rssi(data, rsrp_value, rsrq_value):
    raw = first_nonempty(data, "nv_rssi", "lte_rssi")
    v = safe_num(raw)
    if v is not None:
        if 0 < v <= 150:
            v = -v
        if -150 <= v <= -20:
            return f"{v:g}"

    csq = safe_num(data.get("wan_csq"))
    if csq is not None and 0 <= csq <= 31:
        return f"{(-113 + 2 * csq):g}"

    rv = safe_num(data.get("rssi"))
    rsrp = safe_num(rsrp_value)
    if rv is not None:
        if 0 < rv <= 150:
            rv = -rv
        if -150 <= rv <= -20:
            # На этой прошивке rssi иногда просто дублирует RSRP.
            if rsrp is None or abs(rv - rsrp) >= 3:
                return f"{rv:g}"

    # LTE fallback:
    # RSRQ = N * RSRP / RSSI
    # RSSI[dBm] = RSRP + 10log10(N) - RSRQ
    rsrq = safe_num(rsrq_value)
    bw = bandwidth_mhz(data)
    rb = {
        1.4: 6,
        3.0: 15,
        5.0: 25,
        10.0: 50,
        15.0: 75,
        20.0: 100,
    }.get(bw)

    if rsrp is not None and rsrq is not None and rb:
        value = rsrp + 10.0 * math.log10(rb) - rsrq
        return f"{value:.1f}"

    return "?"


def normalize_txpower(value):
    v = safe_num(value)
    if v is None:
        return "?"
    if -80 <= v <= 50:
        return f"{v:g} dBm"
    return str(value)


def normalize_scalar(value):
    if value in ("", None, "?", "--"):
        return "?"
    return str(value)


def http_get_single(cmd, timeout=2):
    params = urllib.parse.urlencode({
        "isTest": "false",
        "cmd": cmd,
    })

    req = urllib.request.Request(
        GET_URL + "?" + params,
        headers=HEADERS,
        method="GET",
    )

    return _open_json(req, timeout=timeout)


def fetch_connected_clients(radio_raw=None):
    # Сначала используем готовый счётчик, если прошивка его отдаёт.
    if radio_raw:
        v = safe_num(radio_raw.get("wifi_access_sta_num"))
        if v is not None and v >= 0:
            return int(v)

    # station_list на ZTE/Sanechips нужно запрашивать отдельно,
    # без multi_data=1. LAN-варианты нужны для CPE с Ethernet.
    total_ids = set()
    anonymous = 0
    any_supported = False

    for cmd in ("station_list", "lan_station_list", "lan_station_list_all"):
        try:
            payload = http_get_single(cmd, timeout=1.2)
        except Exception:
            continue

        obj = payload
        if isinstance(payload, dict) and cmd in payload:
            obj = payload.get(cmd)

        if obj in ("", None):
            any_supported = True
            continue

        if isinstance(obj, str):
            try:
                obj = json.loads(obj)
            except Exception:
                continue

        if not isinstance(obj, list):
            continue

        any_supported = True

        for item in obj:
            if not isinstance(item, dict):
                anonymous += 1
                continue

            status = str(
                item.get(
                    "connected",
                    item.get(
                        "is_connected",
                        item.get("status", "")
                    )
                )
            ).strip().lower()

            if status in ("0", "false", "offline", "disconnected"):
                continue

            ident = (
                item.get("mac_addr")
                or item.get("mac")
                or item.get("MAC")
                or item.get("ip_addr")
                or item.get("ip")
                or item.get("hostname")
            )

            if ident:
                total_ids.add(str(ident).strip().lower())
            else:
                anonymous += 1

    if any_supported:
        return len(total_ids) + anonymous

    return None



# ---------------------------------------------------------------------------
# Wi-Fi clients / MAC blacklist
# ---------------------------------------------------------------------------

DEVICE_NAME_CACHE = {}
DEVICE_ALIAS_CACHE = {}
DEVICE_ALIAS_FILE = Path.home() / ".ax8_device_aliases.json"
MAC_RE = re.compile(r"(?i)(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}")


def normalize_mac(value):
    if value in (None, ""):
        return ""
    m = MAC_RE.search(str(value))
    if not m:
        return ""
    return m.group(0).replace("-", ":").upper()


def _load_device_aliases():
    DEVICE_ALIAS_CACHE.clear()
    try:
        raw = json.loads(DEVICE_ALIAS_FILE.read_text(encoding="utf-8"))
    except Exception:
        raw = {}
    if not isinstance(raw, dict):
        return
    for mac, name in raw.items():
        nmac = normalize_mac(mac)
        name = clean_control_chars(name).strip()
        if nmac and name:
            DEVICE_ALIAS_CACHE[nmac] = name


def _save_device_aliases():
    DEVICE_ALIAS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = DEVICE_ALIAS_FILE.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(DEVICE_ALIAS_CACHE, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    tmp.replace(DEVICE_ALIAS_FILE)


def get_device_alias(mac):
    return DEVICE_ALIAS_CACHE.get(normalize_mac(mac), "")


def set_device_alias(mac, name):
    mac = normalize_mac(mac)
    if not mac:
        raise RuntimeError("Некорректный MAC-адрес")
    name = clean_control_chars(name).strip()

    if name:
        # Это локальный псевдоним скрипта, а не hostname прошивки.
        # Поэтому лимит длины WebUI/firmware здесь не применяется.
        DEVICE_ALIAS_CACHE[mac] = name
        _save_device_aliases()
        return f"✓ Имя сохранено: {name}"

    if mac in DEVICE_ALIAS_CACHE:
        DEVICE_ALIAS_CACHE.pop(mac, None)
        _save_device_aliases()
        return "✓ Локальное имя удалено, используется имя роутера"

    return "Локальное имя для устройства не задано"


_load_device_aliases()


def _split_mac_list(value):
    """Возвращает уникальные MAC из строки/списка в порядке появления."""
    result = []
    seen = set()

    def add_from(item):
        if item is None:
            return
        if isinstance(item, (list, tuple, set)):
            for part in item:
                add_from(part)
            return
        if isinstance(item, dict):
            for key in ("mac", "mac_addr", "macAddress", "MAC"):
                if key in item:
                    add_from(item.get(key))
            return
        for raw in MAC_RE.findall(str(item)):
            mac = normalize_mac(raw)
            if mac and mac not in seen:
                seen.add(mac)
                result.append(mac)

    add_from(value)
    return result


def _safe_json_obj(value):
    if isinstance(value, (dict, list)):
        return value
    if not isinstance(value, str):
        return value
    raw = value.strip()
    if not raw:
        return value
    try:
        return json.loads(raw, strict=False)
    except Exception:
        return value


def _extract_station_rows(payload, cmd):
    obj = payload
    if isinstance(payload, dict) and cmd in payload:
        obj = payload.get(cmd)
    obj = _safe_json_obj(obj)

    if isinstance(obj, dict):
        for key in ("devices", "station_list", "list", "data", "items"):
            if isinstance(obj.get(key), list):
                obj = obj.get(key)
                break

    return obj if isinstance(obj, list) else []


def _device_name_from_row(row):
    for key in (
        "hostname", "host_name", "name", "device_name", "HostName",
        "hostName", "dev_name",
    ):
        value = clean_control_chars(row.get(key)) if isinstance(row, dict) else ""
        if value and value.lower() not in ("unknown", "unkown", "none", "null"):
            return value
    return "Без имени"


def _device_ip_from_row(row):
    for key in ("ip_addr", "ip", "IP", "ipAddress", "ipv4", "ip_address"):
        value = str(row.get(key, "") or "").strip()
        if value:
            return value
    return ""


def _normalize_ipv6(value):
    raw = str(value or "").strip()
    if not raw:
        return ""
    raw = raw.split("%", 1)[0].split("/", 1)[0].strip("[]")
    try:
        addr = ipaddress.ip_address(raw)
    except Exception:
        return ""
    if addr.version != 6:
        return ""
    if addr.is_unspecified or addr.is_loopback or addr.is_multicast or addr.is_link_local:
        return ""
    return addr.compressed


def _device_ipv6s_from_row(row):
    if not isinstance(row, dict):
        return []

    found = []
    seen = set()
    for key in (
        "ipv6_addr", "ipv6", "ipv6_address", "ip6_addr",
        "IPv6", "ipv6Address", "global_ipv6", "wan_ipv6",
    ):
        raw = row.get(key)
        if raw in (None, "", "--", "?"):
            continue
        if isinstance(raw, (list, tuple)):
            parts = raw
        else:
            parts = re.split(r"[\s,;]+", str(raw))
        for part in parts:
            addr = _normalize_ipv6(part)
            if addr and addr not in seen:
                seen.add(addr)
                found.append(addr)
    return found


def _router_ipv6_neighbors_by_mac():
    """Best-effort MAC -> global/ULA IPv6 map from the router neighbor table."""
    result = {}
    try:
        out, rc = router_exec("ip -6 neigh show 2>/dev/null", timeout=3)
    except Exception:
        return result
    if rc != 0 or not out:
        return result

    for line in out.splitlines():
        m = re.search(
            r"^\s*(\S+).*?\blladdr\s+((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})\b",
            line,
        )
        if not m:
            continue
        addr = _normalize_ipv6(m.group(1))
        mac = normalize_mac(m.group(2))
        if not addr or not mac:
            continue
        result.setdefault(mac, [])
        if addr not in result[mac]:
            result[mac].append(addr)
    return result


def _device_mac_from_row(row):
    for key in (
        "mac_addr", "mac", "MAC", "macAddress", "MacAddress",
        "station_mac", "client_mac_address",
    ):
        mac = normalize_mac(row.get(key))
        if mac:
            return mac
    return ""


def _device_connected_from_row(row, default=True):
    raw = first_nonempty(
        row,
        "connected", "is_connected", "online", "is_online", "status",
    ) if isinstance(row, dict) else None
    if raw is None:
        return default
    value = str(raw).strip().lower()
    if value in ("0", "false", "offline", "disconnected", "disconnect"):
        return False
    if value in ("1", "true", "online", "connected", "connect"):
        return True
    return default


def _device_type_from_row(row):
    for key in (
        "dev_type", "device_type", "conn_type", "connect_type", "interface",
        "ssid_index", "ssid", "type",
    ):
        value = str(row.get(key, "") or "").strip()
        if value:
            return value
    return "?"


def _valid_device_time_value(value):
    raw = str(value or "").strip()
    return raw not in ("", "--", "-", "?", "N/A", "n/a", "null", "None")


def _device_time_from_row(row):
    """Возвращает фактическое время подключения клиента.

    AX8 Pro может отдавать duration как:
      • "2h:11m16s"
      • число секунд
      • число миллисекунд

    Для числового duration масштаб определяем по timestamp, если он доступен.
    """
    if not isinstance(row, dict):
        return ""

    def timestamp_elapsed():
        stamp = str(row.get("timestamp", "") or "").strip()
        if not _valid_device_time_value(stamp):
            return None

        # Unix timestamp seconds / milliseconds.
        if re.fullmatch(r"\d+(?:\.\d+)?", stamp):
            try:
                n = float(stamp)
                if n > 10_000_000_000:
                    n /= 1000.0
                elapsed = time.time() - n
                if elapsed >= 0:
                    return int(elapsed)
            except Exception:
                pass

        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S"):
            try:
                started = time.mktime(time.strptime(stamp, fmt))
                elapsed = max(0, int(time.time() - started))
                return elapsed
            except Exception:
                pass
        return None

    stamp_elapsed = timestamp_elapsed()

    for key in (
        "duration", "online_duration", "connected_duration", "uptime",
        "online_time", "connection_time", "conn_time", "connect_time",
    ):
        value = row.get(key, "")
        if not _valid_device_time_value(value):
            continue

        raw = str(value).strip()

        # Human-readable format, leave it as-is for format_device_time().
        if re.search(r"[dhms:]", raw, re.I):
            return raw

        # Pure numeric value. Decide seconds vs milliseconds.
        if re.fullmatch(r"\d+(?:\.\d+)?", raw):
            try:
                n = float(raw)
                sec_candidate = max(0, int(n))
                ms_candidate = max(0, int(n / 1000.0))

                if stamp_elapsed is not None:
                    # Choose the interpretation closest to timestamp-derived uptime.
                    if abs(ms_candidate - stamp_elapsed) < abs(sec_candidate - stamp_elapsed):
                        return str(ms_candidate)
                    return str(sec_candidate)

                # Fallback heuristic: multi-year "uptime" is implausible here and
                # strongly indicates that duration is milliseconds.
                if sec_candidate > 365 * 24 * 3600:
                    return str(ms_candidate)
                return str(sec_candidate)
            except Exception:
                pass

        return raw

    # Last fallback: derive duration directly from timestamp.
    if stamp_elapsed is not None:
        return str(stamp_elapsed)

    return ""


def format_device_time(value):
    raw = str(value or "").strip()
    if not _valid_device_time_value(raw):
        return ""

    # Формат AX8 Pro: 2h:11m16s / 21m30s / 45s.
    compact = raw.replace(" ", "")
    m = re.fullmatch(
        r"(?:(\d+)d[: ]*)?(?:(\d+)h[: ]*)?(?:(\d+)m[: ]*)?(?:(\d+)s)?",
        compact,
        re.I,
    )
    if m and any(part is not None for part in m.groups()):
        days, hours, mins, secs = [int(x or 0) for x in m.groups()]
        total = days * 86400 + hours * 3600 + mins * 60 + secs
    else:
        # Поддержка HH:MM:SS / MM:SS.
        colon = re.fullmatch(r"(\d+):(\d{1,2})(?::(\d{1,2}))?", raw)
        if colon:
            a, b, c = colon.groups()
            if c is None:
                total = int(a) * 60 + int(b)
            else:
                total = int(a) * 3600 + int(b) * 60 + int(c)
        else:
            try:
                total = int(float(raw))
            except Exception:
                return raw

    if total < 0:
        return raw

    # Время подключения показываем строго как HH:MM:SS.
    # Если подключение дольше суток, часы продолжают расти: 27:04:12.
    total_hours, rem = divmod(total, 3600)
    mins, secs = divmod(rem, 60)
    return f"{total_hours:02d}:{mins:02d}:{secs:02d}"


def _fetch_hostname_map():
    """Пытается получить сохранённые имена устройств, если firmware их отдаёт."""
    result = {}
    try:
        payload = http_get_single("hostNameList", timeout=1.5)
    except Exception:
        return result

    rows = _extract_station_rows(payload, "hostNameList")
    for row in rows:
        if not isinstance(row, dict):
            continue
        mac = _device_mac_from_row(row)
        name = _device_name_from_row(row)
        if mac and name != "Без имени":
            result[mac] = name
    return result


def fetch_connected_devices(timeout=2):
    """Получает подробный список подключённых клиентов AX8 Pro."""
    ensure_auth()
    devices_by_mac = {}
    anonymous = []
    supported = False

    # station_list является основным ZTE/Sanechips источником. LAN-варианты
    # оставлены как fallback для CPE-прошивок с Ethernet.
    for cmd in ("station_list", "lan_station_list", "lan_station_list_all"):
        try:
            payload = http_get_single(cmd, timeout=timeout)
        except Exception:
            continue

        rows = _extract_station_rows(payload, cmd)
        if rows or (isinstance(payload, dict) and cmd in payload):
            supported = True

        for row in rows:
            if not isinstance(row, dict):
                continue
            if not _device_connected_from_row(row, default=True):
                continue

            mac = _device_mac_from_row(row)
            dev = {
                "name": _device_name_from_row(row),
                "ip": _device_ip_from_row(row),
                "mac": mac,
                "ipv6": _device_ipv6s_from_row(row),
                "type": _device_type_from_row(row),
                "time": _device_time_from_row(row),
                "connected": True,
                # Полная строка station_list нужна для per-device traffic.
                # Поля различаются между прошивками, поэтому ниже работает
                # автоопределение известных счётчиков/throughput-полей.
                "_raw": dict(row),
            }

            if mac:
                old = devices_by_mac.get(mac, {})
                # Берём более информативные значения из любого источника.
                for key, value in dev.items():
                    if key == "_raw":
                        merged_raw = dict(old.get("_raw") or {})
                        merged_raw.update(value or {})
                        old["_raw"] = merged_raw
                    elif key == "ipv6":
                        merged = list(old.get("ipv6") or [])
                        for addr in value or []:
                            if addr not in merged:
                                merged.append(addr)
                        old["ipv6"] = merged
                    elif value not in ("", "?", "Без имени", None):
                        old[key] = value
                old.setdefault("name", dev["name"])
                old.setdefault("ip", dev["ip"])
                old.setdefault("mac", mac)
                old.setdefault("type", dev["type"])
                old.setdefault("time", dev["time"])
                old["connected"] = True
                devices_by_mac[mac] = old
            else:
                anonymous.append(dev)

    if not supported:
        raise RuntimeError("Прошивка не отдала station_list.")

    names = _fetch_hostname_map()
    for mac, name in names.items():
        DEVICE_NAME_CACHE[mac] = name

    devices = list(devices_by_mac.values()) + anonymous

    # iOS/macOS often prefer IPv6.  Some firmware builds omit the current
    # global IPv6 from station_list, so supplement it from the neighbor table.
    try:
        neigh6 = _router_ipv6_neighbors_by_mac()
    except Exception:
        neigh6 = {}

    for dev in devices:
        mac = dev.get("mac", "")
        dev.setdefault("ipv6", [])
        if mac and mac in neigh6:
            for addr in neigh6[mac]:
                if addr not in dev["ipv6"]:
                    dev["ipv6"].append(addr)

        name = dev.get("name", "Без имени")
        if mac:
            if name and name != "Без имени":
                DEVICE_NAME_CACHE[mac] = name
            elif mac in DEVICE_NAME_CACHE:
                dev["name"] = DEVICE_NAME_CACHE[mac]

    devices.sort(
        key=lambda d: (
            (get_device_alias(d.get("mac")) or d.get("name") or "").lower(),
            d.get("mac") or "",
        )
    )
    return devices


def _unwrap_access_control(payload):
    obj = payload
    if isinstance(payload, dict) and "queryDeviceAccessControlList" in payload:
        obj = payload.get("queryDeviceAccessControlList")
    obj = _safe_json_obj(obj)
    return obj if isinstance(obj, dict) else {}


# После первой успешной записи запоминаем реально рабочий backend этой прошивки.
# На AX8 Pro queryDeviceAccessControlList может читаться, хотя
# setDeviceAccessControlList возвращает failure. Поэтому нельзя считать, что
# читаемый backend обязательно пригоден для записи.
BLOCKLIST_BACKEND_HINT = None


def _read_wifi_mac_filter_state():
    obj = http_get(
        "ACL_mode,wifi_mac_black_list,wifi_hostname_black_list,"
        "wifi_mac_white_list,wifi_hostname_white_list,user_ip_addr,"
        "client_ip_address,get_user_mac_addr",
        timeout=3,
    )
    if not isinstance(obj, dict) or not any(
        k in obj for k in ("ACL_mode", "wifi_mac_black_list", "wifi_mac_white_list")
    ):
        raise RuntimeError("WIFI_MAC_FILTER API не поддерживается")

    return {
        "backend": "wifi_mac_filter",
        "mode": str(obj.get("ACL_mode", "") or ""),
        "black": _split_mac_list(obj.get("wifi_mac_black_list", "")),
        "white": _split_mac_list(obj.get("wifi_mac_white_list", "")),
        "black_raw": obj.get("wifi_mac_black_list", ""),
        "white_raw": obj.get("wifi_mac_white_list", ""),
        "black_names_raw": obj.get("wifi_hostname_black_list", ""),
        "white_names_raw": obj.get("wifi_hostname_white_list", ""),
        "user_ip": str(
            obj.get("user_ip_addr") or obj.get("client_ip_address") or ""
        ).strip(),
        "user_mac": normalize_mac(obj.get("get_user_mac_addr")),
    }


def _read_access_control_state():
    payload = http_get_single("queryDeviceAccessControlList", timeout=2.5)
    obj = _unwrap_access_control(payload)
    if not any(k in obj for k in ("AclMode", "BlackMacList", "WhiteMacList")):
        raise RuntimeError("DeviceAccessControl API не поддерживается")

    black_raw = obj.get("BlackMacList", "")
    white_raw = obj.get("WhiteMacList", "")
    return {
        "backend": "access_control",
        "mode": str(obj.get("AclMode", "") or ""),
        "black": _split_mac_list(black_raw),
        "white": _split_mac_list(white_raw),
        "black_raw": black_raw,
        "white_raw": white_raw,
        "black_names_raw": obj.get("BlackNameList", ""),
        "white_names_raw": obj.get("WhiteNameList", ""),
        "user_ip": "",
        "user_mac": "",
    }


def _read_blocklist_backend(backend):
    if backend == "wifi_mac_filter":
        return _read_wifi_mac_filter_state()
    if backend == "access_control":
        return _read_access_control_state()
    raise RuntimeError(f"Неизвестный backend блокировок: {backend}")


def read_blocklist_state():
    """Читает blacklist через реально рабочую схему AX8 Pro.

    На этой прошивке новый queryDeviceAccessControlList может быть доступен
    только для чтения, а setDeviceAccessControlList отвечать failure. Поэтому
    сначала используем классический WIFI_MAC_FILTER и после успешной записи
    запоминаем backend.
    """
    ensure_auth()
    errors = []

    order = []
    if BLOCKLIST_BACKEND_HINT:
        order.append(BLOCKLIST_BACKEND_HINT)
    for backend in ("wifi_mac_filter", "access_control"):
        if backend not in order:
            order.append(backend)

    for backend in order:
        try:
            return _read_blocklist_backend(backend)
        except Exception as e:
            errors.append(f"{backend}: {e}")

    raise RuntimeError(
        "Не удалось прочитать список блокировок"
        + (": " + " | ".join(errors[-2:]) if errors else ".")
    )


def _result_success(result):
    if not isinstance(result, dict):
        return False
    value = str(result.get("result", "")).strip().lower()
    return value in ("success", "ok", "0")


def _router_ad_token(timeout=3):
    """Вычисляет ZTE/OLAX AD token, если конкретная команда его требует."""
    data = http_get("wa_inner_version,cr_version,RD", timeout=timeout)
    wa = str(data.get("wa_inner_version", "") or "")
    cr = str(data.get("cr_version", "") or "")
    rd = str(data.get("RD", "") or "")
    if not (wa or cr) or not rd:
        raise RuntimeError("Роутер не отдал данные для AD token")
    first = hashlib.md5((wa + cr).encode("utf-8")).hexdigest()
    return hashlib.md5((first + rd).encode("utf-8")).hexdigest()


def _post_with_ad_retry(payload, timeout=5):
    """POST как WebUI: обычная попытка, затем повтор с AD при failure."""
    result = http_post(payload, timeout=timeout)
    if _result_success(result):
        return result

    try:
        ad = _router_ad_token()
    except Exception:
        return result

    retry = dict(payload)
    retry["AD"] = ad
    return http_post(retry, timeout=timeout)


def _names_for_macs(macs, extra_names=None):
    extra_names = extra_names or {}
    names = []
    for mac in macs:
        name = extra_names.get(mac) or DEVICE_NAME_CACHE.get(mac) or ""
        names.append(clean_control_chars(name))
    return ";".join(names)


def _write_blocklist_once(macs, state, names=None, mode_override=None):
    macs = [normalize_mac(m) for m in macs]
    macs = [m for i, m in enumerate(macs) if m and m not in macs[:i]]
    mac_text = ";".join(macs)
    name_text = _names_for_macs(macs, names)
    # Обычно пустой DENY-лист => ACL off, непустой => DENY mode 2.
    # Для очистки хранилища AX8 Pro нужен промежуточный режим 2: при ACL_mode=0
    # некоторые прошивки отключают фильтр, но игнорируют пустой список и оставляют
    # старые MAC в NVRAM.
    mode = str(mode_override) if mode_override is not None else ("2" if macs else "0")

    backend = state.get("backend")
    if backend == "access_control":
        payload = {
            "goformId": "setDeviceAccessControlList",
            "AclMode": mode,
            "WhiteMacList": state.get("white_raw", "") or "",
            "BlackMacList": mac_text,
            "WhiteNameList": state.get("white_names_raw", "") or "",
            "BlackNameList": name_text,
        }
    else:
        payload = {
            "goformId": "WIFI_MAC_FILTER",
            "ACL_mode": mode,
            "macFilteringMode": mode,
            "wifi_hostname_black_list": name_text,
            "wifi_mac_black_list": mac_text,
        }

    result = _post_with_ad_retry(payload, timeout=5)
    if not _result_success(result):
        raise RuntimeError(f"{payload['goformId']}: {result}")


def write_blocklist(macs, names=None, state=None):
    """Записывает blacklist и проверяет именно тот backend, куда писали."""
    global BLOCKLIST_BACKEND_HINT

    ensure_auth()
    if state is None:
        state = read_blocklist_state()

    # Не ломаем заранее настроенный whitelist пользователя.
    if macs and state.get("white") and str(state.get("mode", "")) not in ("", "0", "2"):
        raise RuntimeError(
            "Сейчас активен ALLOW/whitelist. Автопереключение в DENY отменено."
        )

    wanted = []
    for mac in macs:
        m = normalize_mac(mac)
        if m and m not in wanted:
            wanted.append(m)

    # AX8 Pro сначала пробуем через классический WIFI_MAC_FILTER. На текущей
    # прошивке queryDeviceAccessControlList читается, но set... может быть read-only.
    backends = []
    if BLOCKLIST_BACKEND_HINT:
        backends.append(BLOCKLIST_BACKEND_HINT)
    for b in ("wifi_mac_filter", state.get("backend"), "access_control"):
        if b and b not in backends:
            backends.append(b)

    errors = []
    for backend in backends:
        trial = dict(state)
        trial["backend"] = backend

        # Берём native-поля именно этого backend, если он читается.
        try:
            native = _read_blocklist_backend(backend)
            trial.update(native)
        except Exception:
            pass

        try:
            # Особенность AX8 Pro: WIFI_MAC_FILTER с ACL_mode=0 может только
            # выключить фильтр, не стирая старые MAC из wifi_mac_black_list.
            # Поэтому при очистке сначала оставляем DENY-режим включённым и
            # записываем ПУСТОЙ список. Только после подтверждённой очистки
            # пытаемся выключить ACL. Это же чинит возврат исходного пустого
            # списка после [K] ВРЕМЕННО ОТКЛЮЧИТЬ.
            if backend == "wifi_mac_filter" and not wanted:
                _write_blocklist_once([], trial, names=names, mode_override="2")
                time.sleep(0.6)
                verify = _read_wifi_mac_filter_state()
                have = set(verify.get("black", []))

                # Дополнительный штатный goform старых ZTE/OLAX. На части
                # прошивок именно он сохраняет сам список отдельно от ACL_mode.
                if have:
                    save_result = _post_with_ad_retry({
                        "goformId": "GOFORM_WLAN_SAVE_WIFI_MAC_BLACK_LIST",
                        "wifi_mac_black_list": "",
                        "wifi_hostname_black_list": "",
                    }, timeout=5)
                    if _result_success(save_result):
                        time.sleep(0.6)
                        verify = _read_wifi_mac_filter_state()
                        have = set(verify.get("black", []))

                if have:
                    raise RuntimeError(
                        f"не удалось стереть MAC из DENY: {sorted(have)}"
                    )

                # Список физически пуст. Теперь выключаем ACL. Если конкретная
                # прошивка при ACL_mode=0 снова показывает старое значение,
                # возвращаем DENY mode 2 с пустым списком: блокировок всё равно 0.
                _write_blocklist_once([], verify, names=names, mode_override="0")
                time.sleep(0.4)
                final_state = _read_wifi_mac_filter_state()
                final_have = set(final_state.get("black", []))
                if final_have:
                    _write_blocklist_once([], final_state, names=names, mode_override="2")
                    time.sleep(0.5)
                    final_state = _read_wifi_mac_filter_state()
                    final_have = set(final_state.get("black", []))

                if not final_have:
                    BLOCKLIST_BACKEND_HINT = backend
                    return final_state
                raise RuntimeError(
                    f"после отключения ACL старый DENY вернулся: {sorted(final_have)}"
                )

            _write_blocklist_once(wanted, trial, names=names)
            time.sleep(0.5)

            # Проверяем тот же backend, в который писали.
            verify = _read_blocklist_backend(backend)
            have = set(verify.get("black", []))
            if have == set(wanted):
                BLOCKLIST_BACKEND_HINT = backend
                return verify

            errors.append(
                f"{backend}: ожидалось {wanted}, получено {sorted(have)}"
            )
        except Exception as e:
            errors.append(f"{backend}: {e}")

    raise RuntimeError(
        "Роутер не применил список блокировок: " + " | ".join(errors[-3:])
    )

def get_management_mac(devices=None, state=None):
    """Определяет MAC телефона/ПК, с которого выполняется управление, если возможно."""
    state = state or {}
    direct = normalize_mac(state.get("user_mac"))
    if direct:
        return direct

    try:
        info = http_get(
            "get_user_mac_addr,user_mac_addr,user_ip_addr,client_ip_address",
            timeout=2,
        )
        for key in ("get_user_mac_addr", "user_mac_addr"):
            mac = normalize_mac(info.get(key))
            if mac:
                return mac
        ip = str(info.get("user_ip_addr") or info.get("client_ip_address") or "").strip()
    except Exception:
        ip = str(state.get("user_ip") or "").strip()

    if ip and devices:
        for dev in devices:
            if str(dev.get("ip") or "").strip() == ip:
                mac = normalize_mac(dev.get("mac"))
                if mac:
                    return mac
    return ""


def block_device(mac, name="", devices=None):
    mac = normalize_mac(mac)
    if not mac:
        raise RuntimeError("У устройства нет корректного MAC.")
    state = read_blocklist_state()
    own_mac = get_management_mac(devices=devices, state=state)
    if own_mac and own_mac == mac:
        raise RuntimeError("Это устройство управления. Его блокировка отменена.")
    if mac in state.get("black", []):
        return "✓ Устройство уже заблокировано"
    names = {mac: name} if name else None
    write_blocklist(state.get("black", []) + [mac], names=names, state=state)
    return "✓ Устройство заблокировано"


def unblock_device(mac):
    mac = normalize_mac(mac)
    if not mac:
        raise RuntimeError("Некорректный MAC.")
    state = read_blocklist_state()
    if mac not in state.get("black", []):
        return "✓ Устройство уже разблокировано"
    wanted = [m for m in state.get("black", []) if m != mac]
    write_blocklist(wanted, state=state)
    return "✓ Устройство разблокировано"


def clear_blocklist():
    state = read_blocklist_state()
    if not state.get("black"):
        return "Список блокировок уже пуст"
    count = len(state.get("black", []))
    write_blocklist([], state=state)
    return f"✓ Список блокировок очищен ({count})"


def temporary_disconnect_device(mac, name="", devices=None, hold_seconds=2.0):
    """Принудительно рвёт Wi-Fi-сессию, не оставляя MAC в blacklist.

    Реализовано как кратковременный DENY с обязательным восстановлением исходного
    списка в finally. Клиент после этого может подключиться снова автоматически.
    """
    mac = normalize_mac(mac)
    if not mac:
        raise RuntimeError("У устройства нет корректного MAC.")

    state = read_blocklist_state()
    original = list(state.get("black", []))
    if mac in original:
        raise RuntimeError("Устройство уже заблокировано. Сначала разблокируй его.")

    own_mac = get_management_mac(devices=devices, state=state)
    if own_mac and own_mac == mac:
        raise RuntimeError("Это устройство управления. Временное отключение отменено.")

    names = {mac: name} if name else None
    added = False
    cleanup_error = None
    try:
        write_blocklist(original + [mac], names=names, state=state)
        added = True
        time.sleep(max(0.8, float(hold_seconds)))
    finally:
        if added:
            try:
                # Читаем актуальное состояние перед возвратом, но восстанавливаем
                # именно исходный набор, чтобы временный MAC гарантированно исчез.
                current = read_blocklist_state()
                write_blocklist(original, state=current)
            except Exception as e:
                cleanup_error = e

    if cleanup_error:
        raise RuntimeError(
            "Клиент отключён, но не удалось автоматически убрать временный DENY: "
            + str(cleanup_error)
        )
    return "✓ Устройство временно отключено; блокировка снята"


def empty_info():
    return {
        "loginfo": "",
        "ppp_status": "",
        "network_provider": "?",
        "network_type": "?",
        "sub_network_type": "?",
        "battery_pers": "",
        "battery_vol_percent": "",
        "battery_charging": "",
        "nv_band": "?",
        "nv_bandwidth": "?",
        "nv_arfcn": "?",
        "nv_globecellid": "?",
        "nv_enodbid": "?",
        "nv_cellid": "?",
        "nv_pci": "?",
        "nv_rsrp": "",
        "nv_rsrq": "",
        "nv_sinr": "",
        "realtime_rx_thrpt": "",
        "realtime_tx_thrpt": "",
        "realtime_rx_bytes": "",
        "realtime_tx_bytes": "",
        "nv_rssi": "",
        "lte_rssi": "",
        "rssi": "",
        "wan_csq": "",
        "wifi_access_sta_num": "",
    }


def normalized_info(raw):
    info = empty_info()
    info.update(raw or {})

    rsrp = physical_rsrp(info.get("nv_rsrp"))
    rsrq = physical_rsrq(info.get("nv_rsrq"))
    sinr = physical_sinr(info.get("nv_sinr"))

    info["rsrp"] = rsrp
    info["rsrq"] = rsrq
    info["sinr"] = sinr
    info["rssi"] = physical_rssi(info, rsrp, rsrq)

    band = str(info.get("nv_band", "") or "")
    info["band"] = "?" if not band else (
        band if band.upper().startswith("B") else "B" + band
    )

    info["earfcn"] = val(info.get("nv_arfcn"))
    info["pci"] = val(info.get("nv_pci"))
    info["enb"] = val(info.get("nv_enodbid"))
    info["cell_id"] = val(info.get("nv_globecellid"))
    info["local_cell"] = val(info.get("nv_cellid"))
    info["plmn"] = val(info.get("network_provider"))
    info["bandwidth"] = format_bandwidth(info)
    info["battery"] = battery_percent(info)

    info["rank"] = normalize_scalar(first_nonempty(
        info,
        "nv_rank",
        "nv_rank_index",
        "rank",
        "rank_index",
        "ri",
        "lte_ri",
        "lte_rank",
    ))

    info["txpower"] = normalize_txpower(first_nonempty(
        info,
        "nv_txpower",
        "nv_tx_power",
        "txpower",
        "tx_power",
        "lte_txpower",
        "lte_tx_power",
    ))

    cqi0 = first_nonempty(
        info, "nv_cqi0", "cqi0", "tb0_cqi", "lte_cqi0"
    )
    cqi1 = first_nonempty(
        info, "nv_cqi1", "cqi1", "tb1_cqi", "lte_cqi1"
    )
    if cqi0 is None:
        a, b = split_pair(first_nonempty(
            info, "nv_cqi", "cqi", "lte_cqi"
        ))
        cqi0 = a
        if cqi1 is None:
            cqi1 = b

    info["cqi0"] = normalize_scalar(cqi0)
    info["cqi1"] = normalize_scalar(cqi1)

    info["ul_mcs"] = normalize_scalar(first_nonempty(
        info,
        "nv_ul_mcs",
        "ul_mcs",
        "lte_ul_mcs",
        "tb0_ul_mcs",
        "ul_mcs0",
    ))

    dl0 = first_nonempty(
        info,
        "nv_dl_mcs0",
        "dl_mcs0",
        "lte_dl_mcs0",
        "tb0_dl_mcs",
    )
    dl1 = first_nonempty(
        info,
        "nv_dl_mcs1",
        "dl_mcs1",
        "lte_dl_mcs1",
        "tb1_dl_mcs",
    )
    if dl0 is None:
        a, b = split_pair(first_nonempty(
            info, "nv_dl_mcs", "dl_mcs", "lte_dl_mcs"
        ))
        dl0 = a
        if dl1 is None:
            dl1 = b

    info["dl_mcs0"] = normalize_scalar(dl0)
    info["dl_mcs1"] = normalize_scalar(dl1)

    info["internet_connected"] = (
        info.get("ppp_status") == "ppp_connected"
    )
    info["authorized"] = info.get("loginfo") == "ok"
    return info


class SpeedTracker:
    def __init__(self):
        self.previous = None
        self.download_mb = "0 B/s"
        self.upload_mb = "0 B/s"

    def reset(self):
        self.previous = None
        self.download_mb = "0 B/s"
        self.upload_mb = "0 B/s"

    def update(self, raw):
        # Основной источник, native realtime_*_thrpt.
        dl = format_speed_human(raw.get("realtime_rx_thrpt"))
        ul = format_speed_human(raw.get("realtime_tx_thrpt"))

        now = time.monotonic()
        rx_total = safe_num(raw.get("realtime_rx_bytes"))
        tx_total = safe_num(raw.get("realtime_tx_bytes"))

        # Fallback по накопительным байтам, если throughput отсутствует.
        if (dl is None or ul is None) and self.previous is not None:
            dt = now - self.previous["time"]
            if dt > 0:
                if dl is None and rx_total is not None:
                    delta = rx_total - self.previous["rx"]
                    if delta >= 0:
                        dl = format_speed_human(delta / dt)
                if ul is None and tx_total is not None:
                    delta = tx_total - self.previous["tx"]
                    if delta >= 0:
                        ul = format_speed_human(delta / dt)

        if rx_total is not None and tx_total is not None:
            self.previous = {
                "time": now,
                "rx": rx_total,
                "tx": tx_total,
            }

        if dl is not None:
            self.download_mb = dl
        if ul is not None:
            self.upload_mb = ul

        return {
            "download_mb": self.download_mb,
            "upload_mb": self.upload_mb,
        }


class RawTerminal:
    def __init__(self):
        self.fd = None
        self.old = None
        self.active = False

    def enable(self):
        if self.active:
            return
        if not sys.stdin.isatty():
            raise RuntimeError("Live TUI требует обычную сессию Termux.")
        self.fd = sys.stdin.fileno()
        self.old = termios.tcgetattr(self.fd)
        tty.setcbreak(self.fd)
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()
        self.active = True

    def disable(self):
        if not self.active:
            return
        termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()
        self.active = False

    def read_key(self, timeout=0.05):
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return None
        return sys.stdin.read(1)




# ---------------------------------------------------------------------------
# Linux shell: per-device traffic + tc rate limiting
# ---------------------------------------------------------------------------

TELNET_HOST = "192.168.150.1"
TELNET_PORT = 4719
TELNET_USER = "admin"
TELNET_PASSWORD = "admin"
TRAFFIC_CHAIN = "AX8_MON"
TRAFFIC_CHAIN_V6 = "AX8_MON6"
ZERO_LIMIT_CHAIN = "AX8_ZERO"
ZERO_LIMIT_CHAIN_V6 = "AX8_ZERO6"
LIMITS_FILE = Path.home() / ".ax8_speed_limits.json"
WIFI_IFACE = "wlan0"
QOS_RUNTIME = {
    "ifaces": [WIFI_IFACE],
    "ipv6_monitor": False,
    "ipv6_qos": False,
    "ipv6_error": "",
}

# Temporary limits created by [P] OWNER PRIORITY.
# They are intentionally NOT written to LIMITS_FILE.  When priority is disabled
# the dictionary is cleared and the user's saved limits are reapplied.
PRIORITY_LIMIT_OVERRIDES = {}
PRIORITY_STATE_FILE = Path.home() / ".ax8_owner_priority.json"


def _load_priority_enabled():
    try:
        raw = json.loads(PRIORITY_STATE_FILE.read_text(encoding="utf-8"))
        return bool(raw.get("enabled", False)) if isinstance(raw, dict) else False
    except Exception:
        return False


def _save_priority_enabled(enabled):
    PRIORITY_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = PRIORITY_STATE_FILE.with_suffix(".tmp")
    tmp.write_text(
        json.dumps({"enabled": bool(enabled)}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    tmp.replace(PRIORITY_STATE_FILE)




class RouterShell:
    """Minimal Telnet client for the BusyBox shell inside AX8 Pro.

    The router exposes telnetd on port 4719 after toggling tw_telnet_config.
    We answer Telnet option negotiation conservatively and execute commands
    using unique end markers so TUI code can safely parse command output.
    """

    IAC = 255
    DONT = 254
    DO = 253
    WONT = 252
    WILL = 251
    SB = 250
    SE = 240

    def __init__(self):
        self.sock = None
        self.buffer = ""
        self._iac_pending = b""

    def close(self):
        if self.sock is not None:
            try:
                self.sock.close()
            except Exception:
                pass
        self.sock = None
        self.buffer = ""

    @staticmethod
    def _port_open(timeout=0.5):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        try:
            return s.connect_ex((TELNET_HOST, TELNET_PORT)) == 0
        finally:
            try:
                s.close()
            except Exception:
                pass

    @staticmethod
    def _restart_telnet():
        ensure_auth()
        http_post({
            "goformId": "tw_telnet_config",
            "telnetd_enable": "0",
            "debug_enable": "0",
        }, timeout=4)
        time.sleep(0.7)
        result = http_post({
            "goformId": "tw_telnet_config",
            "telnetd_enable": "1",
            "debug_enable": "0",
        }, timeout=4)
        if not _result_success(result):
            raise RuntimeError(f"Не удалось запустить Telnet: {result}")
        deadline = time.monotonic() + 4.0
        while time.monotonic() < deadline:
            if RouterShell._port_open(0.35):
                return
            time.sleep(0.2)
        raise RuntimeError("Telnet 4719 не открылся после перезапуска")

    def _send(self, data):
        if not self.sock:
            raise RuntimeError("Telnet не подключён")
        if isinstance(data, str):
            data = data.encode("utf-8")
        self.sock.sendall(data)

    def _strip_telnet(self, data):
        data = self._iac_pending + data
        self._iac_pending = b""
        out = bytearray()
        i = 0
        n = len(data)
        while i < n:
            b = data[i]
            if b != self.IAC:
                out.append(b)
                i += 1
                continue
            if i + 1 >= n:
                self._iac_pending = data[i:]
                break
            cmd = data[i + 1]
            if cmd == self.IAC:
                out.append(self.IAC)
                i += 2
                continue
            if cmd in (self.DO, self.DONT, self.WILL, self.WONT):
                if i + 2 >= n:
                    self._iac_pending = data[i:]
                    break
                opt = data[i + 2]
                try:
                    if cmd in (self.DO, self.DONT):
                        self._send(bytes((self.IAC, self.WONT, opt)))
                    else:
                        self._send(bytes((self.IAC, self.DONT, opt)))
                except Exception:
                    pass
                i += 3
                continue
            if cmd == self.SB:
                j = data.find(bytes((self.IAC, self.SE)), i + 2)
                if j < 0:
                    self._iac_pending = data[i:]
                    break
                i = j + 2
                continue
            i += 2
        return out.decode("utf-8", "replace")

    def _recv(self, timeout=1.0):
        if not self.sock:
            return ""
        self.sock.settimeout(timeout)
        try:
            raw = self.sock.recv(4096)
        except socket.timeout:
            return ""
        if not raw:
            raise ConnectionError("Telnet соединение закрыто роутером")
        return self._strip_telnet(raw)

    def _read_until(self, needles, timeout=5.0):
        if isinstance(needles, str):
            needles = [needles]
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            for needle in needles:
                if needle in self.buffer:
                    return self.buffer
            self.buffer += self._recv(min(0.6, max(0.1, deadline - time.monotonic())))
        raise TimeoutError("Telnet: таймаут ожидания " + "/".join(needles))

    def connect(self):
        self.close()
        if not self._port_open():
            self._restart_telnet()
        try:
            self.sock = socket.create_connection((TELNET_HOST, TELNET_PORT), timeout=3)
            self.sock.settimeout(1.0)
            self.buffer = ""
            self._read_until("login:", timeout=4)
            self._send(TELNET_USER + "\r\n")
            self.buffer = ""
            self._read_until("Password:", timeout=4)
            self._send(TELNET_PASSWORD + "\r\n")
            self.buffer = ""
            text = self._read_until(["~ #", "# "], timeout=5)
            if "Login incorrect" in text:
                raise RuntimeError("Telnet: неверный логин/пароль")
            self.buffer = ""
            return True
        except Exception:
            self.close()
            raise

    def ensure(self):
        if self.sock is None:
            self.connect()
        return self

    def exec(self, command, timeout=5.0):
        self.ensure()
        token = "__AX8_END_%d_%d__" % (os.getpid(), int(time.time() * 1000) % 10000000)
        payload = command.rstrip() + "\n" + f"echo {token}:$?" + "\n"
        try:
            self.buffer = ""
            self._send(payload)
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                self.buffer += self._recv(min(0.7, max(0.1, deadline - time.monotonic())))
                m = re.search(re.escape(token) + r":(\d+)", self.buffer)
                if m:
                    rc = int(m.group(1))
                    text = self.buffer[:m.start()]
                    # BusyBox tty echoes commands. Remove obvious echoed command/marker lines.
                    lines = text.replace("\r", "").split("\n")
                    cleaned = []
                    cmd_first = command.strip().split("\n", 1)[0].strip()
                    for line in lines:
                        st = line.strip()
                        if not st:
                            continue
                        if st == cmd_first or st.startswith("echo " + token):
                            continue
                        if st in ("~ #", "#"):
                            continue
                        cleaned.append(line)
                    self.buffer = ""
                    return "\n".join(cleaned).strip(), rc
            raise TimeoutError("Telnet command timeout")
        except Exception:
            self.close()
            raise


_ROUTER_SHELL = RouterShell()


def router_exec(command, timeout=5.0, retry=True):
    try:
        return _ROUTER_SHELL.exec(command, timeout=timeout)
    except Exception:
        if not retry:
            raise
        _ROUTER_SHELL.close()
        return _ROUTER_SHELL.exec(command, timeout=timeout)


def _load_limits():
    try:
        obj = json.loads(LIMITS_FILE.read_text(encoding="utf-8"))
        if not isinstance(obj, dict):
            return {}
        out = {}
        for mac, value in obj.items():
            mac = normalize_mac(mac)
            try:
                value = int(value)
            except Exception:
                continue
            if mac and value >= 0:
                out[mac] = value
        return out
    except Exception:
        return {}


def _save_limits(limits):
    LIMITS_FILE.write_text(
        json.dumps(dict(sorted(limits.items())), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _current_limit_for_device(dev):
    mac = normalize_mac(dev.get("mac"))
    return _load_limits().get(mac) if mac else None


LIMIT_PRESETS = {
    "0": 0,
    "1": 15,
    "2": 20,
    "3": 30,
    "4": 50,
    "5": 100,
    "6": 250,
    "7": 300,
    "8": 500,
    "9": 750,
    "a": 1000,
}


def format_limit_label(limit_kb):
    if limit_kb is None:
        return "БЕЗЛИМИТ"

    value = int(limit_kb)
    if value >= 1000:
        mb = value / 1000.0
        if mb.is_integer():
            return f"{int(mb)} MB/s"
        return f"{mb:.2f}".rstrip("0").rstrip(".") + " MB/s"

    return f"{value} KB/s"


def limit_label_color(limit_kb):
    if limit_kb is None:
        return GREEN
    if int(limit_kb) == 0:
        return RED
    return YELLOW


def _get_wifi_ifaces():
    """Discover Wi-Fi bridge ports instead of assuming wlan0 only."""
    candidates = []
    try:
        cmd = (
            'for d in /sys/class/net/br0/brif/*; do '
            '[ -e "$d" ] || continue; n=${d##*/}; '
            'case "$n" in wlan*|ra*|ath*|ap*) echo "$n";; esac; '
            'done'
        )
        out, rc = router_exec(cmd, timeout=3)
        if rc == 0:
            for line in out.splitlines():
                name = line.strip()
                if re.fullmatch(r"[A-Za-z0-9_.:-]+", name) and name not in candidates:
                    candidates.append(name)
    except Exception:
        pass

    if not candidates:
        candidates = [WIFI_IFACE]

    QOS_RUNTIME["ifaces"] = list(candidates)
    return candidates


def _ip6tables_available():
    try:
        _, rc = router_exec("ip6tables -L FORWARD -n >/dev/null 2>&1", timeout=3)
        return rc == 0
    except Exception:
        return False


def _restore_stock_wifi_qdisc(ifaces=None):
    """Remove only AX8-created qdiscs and restore pfifo_fast when appropriate."""
    ifaces = list(ifaces or _get_wifi_ifaces())
    for iface in ifaces:
        try:
            q, _ = router_exec(f"tc qdisc show dev {iface}", timeout=3)
        except Exception:
            continue
        if "htb 1:" in q:
            router_exec(f"tc qdisc del dev {iface} root 2>/dev/null", timeout=3)
        if "ingress ffff:" in q:
            router_exec(f"tc qdisc del dev {iface} ingress 2>/dev/null", timeout=3)
        try:
            q2, _ = router_exec(f"tc qdisc show dev {iface}", timeout=3)
            if "pfifo_fast" not in q2 and "htb 1:" not in q2:
                router_exec(f"tc qdisc add dev {iface} root pfifo_fast 2>/dev/null", timeout=3)
        except Exception:
            pass


def _apply_zero_limit_firewall(zero_devices):
    """0 KB/s for both IPv4 and IPv6 routed traffic."""
    ipv4s = set()
    ipv6s = set()

    for item in zero_devices or []:
        if isinstance(item, dict):
            ip4 = str(item.get("ip") or "").strip()
            ip6_list = item.get("ipv6") or []
        else:
            ip4 = str(item or "").strip()
            ip6_list = []

        if re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", ip4):
            ipv4s.add(ip4)
        for addr in ip6_list:
            norm = _normalize_ipv6(addr)
            if norm:
                ipv6s.add(norm)

    # IPv4 chain.
    cmd = (
        f"while iptables -D FORWARD -j {ZERO_LIMIT_CHAIN} 2>/dev/null; do :; done; "
        f"iptables -N {ZERO_LIMIT_CHAIN} 2>/dev/null; "
        f"iptables -F {ZERO_LIMIT_CHAIN}"
    )
    out, rc = router_exec(cmd, timeout=5)
    if rc != 0:
        raise RuntimeError("Не удалось подготовить IPv4 0 KB/s firewall: " + (out or str(rc))[:120])

    if ipv4s:
        out, rc = router_exec(f"iptables -I FORWARD 1 -j {ZERO_LIMIT_CHAIN}", timeout=4)
        if rc != 0:
            raise RuntimeError("Не удалось включить IPv4 0 KB/s firewall")
        for ip in sorted(ipv4s):
            out, rc = router_exec(
                f"iptables -A {ZERO_LIMIT_CHAIN} -s {ip}/32 -j DROP; "
                f"iptables -A {ZERO_LIMIT_CHAIN} -d {ip}/32 -j DROP",
                timeout=4,
            )
            if rc != 0:
                raise RuntimeError("Не удалось установить IPv4 0 KB/s для " + ip)
    else:
        router_exec(
            f"iptables -F {ZERO_LIMIT_CHAIN} 2>/dev/null; "
            f"iptables -X {ZERO_LIMIT_CHAIN} 2>/dev/null",
            timeout=4,
        )

    # IPv6 chain. If a client has routable IPv6, silently skipping this would
    # make 0 KB/s ineffective, so fail explicitly if ip6tables is unavailable.
    has_ip6 = bool(ipv6s)
    if has_ip6 and not _ip6tables_available():
        raise RuntimeError(
            "Устройство использует IPv6, но ip6tables недоступен. "
            "0 KB/s не может быть применён полностью."
        )

    if _ip6tables_available():
        router_exec(
            f"while ip6tables -D FORWARD -j {ZERO_LIMIT_CHAIN_V6} 2>/dev/null; do :; done; "
            f"ip6tables -N {ZERO_LIMIT_CHAIN_V6} 2>/dev/null; "
            f"ip6tables -F {ZERO_LIMIT_CHAIN_V6}",
            timeout=5,
        )
        if ipv6s:
            out, rc = router_exec(
                f"ip6tables -I FORWARD 1 -j {ZERO_LIMIT_CHAIN_V6}",
                timeout=4,
            )
            if rc != 0:
                raise RuntimeError("Не удалось включить IPv6 0 KB/s firewall")
            for addr in sorted(ipv6s):
                out, rc = router_exec(
                    f"ip6tables -A {ZERO_LIMIT_CHAIN_V6} -s {addr}/128 -j DROP; "
                    f"ip6tables -A {ZERO_LIMIT_CHAIN_V6} -d {addr}/128 -j DROP",
                    timeout=4,
                )
                if rc != 0:
                    raise RuntimeError("Не удалось установить IPv6 0 KB/s для " + addr)
        else:
            router_exec(
                f"ip6tables -F {ZERO_LIMIT_CHAIN_V6} 2>/dev/null; "
                f"ip6tables -X {ZERO_LIMIT_CHAIN_V6} 2>/dev/null",
                timeout=4,
            )

    return len(ipv4s), len(ipv6s)


def _effective_qos_signature(devices):
    """Stable signature of currently limited clients and all known IP addresses."""
    manual = _load_limits()
    rows = []

    for dev in devices or []:
        mac = normalize_mac(dev.get("mac"))
        if not mac:
            continue

        manual_limit = manual.get(mac)
        auto_limit = PRIORITY_LIMIT_OVERRIDES.get(mac)

        if manual_limit is None:
            effective = auto_limit
        elif auto_limit is None:
            effective = manual_limit
        else:
            effective = min(int(manual_limit), int(auto_limit))

        if effective is None:
            continue

        ip4 = str(dev.get("ip") or "").strip()
        ipv6s = tuple(sorted(
            addr for addr in (_normalize_ipv6(x) for x in (dev.get("ipv6") or []))
            if addr
        ))
        rows.append((mac, ip4, ipv6s, int(effective)))

    return tuple(sorted(rows))


def _apply_tc_limits(devices=None):
    """Rebuild persistent per-device limits for IPv4 + IPv6.

    Download:
      HTB/u32 on every discovered Wi-Fi bridge interface.

    Upload:
      ingress u32 police on every discovered Wi-Fi bridge interface.

    Manual limits remain MAC-based.  IPv4 and all known non-link-local IPv6
    addresses of that MAC receive the same effective limit.
    """
    if devices is None:
        devices = fetch_connected_devices(timeout=2.0)

    manual_limits = _load_limits()
    limits = dict(manual_limits)

    for raw_mac, raw_value in list(PRIORITY_LIMIT_OVERRIDES.items()):
        mac = normalize_mac(raw_mac)
        if not mac:
            continue
        try:
            value = max(0, int(raw_value))
        except Exception:
            continue
        if mac in limits:
            limits[mac] = min(int(limits[mac]), value)
        else:
            limits[mac] = value

    active = []
    for dev in devices:
        mac = normalize_mac(dev.get("mac"))
        ip4 = str(dev.get("ip") or "").strip()
        dtype = str(dev.get("type") or "").lower()
        if not mac or mac not in limits:
            continue
        if dtype and "wifi" not in dtype:
            continue

        ipv6s = []
        for addr in dev.get("ipv6") or []:
            norm = _normalize_ipv6(addr)
            if norm and norm not in ipv6s:
                ipv6s.append(norm)

        if not re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", ip4):
            ip4 = ""

        if not ip4 and not ipv6s:
            continue

        active.append({
            "mac": mac,
            "ip": ip4,
            "ipv6": ipv6s,
            "kb": int(limits[mac]),
        })

    zero_active = [d for d in active if d["kb"] == 0]
    positive_active = [d for d in active if d["kb"] > 0]

    _apply_zero_limit_firewall(zero_active)

    ifaces = _get_wifi_ifaces()

    # Protect unknown pre-existing qdisc configurations.
    for iface in ifaces:
        q, _ = router_exec(f"tc qdisc show dev {iface}", timeout=3)
        if q and "htb 1:" not in q and "pfifo_fast" not in q and positive_active:
            raise RuntimeError(
                f"На {iface} уже используется неизвестный root qdisc; менять его небезопасно"
            )

    for iface in ifaces:
        router_exec(f"tc qdisc del dev {iface} ingress 2>/dev/null", timeout=3)
        router_exec(f"tc qdisc del dev {iface} root 2>/dev/null", timeout=3)

    if not positive_active:
        for iface in ifaces:
            router_exec(f"tc qdisc add dev {iface} root pfifo_fast 2>/dev/null", timeout=3)
        QOS_RUNTIME["ipv6_qos"] = False
        QOS_RUNTIME["ipv6_error"] = ""
        return len(active)

    any_ipv6 = any(d["ipv6"] for d in positive_active)
    ipv6_filter_ok = True
    ipv6_error = ""

    try:
        for iface in ifaces:
            base_commands = [
                f"tc qdisc add dev {iface} root handle 1: htb default 999",
                f"tc class add dev {iface} parent 1: classid 1:999 htb rate 1000mbit ceil 1000mbit burst 64k cburst 64k",
                f"tc qdisc add dev {iface} handle ffff: ingress",
            ]
            for cmd in base_commands:
                out, rc = router_exec(cmd, timeout=4)
                if rc != 0:
                    raise RuntimeError((out or cmd)[:180])

            for idx, dev in enumerate(positive_active, 10):
                kbit = max(8, int(dev["kb"]) * 8)
                out, rc = router_exec(
                    f"tc class add dev {iface} parent 1: classid 1:{idx} "
                    f"htb rate {kbit}kbit ceil {kbit}kbit burst 32k cburst 32k",
                    timeout=4,
                )
                if rc != 0:
                    raise RuntimeError((out or f"tc class {iface} 1:{idx}")[:180])

                if dev["ip"]:
                    for cmd in (
                        f"tc filter add dev {iface} protocol ip parent 1: prio 1 u32 "
                        f"match ip dst {dev['ip']}/32 flowid 1:{idx}",
                        f"tc filter add dev {iface} parent ffff: protocol ip prio 1 u32 "
                        f"match ip src {dev['ip']}/32 police rate {kbit}kbit burst 32k drop flowid :1",
                    ):
                        out, rc = router_exec(cmd, timeout=4)
                        if rc != 0:
                            raise RuntimeError((out or cmd)[:180])

                for addr in dev["ipv6"]:
                    ipv6_cmds = (
                        f"tc filter add dev {iface} protocol ipv6 parent 1: prio 2 u32 "
                        f"match ip6 dst {addr}/128 flowid 1:{idx}",
                        f"tc filter add dev {iface} parent ffff: protocol ipv6 prio 2 u32 "
                        f"match ip6 src {addr}/128 police rate {kbit}kbit burst 32k drop flowid :1",
                    )
                    for cmd in ipv6_cmds:
                        out, rc = router_exec(cmd, timeout=4)
                        if rc != 0:
                            ipv6_filter_ok = False
                            ipv6_error = (out or cmd).replace("\n", " ")[:160]
                            raise RuntimeError(
                                "IPv6 tc-фильтр не поддержан/не применился: " + ipv6_error
                            )

    except Exception:
        _restore_stock_wifi_qdisc(ifaces)
        QOS_RUNTIME["ipv6_qos"] = False
        QOS_RUNTIME["ipv6_error"] = ipv6_error
        raise

    QOS_RUNTIME["ipv6_qos"] = bool(any_ipv6 and ipv6_filter_ok)
    QOS_RUNTIME["ipv6_error"] = ""
    return len(active)



def _set_limit_for_mac(mac, speed_kb_s):
    mac = normalize_mac(mac)
    if not mac:
        raise RuntimeError("У устройства нет MAC-адреса")
    speed = int(speed_kb_s)
    if speed < 0 or speed > 125000:
        raise RuntimeError("Лимит должен быть от 0 до 125000 KB/s")
    limits = _load_limits()
    limits[mac] = speed
    _save_limits(limits)
    try:
        devices = fetch_connected_devices(timeout=2.0)
        count = _apply_tc_limits(devices)
    except Exception:
        limits.pop(mac, None)
        _save_limits(limits)
        try:
            _apply_tc_limits(fetch_connected_devices(timeout=2.0))
        except Exception:
            pass
        raise
    return count


def _clear_limit_for_mac(mac):
    mac = normalize_mac(mac)
    limits = _load_limits()
    existed = bool(mac and mac in limits)
    if mac:
        limits.pop(mac, None)
    _save_limits(limits)
    _apply_tc_limits(fetch_connected_devices(timeout=2.0))
    return existed



PRIORITY_CAP_TIERS = [1000, 750, 500, 300, 250, 100, 50, 30, 20, 15]


class OwnerPriorityController:
    """Adaptive temporary throttling for every Wi-Fi client except the owner.

    The controller never edits LIMITS_FILE.  It only fills
    PRIORITY_LIMIT_OVERRIDES and asks the existing tc backend to rebuild the
    effective rules.  Disabling priority therefore restores the saved limits.

    Heuristic:
      * owner must actually be using the link;
      * if other clients consume the same direction and the owner's share drops
        below 60%, their temporary ceiling is tightened;
      * if the owner already receives >82%, the ceiling is gradually relaxed;
      * after several seconds of owner inactivity all temporary ceilings are
        removed automatically while the feature itself stays enabled.
    """

    OWNER_ACTIVE_BPS = 8_000.0
    OTHER_BUSY_BPS = 30_000.0
    TIGHTEN_SHARE = 0.60
    RELAX_SHARE = 0.82
    EVAL_INTERVAL = 2.5
    IDLE_RELEASE_SECONDS = 6.0

    def __init__(self):
        self.enabled = False
        self.owner_mac = ""
        self.owner_name = ""
        self.cap_kb = None
        self.mode = "ВЫКЛ"
        self.last_eval = 0.0
        self.idle_since = None
        self.good_samples = 0
        self.last_error = ""
        self.last_owner_bps = 0.0
        self.last_other_bps = 0.0
        self.last_direction = "DL"
        self.history = []

    def _log(self, text):
        entry = f"{time.strftime('%H:%M:%S')}  {text}"
        if self.history and self.history[-1] == entry:
            return
        self.history.append(entry)
        if len(self.history) > 8:
            self.history = self.history[-8:]

    def _resolve_owner(self, devices):
        if self.owner_mac:
            for dev in devices or []:
                if normalize_mac(dev.get("mac")) == self.owner_mac:
                    self.owner_name = _device_display_name(dev)
                    return self.owner_mac

        try:
            state = read_blocklist_state()
        except Exception:
            state = {}

        mac = get_management_mac(devices=devices, state=state)
        if mac:
            self.owner_mac = mac
            for dev in devices or []:
                if normalize_mac(dev.get("mac")) == mac:
                    self.owner_name = _device_display_name(dev)
                    break
        return self.owner_mac

    @staticmethod
    def _wifi_targets(devices, owner_mac):
        targets = []
        for dev in devices or []:
            mac = normalize_mac(dev.get("mac"))
            dtype = str(dev.get("type") or "").lower()
            ip = str(dev.get("ip") or "").strip()
            if not mac or mac == owner_mac:
                continue
            if dtype and "wifi" not in dtype:
                continue
            if not re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", ip):
                continue
            targets.append(mac)
        return list(dict.fromkeys(targets))

    @staticmethod
    def _lower_cap(current):
        if current is None:
            return None
        try:
            idx = PRIORITY_CAP_TIERS.index(int(current))
        except ValueError:
            # Find the first predefined tier strictly below the custom/current cap.
            for tier in PRIORITY_CAP_TIERS:
                if tier < int(current):
                    return tier
            return PRIORITY_CAP_TIERS[-1]
        if idx >= len(PRIORITY_CAP_TIERS) - 1:
            return PRIORITY_CAP_TIERS[-1]
        return PRIORITY_CAP_TIERS[idx + 1]

    @staticmethod
    def _higher_cap(current):
        if current is None:
            return None
        try:
            idx = PRIORITY_CAP_TIERS.index(int(current))
        except ValueError:
            for tier in reversed(PRIORITY_CAP_TIERS):
                if tier > int(current):
                    return tier
            return None
        if idx <= 0:
            return None
        return PRIORITY_CAP_TIERS[idx - 1]

    @staticmethod
    def _initial_cap_for_rate(other_max_bps):
        kb = max(0.0, float(other_max_bps)) / 1000.0
        for tier in PRIORITY_CAP_TIERS:
            if tier < kb:
                return tier
        return PRIORITY_CAP_TIERS[-1]

    def _apply_cap(self, devices, cap_kb):
        global PRIORITY_LIMIT_OVERRIDES

        owner = self._resolve_owner(devices)
        if not owner:
            self.mode = "ПОИСК ХОЗЯИНА"
            return False

        targets = self._wifi_targets(devices, owner)
        wanted = {}
        if cap_kb is not None:
            wanted = {mac: int(cap_kb) for mac in targets}

        if wanted == PRIORITY_LIMIT_OVERRIDES and self.cap_kb == cap_kb:
            return False

        previous = dict(PRIORITY_LIMIT_OVERRIDES)
        previous_cap = self.cap_kb
        PRIORITY_LIMIT_OVERRIDES.clear()
        PRIORITY_LIMIT_OVERRIDES.update(wanted)
        self.cap_kb = cap_kb

        try:
            _apply_tc_limits(devices)

            old_label = format_limit_label(previous_cap) if previous_cap is not None else "БЕЗ AUTO"
            new_label = format_limit_label(cap_kb) if cap_kb is not None else "БЕЗ AUTO"
            if old_label != new_label:
                self._log(f"{self.mode}: {old_label} -> {new_label}")
        except Exception:
            PRIORITY_LIMIT_OVERRIDES.clear()
            PRIORITY_LIMIT_OVERRIDES.update(previous)
            self.cap_kb = previous_cap
            try:
                _apply_tc_limits(devices)
            except Exception:
                pass
            raise

        return True

    def enable(self, devices, persist=True):
        self.enabled = True
        self.mode = "ОЖИДАНИЕ"
        self.last_error = ""
        self.last_eval = 0.0
        self.idle_since = None
        self.good_samples = 0

        if persist:
            _save_priority_enabled(True)

        self._resolve_owner(devices)
        who = self.owner_name or self.owner_mac or "поиск устройства"
        self._log(f"ВКЛ: хозяин = {who}")
        return self.status_message()

    def disable(self, devices=None, persist=True):
        global PRIORITY_LIMIT_OVERRIDES

        was_enabled = self.enabled or bool(PRIORITY_LIMIT_OVERRIDES)

        if persist:
            _save_priority_enabled(False)

        self.enabled = False
        self.mode = "ВЫКЛ"
        self.idle_since = None
        self.good_samples = 0
        self.last_error = ""

        PRIORITY_LIMIT_OVERRIDES.clear()
        self.cap_kb = None

        if was_enabled:
            try:
                _apply_tc_limits(devices)
                self._log("ВЫКЛ: восстановлены ручные лимиты")
            except Exception as e:
                self.last_error = str(e).replace("\n", " ")[:140]
                self._log("ОШИБКА восстановления ручных лимитов")
                return "✗ Приоритет выключен, но не удалось восстановить лимиты: " + self.last_error

        return "✓ Приоритет хозяина выключен, установленные лимиты восстановлены"

    def status_message(self):
        if not self.enabled:
            return "ПРИОРИТЕТ ХОЗЯИНА: ВЫКЛ"
        if not self.owner_mac:
            return "ПРИОРИТЕТ ХОЗЯИНА: ВКЛ [ПОИСК ХОЗЯИНА]"
        if self.cap_kb is None:
            return "ПРИОРИТЕТ ХОЗЯИНА: ВКЛ [ОЖИДАНИЕ]"
        return f"ПРИОРИТЕТ ХОЗЯИНА: ВКЛ [{format_limit_label(self.cap_kb)}]"

    def status(self):
        return {
            "enabled": self.enabled,
            "mode": self.mode,
            "cap_kb": self.cap_kb,
            "owner_mac": self.owner_mac,
            "owner_name": self.owner_name,
            "message": self.status_message(),
            "owner_bps": self.last_owner_bps,
            "other_bps": self.last_other_bps,
            "direction": self.last_direction,
            "error": self.last_error,
            "history": list(self.history),
        }

    def update(self, devices, traffic_tracker):
        if not self.enabled:
            return

        now = time.monotonic()
        if now - self.last_eval < self.EVAL_INTERVAL:
            return
        self.last_eval = now

        try:
            owner = self._resolve_owner(devices)
            if not owner:
                self.mode = "ПОИСК ХОЗЯИНА"
                return

            owner_dev = next(
                (d for d in devices if normalize_mac(d.get("mac")) == owner),
                None,
            )
            if not owner_dev:
                self.mode = "ХОЗЯИН НЕ В СЕТИ"
                if self.cap_kb is not None or PRIORITY_LIMIT_OVERRIDES:
                    self._apply_cap(devices, None)
                return

            owner_stat = traffic_tracker.stat_for_device(owner_dev)
            owner_dl = max(0.0, float(owner_stat.get("dl") or 0.0))
            owner_ul = max(0.0, float(owner_stat.get("ul") or 0.0))

            # Protect the direction the owner is using most right now.
            if owner_dl < self.OWNER_ACTIVE_BPS and owner_ul < self.OWNER_ACTIVE_BPS:
                direction = "dl"
                self.last_direction = "—"
            else:
                direction = "dl" if owner_dl >= owner_ul else "ul"
                self.last_direction = direction.upper()
            owner_rate = owner_dl if direction == "dl" else owner_ul

            other_rates = []
            for dev in devices:
                mac = normalize_mac(dev.get("mac"))
                if not mac or mac == owner:
                    continue
                stat = traffic_tracker.stat_for_device(dev)
                rate = max(0.0, float(stat.get(direction) or 0.0))
                other_rates.append(rate)

            other_total = sum(other_rates)
            other_max = max(other_rates) if other_rates else 0.0

            if self.last_direction != "—":
                self.last_direction = direction.upper()
            self.last_owner_bps = owner_rate
            self.last_other_bps = other_total

            # Owner is not requesting meaningful throughput.  After a short idle
            # grace period restore the manually configured limits.
            if owner_rate < self.OWNER_ACTIVE_BPS:
                if self.idle_since is None:
                    self.idle_since = now
                self.good_samples = 0
                self.mode = "ОЖИДАНИЕ"

                if (
                    self.cap_kb is not None
                    and now - self.idle_since >= self.IDLE_RELEASE_SECONDS
                ):
                    self._apply_cap(devices, None)
                else:
                    # Even with no cap, refresh target set if clients changed.
                    if self.cap_kb is not None:
                        self._apply_cap(devices, self.cap_kb)
                return

            self.idle_since = None

            # No competing traffic: gradually remove a stale priority cap.
            if other_total < self.OTHER_BUSY_BPS:
                self.mode = "СВОБОДНО"
                self.good_samples += 1
                if self.cap_kb is not None and self.good_samples >= 2:
                    self.good_samples = 0
                    self._apply_cap(devices, self._higher_cap(self.cap_kb))
                return

            total = owner_rate + other_total
            share = owner_rate / total if total > 0 else 1.0

            if share < self.TIGHTEN_SHARE:
                self.mode = "ЗАЩИТА"
                self.good_samples = 0

                if self.cap_kb is None:
                    next_cap = self._initial_cap_for_rate(other_max)
                else:
                    next_cap = self._lower_cap(self.cap_kb)

                self._apply_cap(devices, next_cap)
                return

            if share > self.RELAX_SHARE:
                self.mode = "ОСЛАБЛЕНИЕ"
                self.good_samples += 1
                if self.cap_kb is not None and self.good_samples >= 2:
                    self.good_samples = 0
                    self._apply_cap(devices, self._higher_cap(self.cap_kb))
                else:
                    # New/removed clients still need the current temporary cap.
                    if self.cap_kb is not None:
                        self._apply_cap(devices, self.cap_kb)
                return

            self.mode = "СТАБИЛЬНО"
            self.good_samples = 0
            if self.cap_kb is not None:
                self._apply_cap(devices, self.cap_kb)

        except Exception as e:
            self.last_error = str(e).replace("\n", " ")[:150]
            self.mode = "ОШИБКА"


class DeviceTrafficTracker:
    """Real per-device IPv4 + IPv6 throughput from router FORWARD counters."""

    def __init__(self):
        self.previous = {}
        self.last = {}
        self.ipv4s = tuple()
        self.ipv6s = tuple()
        self.initialized = False
        self.ipv6_supported = False
        self.last_error = ""

    @staticmethod
    def _fmt(value):
        return format_speed_human(value) or "--"

    @staticmethod
    def _device_key(dev):
        mac = normalize_mac(dev.get("mac"))
        if mac:
            return "mac:" + mac
        ip4 = str(dev.get("ip") or "").strip()
        return "ip:" + ip4

    def _configure_v4(self, ips):
        cmd = (
            f"iptables -t mangle -N {TRAFFIC_CHAIN} 2>/dev/null; "
            f"iptables -t mangle -F {TRAFFIC_CHAIN}; "
            f"while iptables -t mangle -D FORWARD -j {TRAFFIC_CHAIN} 2>/dev/null; do :; done; "
            f"iptables -t mangle -I FORWARD 1 -j {TRAFFIC_CHAIN}"
        )
        out, rc = router_exec(cmd, timeout=5)
        if rc != 0:
            raise RuntimeError("Не удалось создать IPv4 traffic monitor: " + (out or str(rc))[:120])

        for ip in ips:
            out, rc = router_exec(
                f"iptables -t mangle -A {TRAFFIC_CHAIN} -s {ip}/32 -j RETURN; "
                f"iptables -t mangle -A {TRAFFIC_CHAIN} -d {ip}/32 -j RETURN",
                timeout=4,
            )
            if rc != 0:
                raise RuntimeError("Не удалось добавить IPv4 счётчик " + ip)

    def _configure_v6(self, ips):
        self.ipv6_supported = _ip6tables_available()
        QOS_RUNTIME["ipv6_monitor"] = self.ipv6_supported
        if not self.ipv6_supported:
            return

        cmd = (
            f"ip6tables -t mangle -N {TRAFFIC_CHAIN_V6} 2>/dev/null; "
            f"ip6tables -t mangle -F {TRAFFIC_CHAIN_V6}; "
            f"while ip6tables -t mangle -D FORWARD -j {TRAFFIC_CHAIN_V6} 2>/dev/null; do :; done; "
            f"ip6tables -t mangle -I FORWARD 1 -j {TRAFFIC_CHAIN_V6}"
        )
        out, rc = router_exec(cmd, timeout=5)
        if rc != 0:
            self.ipv6_supported = False
            QOS_RUNTIME["ipv6_monitor"] = False
            return

        for addr in ips:
            out, rc = router_exec(
                f"ip6tables -t mangle -A {TRAFFIC_CHAIN_V6} -s {addr}/128 -j RETURN; "
                f"ip6tables -t mangle -A {TRAFFIC_CHAIN_V6} -d {addr}/128 -j RETURN",
                timeout=4,
            )
            if rc != 0:
                self.ipv6_supported = False
                QOS_RUNTIME["ipv6_monitor"] = False
                break

    def _configure(self, ipv4s, ipv6s):
        ipv4s = tuple(sorted(set(ipv4s)))
        ipv6s = tuple(sorted(set(ipv6s)))
        if self.initialized and ipv4s == self.ipv4s and ipv6s == self.ipv6s:
            return

        self._configure_v4(ipv4s)
        self._configure_v6(ipv6s)

        self.previous = {}
        self.last = {}
        self.ipv4s = ipv4s
        self.ipv6s = ipv6s
        self.initialized = True

    @staticmethod
    def _parse_counter_text(text, addresses):
        totals = {addr: {"ul": None, "dl": None} for addr in addresses}
        rgx = re.compile(
            r"^\s*(\d+)\s+(\d+)\s+RETURN\s+all\s+--\s+\*\s+\*\s+(\S+)\s+(\S+)",
            re.M,
        )
        for m in rgx.finditer(text or ""):
            byte_count = int(m.group(2))
            src = m.group(3).split("/", 1)[0]
            dst = m.group(4).split("/", 1)[0]
            if src in totals:
                totals[src]["ul"] = byte_count
            if dst in totals:
                totals[dst]["dl"] = byte_count
        return totals

    def _read_counters(self):
        text4, rc = router_exec(
            f"iptables -t mangle -L {TRAFFIC_CHAIN} -n -v -x",
            timeout=4,
        )
        if rc != 0:
            raise RuntimeError("Не удалось прочитать IPv4 traffic counters")

        totals4 = self._parse_counter_text(text4, self.ipv4s)
        totals6 = {addr: {"ul": None, "dl": None} for addr in self.ipv6s}

        if self.ipv6_supported and self.ipv6s:
            text6, rc6 = router_exec(
                f"ip6tables -t mangle -L {TRAFFIC_CHAIN_V6} -n -v -x",
                timeout=4,
            )
            if rc6 == 0:
                totals6 = self._parse_counter_text(text6, self.ipv6s)
            else:
                self.ipv6_supported = False
                QOS_RUNTIME["ipv6_monitor"] = False

        return totals4, totals6

    @staticmethod
    def _sum_direction(addresses, totals4, totals6, direction):
        values = []
        for addr in addresses:
            bucket = totals4.get(addr) if "." in addr else totals6.get(addr)
            if bucket and bucket.get(direction) is not None:
                values.append(int(bucket[direction]))
        return sum(values) if values else None

    def stat_for_device(self, dev):
        key = self._device_key(dev)
        return self.last.get(key, {})

    def update(self, devices):
        now = time.monotonic()
        ipv4s = []
        ipv6s = []
        limits = _load_limits()

        for dev in devices:
            ip4 = str(dev.get("ip") or "").strip()
            if re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", ip4):
                ipv4s.append(ip4)

            clean6 = []
            for addr in dev.get("ipv6") or []:
                norm = _normalize_ipv6(addr)
                if norm and norm not in clean6:
                    clean6.append(norm)
                    ipv6s.append(norm)
            dev["ipv6"] = clean6

            mac = normalize_mac(dev.get("mac"))
            dev["speed_limit_kb"] = limits.get(mac) if mac else None

        try:
            self._configure(ipv4s, ipv6s)
            totals4, totals6 = self._read_counters()

            for dev in devices:
                key = self._device_key(dev)
                addresses = []
                ip4 = str(dev.get("ip") or "").strip()
                if ip4 in self.ipv4s:
                    addresses.append(ip4)
                addresses.extend(dev.get("ipv6") or [])

                curr_dl = self._sum_direction(addresses, totals4, totals6, "dl")
                curr_ul = self._sum_direction(addresses, totals4, totals6, "ul")

                prev = self.previous.get(key)
                dl = ul = None
                if prev:
                    dt = now - prev["time"]
                    if dt > 0.15:
                        if curr_dl is not None and prev.get("dl") is not None and curr_dl >= prev["dl"]:
                            dl = (curr_dl - prev["dl"]) / dt
                        if curr_ul is not None and prev.get("ul") is not None and curr_ul >= prev["ul"]:
                            ul = (curr_ul - prev["ul"]) / dt

                self.previous[key] = {
                    "time": now,
                    "dl": curr_dl,
                    "ul": curr_ul,
                }

                old = self.last.get(key, {})
                if dl is not None:
                    old["dl"] = dl
                if ul is not None:
                    old["ul"] = ul
                self.last[key] = old

                # Backward-compatible aliases for code that still looks up IPv4.
                if ip4:
                    self.last[ip4] = old

                dev["_traffic_dl_bps"] = old.get("dl")
                dev["_traffic_ul_bps"] = old.get("ul")
                dev["download_speed"] = self._fmt(old.get("dl"))
                dev["upload_speed"] = self._fmt(old.get("ul"))

            self.last_error = ""

        except Exception as e:
            self.last_error = str(e).replace("\n", " ")[:150]
            self.initialized = False
            self.ipv4s = tuple()
            self.ipv6s = tuple()

            for dev in devices:
                key = self._device_key(dev)
                cached = self.last.get(key, {})
                dev["_traffic_dl_bps"] = cached.get("dl")
                dev["_traffic_ul_bps"] = cached.get("ul")
                dev["download_speed"] = self._fmt(cached.get("dl"))
                dev["upload_speed"] = self._fmt(cached.get("ul"))

        return devices

    def close(self):
        try:
            router_exec(
                f"while iptables -t mangle -D FORWARD -j {TRAFFIC_CHAIN} 2>/dev/null; do :; done; "
                f"iptables -t mangle -F {TRAFFIC_CHAIN} 2>/dev/null; "
                f"iptables -t mangle -X {TRAFFIC_CHAIN} 2>/dev/null",
                timeout=4,
            )
        except Exception:
            pass

        if _ip6tables_available():
            try:
                router_exec(
                    f"while ip6tables -t mangle -D FORWARD -j {TRAFFIC_CHAIN_V6} 2>/dev/null; do :; done; "
                    f"ip6tables -t mangle -F {TRAFFIC_CHAIN_V6} 2>/dev/null; "
                    f"ip6tables -t mangle -X {TRAFFIC_CHAIN_V6} 2>/dev/null",
                    timeout=4,
                )
            except Exception:
                pass

        self.initialized = False



def _rate_rule_for_ip(ip):
    try:
        devices = fetch_connected_devices(timeout=1.5)
        dev = next((d for d in devices if str(d.get("ip") or "") == str(ip)), None)
        if not dev:
            return None, None, {"backend": "linux-tc"}
        limit = _current_limit_for_device(dev)
        if limit is not None:
            backend = "linux-drop" if int(limit) == 0 else "linux-tc"
            return 0, f"AX8_{limit}KBs", {"backend": backend}
    except Exception:
        pass
    return None, None, {"backend": "linux-tc"}


def set_device_rate_limit(ip, speed_kb_s):
    ip = str(ip or "").strip()
    devices = fetch_connected_devices(timeout=2.0)
    target = next((d for d in devices if str(d.get("ip") or "") == ip), None)
    if not target:
        raise RuntimeError("Устройство с этим IPv4 сейчас не подключено")
    if "wifi" not in str(target.get("type") or "").lower():
        raise RuntimeError("Linux tc-лимит v13 сейчас поддерживает Wi-Fi устройства")

    # v13: разрешаем ограничивать даже устройство, с которого управляется AX8 Pro.
    # Важно: tc на wlan0 затрагивает также локальный трафик управления к этому клиенту,
    # поэтому при очень низком лимите WebUI/Telnet могут стать заметно медленнее.

    count = _set_limit_for_mac(target.get("mac"), speed_kb_s)
    label = format_limit_label(int(speed_kb_s))
    backend = "iptables/ip6tables DROP" if int(speed_kb_s) == 0 else "Linux tc IPv4+IPv6"
    return f"✓ Лимит {label} установлен ({backend}, устройств с лимитом: {count})"


def clear_device_rate_limit(ip):
    ip = str(ip or "").strip()
    devices = fetch_connected_devices(timeout=2.0)
    target = next((d for d in devices if str(d.get("ip") or "") == ip), None)
    if not target:
        raise RuntimeError("Устройство с этим IPv4 сейчас не подключено")
    existed = _clear_limit_for_mac(target.get("mac"))
    if existed:
        return "✓ Лимит снят, стандартный Wi-Fi qdisc восстановлен при отсутствии других лимитов"
    return "Лимит для этого устройства не был задан"


def _parse_rule_limit_kb(raw):
    if not raw:
        return None
    m = re.search(r"AX8_(\d+)KBs", str(raw))
    return int(m.group(1)) if m else None


def _parse_custom_limit_value(raw):
    """Parse a manually entered speed limit and return integer KB/s.

    Accepted examples:
      25
      25 KB/s
      750k
      1 MB/s
      1.5 MB/s
    """
    raw = str(raw or "").strip().lower().replace(",", ".")
    if not raw:
        return None

    compact = re.sub(r"\s+", "", raw)

    # Plain number means KB/s.
    m = re.fullmatch(r"(\d+(?:\.\d+)?)", compact)
    if m:
        value_kb = float(m.group(1))
    else:
        m = re.fullmatch(
            r"(\d+(?:\.\d+)?)(kb/s|kbyte/s|kbytes/s|kb|k|mb/s|mbyte/s|mbytes/s|mb|m)",
            compact,
        )
        if not m:
            raise ValueError("Формат: 25, 25 KB/s или 1.5 MB/s")

        value = float(m.group(1))
        unit = m.group(2)
        value_kb = value * 1000.0 if unit.startswith("m") else value

    value_kb = int(round(value_kb))
    if value_kb < 0 or value_kb > 125000:
        raise ValueError("Допустимый диапазон: 0..125000 KB/s")
    return value_kb


def _custom_limit_input(term, title):
    """Styled manual limit entry screen."""
    width = ui_width()
    line = ui_line(width)

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi(title, WHITE, True)}",
        ansi(line, GRAY),
        f" {ansi('ФОРМАТ', CYAN, True)}",
        " Без единицы значение считается в KB/s.",
        " Можно указывать KB/s или MB/s.",
        "",
        f" {ansi('ПРИМЕРЫ', CYAN, True)}",
        " 25",
        " 25 KB/s",
        " 1.5 MB/s",
        "",
        f" {ansi('ДИАПАЗОН', CYAN, True)}",
        " 0 .. 125000 KB/s",
        " 0 KB/s = блокировка интернет-трафика",
        "",
        f" {ansi('[ENTER]', YELLOW, True)} применить",
        f" Пустая строка = {ansi('ОТМЕНА', RED, True)}",
        ansi(line, GRAY),
    ]

    term.disable()
    try:
        sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
        sys.stdout.write(f" {ansi('ЛИМИТ:', CYAN, True)} ")
        sys.stdout.flush()
        raw = input()
    finally:
        term.enable()

    if not str(raw).strip():
        return None

    return _parse_custom_limit_value(raw)



def _render_limit_choices(out):
    out.extend([
        f" {ansi('[0]', CYAN, True)} 0 KB/s",
        f" {ansi('[1]', CYAN, True)} 15 KB/s",
        f" {ansi('[2]', CYAN, True)} 20 KB/s",
        f" {ansi('[3]', CYAN, True)} 30 KB/s",
        f" {ansi('[4]', CYAN, True)} 50 KB/s",
        f" {ansi('[5]', CYAN, True)} 100 KB/s",
        f" {ansi('[6]', CYAN, True)} 250 KB/s",
        f" {ansi('[7]', CYAN, True)} 300 KB/s",
        f" {ansi('[8]', CYAN, True)} 500 KB/s",
        f" {ansi('[9]', CYAN, True)} 750 KB/s",
        f" {ansi('[A]', CYAN, True)} 1 MB/s",
        f" {ansi('[C]', YELLOW, True)} ВВЕСТИ СВОЁ ЗНАЧЕНИЕ",
        f" {ansi('[F]', GREEN, True)} СНЯТЬ ЛИМИТ",
    ])


def render_rate_limit_menu(dev, message=""):
    width = ui_width()
    line = ui_line(width)
    ip = dev.get("ip") or "--"
    name = _device_display_name(dev)
    current = _current_limit_for_device(dev)
    label = format_limit_label(current)
    color = limit_label_color(current)

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('ЛИМИТ СКОРОСТИ / LINUX', WHITE, True)}",
        ansi(line, GRAY),
        f" DEVICE: {ansi(name, WHITE, True)} {ansi('[' + label + ']', color, True)}",
        f" IP:     {ip}",
        ansi(line, GRAY),
    ]
    _render_limit_choices(out)
    out.extend([
        f" {ansi('[R]', CYAN, True)} ОБНОВИТЬ   {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ])

    if message:
        msg_color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, msg_color, True))
    else:
        out.append(" [C] принимает KB/s или MB/s. 0 KB/s блокирует интернет-трафик.")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def rate_limit_menu(term, dev):
    ip = str(dev.get("ip") or "").strip()
    if not ip:
        return "✗ У устройства нет IPv4 для ограничения"

    message = ""
    while True:
        try:
            render_rate_limit_menu(dev, message)
        except Exception as e:
            message = "✗ " + str(e).replace("\n", " ")[:150]
            render_rate_limit_menu(dev, message)

        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key == "q":
            return message
        if key == "r":
            message = "Обновление…"
            continue
        if key == "f":
            try:
                message = clear_device_rate_limit(ip)
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:170]
            continue
        if key == "c":
            try:
                custom = _custom_limit_input(term, "СВОЙ ЛИМИТ УСТРОЙСТВА")
                if custom is None:
                    message = "Ввод лимита отменён."
                else:
                    message = set_device_rate_limit(ip, custom)
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:170]
            continue
        if key in LIMIT_PRESETS:
            try:
                message = set_device_rate_limit(ip, LIMIT_PRESETS[key])
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:170]
            continue


def _set_limit_for_all_except_management(speed_kb_s=None):
    """Set/clear the selected limit for all currently connected Wi-Fi clients except this controller."""
    devices = fetch_connected_devices(timeout=2.0)
    if not devices:
        raise RuntimeError("Подключённых устройств нет")

    state = read_blocklist_state()
    own_mac = get_management_mac(devices=devices, state=state)
    if not own_mac:
        raise RuntimeError(
            "Не удалось определить устройство управления. Массовый лимит отменён, чтобы не ограничить тебя."
        )

    targets = []
    for dev in devices:
        mac = normalize_mac(dev.get("mac"))
        dtype = str(dev.get("type") or "").lower()
        if not mac or mac == own_mac:
            continue
        if dtype and "wifi" not in dtype:
            continue
        targets.append(mac)

    targets = list(dict.fromkeys(targets))
    if not targets:
        return "Нет других устройств для изменения лимита"

    before = _load_limits()
    after = dict(before)

    if speed_kb_s is None:
        for mac in targets:
            after.pop(mac, None)
    else:
        speed = int(speed_kb_s)
        if speed < 0 or speed > 125000:
            raise RuntimeError("Некорректный лимит")
        for mac in targets:
            after[mac] = speed

    _save_limits(after)
    try:
        _apply_tc_limits(devices)
    except Exception:
        _save_limits(before)
        try:
            _apply_tc_limits(devices)
        except Exception:
            pass
        raise

    if speed_kb_s is None:
        return f"✓ Лимит снят у устройств: {len(targets)}; твоё устройство не изменено"

    return (
        f"✓ {format_limit_label(speed_kb_s)} установлено для устройств: {len(targets)}; "
        "твоё устройство не изменено"
    )


def render_all_rate_limit_menu(message=""):
    width = ui_width()
    line = ui_line(width)

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('ЛИМИТ ВСЕМ, КРОМЕ МЕНЯ', WHITE, True)}",
        ansi(line, GRAY),
        " Выбранное значение применяется ко всем подключённым Wi-Fi устройствам,",
        " кроме устройства, с которого сейчас выполняется управление AX8.",
        ansi(line, GRAY),
    ]
    _render_limit_choices(out)
    out.extend([
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ])

    if message:
        msg_color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, msg_color, True))
    else:
        out.append(" [C] свой лимит; [F] снимает лимит у всех остальных устройств.")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def all_devices_rate_limit_menu(term):
    message = ""
    while True:
        render_all_rate_limit_menu(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key == "q":
            return message
        if key == "f":
            try:
                message = _set_limit_for_all_except_management(None)
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:180]
            continue
        if key == "c":
            try:
                custom = _custom_limit_input(term, "СВОЙ ЛИМИТ ВСЕМ, КРОМЕ МЕНЯ")
                if custom is None:
                    message = "Ввод лимита отменён."
                else:
                    message = _set_limit_for_all_except_management(custom)
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:180]
            continue
        if key in LIMIT_PRESETS:
            try:
                message = _set_limit_for_all_except_management(LIMIT_PRESETS[key])
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:180]
            continue



def _device_display_name(dev):
    mac = normalize_mac(dev.get("mac"))
    alias = get_device_alias(mac)
    if alias:
        return alias

    name = clean_control_chars(dev.get("name")) or ""
    if name and name != "Без имени":
        return name
    if mac and mac in DEVICE_NAME_CACHE:
        return DEVICE_NAME_CACHE[mac]
    return "Без имени"



def temporary_disconnect_all_devices(devices, hold_seconds=2.0):
    """Временно отключает все подключённые клиентские устройства.

    Устройство, с которого выполняется управление AX8, намеренно не отключается:
    иначе клиент потеряет доступ к роутеру до того, как скрипт успеет восстановить
    исходный blacklist. Уже постоянные блокировки сохраняются без изменений.
    """
    devices = list(devices or [])
    if not devices:
        return "Подключённых устройств нет"

    state = read_blocklist_state()
    original = list(state.get("black", []))
    original_set = set(original)
    own_mac = get_management_mac(devices=devices, state=state)

    targets = []
    names = {}
    for dev in devices:
        mac = normalize_mac(dev.get("mac"))
        if not mac or mac in original_set:
            continue
        if own_mac and mac == own_mac:
            continue
        targets.append(mac)
        name = _device_display_name(dev)
        if name and name != "Без имени":
            names[mac] = name

    # Не дублируем MAC, сохраняя порядок списка устройств.
    targets = list(dict.fromkeys(targets))
    if not targets:
        if own_mac:
            return "Нет других устройств для отключения"
        return "Нет устройств для временного отключения"

    added = False
    cleanup_error = None
    try:
        write_blocklist(original + targets, names=names or None, state=state)
        added = True
        time.sleep(max(0.8, float(hold_seconds)))
    finally:
        if added:
            try:
                current = read_blocklist_state()
                write_blocklist(original, state=current)
            except Exception as e:
                cleanup_error = e

    if cleanup_error:
        raise RuntimeError(
            f"Отключено {len(targets)}, но не удалось полностью восстановить blacklist: "
            + str(cleanup_error)
        )

    suffix = ""
    if own_mac:
        suffix = "; устройство управления оставлено в сети"
    return f"✓ Временно отключено устройств: {len(targets)}{suffix}"

def render_devices_screen(devices, blocked, page=0, message="", page_size=None):
    width = ui_width()
    line = ui_line(width)
    if page_size is None:
        page_size = int(CUSTOM.get("device_page_size", 5))
    pages = max(1, (len(devices) + page_size - 1) // page_size)
    page = max(0, min(page, pages - 1))
    start = page * page_size
    visible = devices[start:start + page_size]

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('УСТРОЙСТВА', WHITE, True)}",
        ansi(line, GRAY),
        f" CONNECTED: {ansi(str(len(devices)), GREEN, True)}   "
        f"BLOCKED: {ansi(str(len(blocked)), RED if blocked else GREEN, True)}",
        ansi(line, GRAY),
    ]

    if not visible:
        out.append(" Подключённых устройств нет")
    else:
        for local_i, dev in enumerate(visible, 1):
            mac = normalize_mac(dev.get("mac")) or "--"
            name = _device_display_name(dev)
            is_blocked = mac in blocked
            icon = "✕" if is_blocked else "●"
            color = RED if is_blocked else GREEN
            ip = dev.get("ip") or "--"
            ctime = format_device_time(dev.get("time"))

            limit_kb = dev.get("speed_limit_kb")
            limit_text = format_limit_label(limit_kb)
            limit_color = limit_label_color(limit_kb)

            name_line = (
                f" {ansi('[' + str(local_i) + ']', CYAN, True)} "
                f"{ansi(icon + ' ' + name, color, True)}"
            )
            if CUSTOM.get("show_device_limit", True):
                name_line += " " + ansi("[" + limit_text + "]", limit_color, True)
            out.append(name_line)

            identity = []
            if CUSTOM.get("show_device_ip", True):
                identity.append(f"IP: {ip}")
            if CUSTOM.get("show_device_mac", True):
                identity.append(f"MAC: {mac}")
            if identity:
                out.append("     " + "   ".join(identity))

            if ctime and CUSTOM.get("show_device_time", True):
                out.append(f"     TIME: {ctime}")

            if CUSTOM.get("show_device_speed", True):
                out.append(
                    f"     DL: {ansi(dev.get('download_speed', '--'), WHITE, True)}"
                    f"   UL: {ansi(dev.get('upload_speed', '--'), WHITE, True)}"
                )

    out.append(ansi(line, GRAY))
    out.append(
        f" {ansi('[1-' + str(min(9, page_size)) + ']', CYAN, True)} ВЫБРАТЬ УСТРОЙСТВО"
    )
    out.append(f" {ansi('[B]', CYAN, True)} ЗАБЛОКИРОВАННЫЕ")
    out.append(f" {ansi('[K]', YELLOW, True)} ВРЕМЕННО ОТКЛЮЧИТЬ ВСЕХ")
    out.append(f" {ansi('[H]', CYAN, True)} ЛИМИТ ВСЕМ (КРОМЕ МЕНЯ)")
    out.append(f" {ansi('[O]', YELLOW, True)} ОЧИСТИТЬ СПИСОК БЛОКИРОВОК")
    if pages > 1:
        out.append(
            f" {ansi('[N]', CYAN, True)} ДАЛЕЕ   {page + 1}/{pages}   "
            f"{ansi('[P]', CYAN, True)} НАЗАД"
        )
    out.append(f" {ansi('[R]', CYAN, True)} ОБНОВИТЬ   {ansi('[Q]', RED, True)} В МЕНЮ")
    out.append(ansi(line, GRAY))

    if message:
        color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(f" UPDATED: {time.strftime('%H:%M:%S')}")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()
    return page


def render_device_detail(dev, blocked, message="", confirm_action=""):
    width = ui_width()
    line = ui_line(width)
    mac = normalize_mac(dev.get("mac")) or "--"
    name = _device_display_name(dev)
    connected = bool(dev.get("connected"))

    if blocked:
        status, color, icon = "ЗАБЛОКИРОВАНО", RED, "✕"
    elif connected:
        status, color, icon = "ПОДКЛЮЧЕНО", GREEN, "●"
    else:
        status, color, icon = "НЕ В СЕТИ", GRAY, "○"

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('УСТРОЙСТВО', WHITE, True)}",
        ansi(line, GRAY),
        (
            f" NAME:   {ansi(name, WHITE, True)} "
            + (
                ansi(
                    "[" + format_limit_label(dev.get("speed_limit_kb")) + "]",
                    limit_label_color(dev.get("speed_limit_kb")),
                    True,
                )
                if CUSTOM.get("show_device_limit", True)
                else ""
            )
        ),
        f" STATUS: {ansi(icon + ' ' + status, color, True)}",
    ]
    if CUSTOM.get("show_device_ip", True):
        out.append(f" IP:     {dev.get('ip') or '--'}")
    if CUSTOM.get("show_device_mac", True):
        out.append(f" MAC:    {mac}")
    ctime = format_device_time(dev.get("time"))
    if ctime and CUSTOM.get("show_device_time", True):
        out.append(f" TIME:   {ctime}")
    if CUSTOM.get("show_device_speed", True):
        out.append(
            f" SPEED:  DL {ansi(dev.get('download_speed', '--'), WHITE, True)}"
            f"   UL {ansi(dev.get('upload_speed', '--'), WHITE, True)}"
        )
    out.append(ansi(line, GRAY))
    if blocked:
        out.append(f" {ansi('[U]', GREEN, True)} РАЗБЛОКИРОВАТЬ")
    else:
        out.append(f" {ansi('[K]', YELLOW, True)} ВРЕМЕННО ОТКЛЮЧИТЬ")
        out.append(f" {ansi('[B]', RED, True)} ЗАБЛОКИРОВАТЬ")
        out.append(f" {ansi('[L]', CYAN, True)} ЛИМИТ СКОРОСТИ")
    out.append(f" {ansi('[E]', CYAN, True)} ИЗМЕНИТЬ ИМЯ")
    out.append(f" {ansi('[R]', CYAN, True)} ОБНОВИТЬ   {ansi('[Q]', RED, True)} НАЗАД")
    out.append(ansi(line, GRAY))

    if confirm_action == "block":
        out.append(" " + ansi("Нажми [B] ещё раз для подтверждения блокировки", YELLOW, True))
    elif confirm_action == "kick":
        out.append(" " + ansi("Нажми [K] ещё раз для временного отключения", YELLOW, True))
    elif message:
        color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(f" UPDATED: {time.strftime('%H:%M:%S')}")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def _edit_device_alias_input(term, dev):
    mac = normalize_mac(dev.get("mac"))
    if not mac:
        return "✗ У устройства нет MAC-адреса"

    current = _device_display_name(dev)
    term.disable()
    try:
        sys.stdout.write("\033[H\033[J")
        sys.stdout.write("AX8 PRO | ИМЯ УСТРОЙСТВА\n\n")
        sys.stdout.write(f"MAC: {mac}\n")
        sys.stdout.write(f"Текущее имя: {current}\n\n")
        sys.stdout.write(
            "Новое имя может быть длиннее лимита прошивки.\n"
            "Оно хранится локально в скрипте и привязано к MAC.\n\n"
            "Пустая строка = отмена\n"
            "-" + " = удалить локальное имя и вернуть имя роутера\n\n"
            "Новое имя: "
        )
        sys.stdout.flush()
        raw = input()
    finally:
        term.enable()

    if raw == "":
        return "Изменение имени отменено"
    if raw.strip() == "-":
        return set_device_alias(mac, "")

    name = clean_control_chars(raw).strip()
    if not name:
        return "Изменение имени отменено"
    return set_device_alias(mac, name)


def device_detail_menu(term, base_dev, traffic_tracker=None):
    current = dict(base_dev)
    mac = normalize_mac(current.get("mac"))
    if not mac:
        return "✗ У устройства нет MAC-адреса"

    message = ""
    confirm_action = ""
    confirm_until = 0.0
    last_refresh = 0.0
    blocked = False
    devices = [current]

    # Вход из [D] УСТРОЙСТВА использует тот же tracker, что и родительский экран.
    # Так detail-screen больше не уничтожает/пересоздаёт AX8_MON отдельно.
    owns_traffic_tracker = traffic_tracker is None
    if traffic_tracker is None:
        traffic_tracker = DeviceTrafficTracker()

    traffic_tracker.update(devices)

    while True:
        now = time.monotonic()
        if now - last_refresh >= 1.0:
            last_refresh = now
            try:
                devices = fetch_connected_devices(timeout=1.5)
                traffic_tracker.update(devices)
                match = next((d for d in devices if normalize_mac(d.get("mac")) == mac), None)
                if match:
                    current = match
                else:
                    current["connected"] = False
                    current["ip"] = current.get("ip") or ""
                state = read_blocklist_state()
                blocked = mac in set(state.get("black", []))
                if message.startswith("✗ Нет связи"):
                    message = ""
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]

        if confirm_until <= now:
            confirm_action = ""

        render_device_detail(current, blocked, message, confirm_action)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key in ("q", "0"):
            if owns_traffic_tracker:
                traffic_tracker.close()
            return message
        if key == "r":
            last_refresh = 0.0
            message = "Обновление…"
            confirm_action = ""
            continue

        if key == "e":
            confirm_action = ""
            confirm_until = 0.0
            try:
                message = _edit_device_alias_input(term, current)
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:180]
            continue

        if key == "u" and blocked:
            confirm_action = ""
            try:
                message = unblock_device(mac)
                blocked = False
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]
            continue

        if key == "b" and not blocked:
            if confirm_action != "block" or confirm_until <= now:
                confirm_action = "block"
                confirm_until = now + 3.0
                message = ""
                continue
            confirm_action = ""
            confirm_until = 0.0
            try:
                message = block_device(
                    mac,
                    name=_device_display_name(current),
                    devices=devices,
                )
                blocked = True
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]
            continue

        if key == "l" and not blocked:
            confirm_action = ""
            confirm_until = 0.0
            message = rate_limit_menu(term, current) or ""
            last_refresh = 0.0
            continue

        if key == "k" and not blocked:
            if confirm_action != "kick" or confirm_until <= now:
                confirm_action = "kick"
                confirm_until = now + 3.0
                message = ""
                continue
            confirm_action = ""
            confirm_until = 0.0
            try:
                render_device_detail(current, blocked, "Временное отключение…")
                message = temporary_disconnect_device(
                    mac,
                    name=_device_display_name(current),
                    devices=devices,
                    hold_seconds=2.0,
                )
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]
            continue


def render_blocked_screen(blocked_macs, page=0, message="", page_size=8):
    width = ui_width()
    line = ui_line(width)
    pages = max(1, (len(blocked_macs) + page_size - 1) // page_size)
    page = max(0, min(page, pages - 1))
    start = page * page_size
    visible = blocked_macs[start:start + page_size]

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('ЗАБЛОКИРОВАННЫЕ', WHITE, True)}",
        ansi(line, GRAY),
        f" BLOCKED: {ansi(str(len(blocked_macs)), RED if blocked_macs else GREEN, True)}",
        ansi(line, GRAY),
    ]

    if not visible:
        out.append(" Список блокировок пуст")
    else:
        for local_i, mac in enumerate(visible, 1):
            name = get_device_alias(mac) or DEVICE_NAME_CACHE.get(mac, "Без имени")
            out.append(
                f" {ansi('[' + str(local_i) + ']', CYAN, True)} "
                f"{ansi('✕ ' + name, RED, True)}"
            )
            out.append(f"     {mac}")

    out.append(ansi(line, GRAY))
    if visible:
        out.append(f" {ansi('[1-8]', CYAN, True)} ОТКРЫТЬ")
    out.append(f" {ansi('[O]', YELLOW, True)} ОЧИСТИТЬ ВСЕ БЛОКИРОВКИ")
    if pages > 1:
        out.append(
            f" {ansi('[N]', CYAN, True)} ДАЛЕЕ   {page + 1}/{pages}   "
            f"{ansi('[P]', CYAN, True)} НАЗАД"
        )
    out.append(f" {ansi('[R]', CYAN, True)} ОБНОВИТЬ   {ansi('[Q]', RED, True)} НАЗАД")
    out.append(ansi(line, GRAY))

    if message:
        color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(f" UPDATED: {time.strftime('%H:%M:%S')}")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()
    return page


def blocked_devices_menu(term, traffic_tracker=None):
    blocked_macs = []
    page = 0
    message = ""
    last_refresh = 0.0
    clear_confirm_until = 0.0

    while True:
        now = time.monotonic()
        if now - last_refresh >= 1.0:
            last_refresh = now
            try:
                state = read_blocklist_state()
                blocked_macs = list(state.get("black", []))
                page = min(page, max(0, (len(blocked_macs) - 1) // 8))
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]

        display_message = message
        if clear_confirm_until > now:
            display_message = "Нажми [O] ещё раз, чтобы снять ВСЕ блокировки"

        page = render_blocked_screen(blocked_macs, page, display_message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key in ("q", "0"):
            return message
        if key == "r":
            last_refresh = 0.0
            message = "Обновление…"
            clear_confirm_until = 0.0
            continue
        if key == "n":
            page = min(page + 1, max(0, (len(blocked_macs) - 1) // 8))
            clear_confirm_until = 0.0
            continue
        if key == "p":
            page = max(0, page - 1)
            clear_confirm_until = 0.0
            continue

        if key == "o":
            if not blocked_macs:
                message = "Список блокировок уже пуст"
                clear_confirm_until = 0.0
                continue
            if clear_confirm_until <= now:
                clear_confirm_until = now + 3.0
                message = ""
                continue
            clear_confirm_until = 0.0
            try:
                message = clear_blocklist()
                blocked_macs = []
                page = 0
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]
            continue

        if key.isdigit() and key != "0":
            idx = page * 8 + int(key) - 1
            if 0 <= idx < len(blocked_macs) and 1 <= int(key) <= 8:
                mac = blocked_macs[idx]
                base = {
                    "name": get_device_alias(mac) or DEVICE_NAME_CACHE.get(mac, "Без имени"),
                    "ip": "",
                    "mac": mac,
                    "type": "?",
                    "time": "",
                    "connected": False,
                }
                message = device_detail_menu(
                    term,
                    base,
                    traffic_tracker=traffic_tracker,
                ) or ""
                last_refresh = 0.0
                clear_confirm_until = 0.0


def devices_menu(term, traffic_tracker=None):
    devices = []
    blocked = set()
    page = 0
    message = "Загрузка устройств…"
    last_refresh = 0.0
    clear_confirm_until = 0.0
    kick_all_confirm_until = 0.0
    owns_traffic_tracker = traffic_tracker is None
    if traffic_tracker is None:
        traffic_tracker = DeviceTrafficTracker()
    last_limit_signature = None

    while True:
        now = time.monotonic()
        if now - last_refresh >= 1.0:
            last_refresh = now
            try:
                devices = fetch_connected_devices(timeout=1.5)
                traffic_tracker.update(devices)

                # Reapply QoS after router reboot, DHCP changes, IPv6 privacy
                # address rotation, or Priority AUTO changes.
                signature = _effective_qos_signature(devices)
                if signature != last_limit_signature:
                    if signature or _load_limits() or PRIORITY_LIMIT_OVERRIDES:
                        _apply_tc_limits(devices)
                    last_limit_signature = signature

                state = read_blocklist_state()
                blocked = set(state.get("black", []))
                page_size = int(CUSTOM.get("device_page_size", 5))
                page = min(page, max(0, (len(devices) - 1) // page_size))
                if message == "Загрузка устройств…" or message == "Обновление…":
                    message = ""
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]

        display_message = message
        if kick_all_confirm_until > now:
            display_message = "Нажми [K] ещё раз, чтобы временно отключить всех остальных"
        elif clear_confirm_until > now:
            display_message = "Нажми [O] ещё раз, чтобы снять ВСЕ блокировки"

        page = render_devices_screen(devices, blocked, page, display_message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key in ("q", "0"):
            if owns_traffic_tracker:
                traffic_tracker.close()
            return message
        if key == "r":
            last_refresh = 0.0
            message = "Обновление…"
            clear_confirm_until = 0.0
            kick_all_confirm_until = 0.0
            continue
        if key == "b":
            message = blocked_devices_menu(
                term,
                traffic_tracker=traffic_tracker,
            ) or ""
            last_refresh = 0.0
            clear_confirm_until = 0.0
            kick_all_confirm_until = 0.0
            continue
        if key == "h":
            message = all_devices_rate_limit_menu(term) or ""
            last_refresh = 0.0
            last_limit_signature = None
            clear_confirm_until = 0.0
            kick_all_confirm_until = 0.0
            continue
        if key == "n":
            page_size = int(CUSTOM.get("device_page_size", 5))
            page = min(page + 1, max(0, (len(devices) - 1) // page_size))
            clear_confirm_until = 0.0
            kick_all_confirm_until = 0.0
            continue
        if key == "p":
            page = max(0, page - 1)
            clear_confirm_until = 0.0
            kick_all_confirm_until = 0.0
            continue

        if key == "k":
            if len(devices) <= 1:
                message = "Нет других устройств для отключения"
                kick_all_confirm_until = 0.0
                clear_confirm_until = 0.0
                continue
            if kick_all_confirm_until <= now:
                kick_all_confirm_until = now + 3.0
                clear_confirm_until = 0.0
                message = ""
                continue
            kick_all_confirm_until = 0.0
            clear_confirm_until = 0.0
            try:
                message = temporary_disconnect_all_devices(devices, hold_seconds=2.0)
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:170]
            continue

        if key == "o":
            kick_all_confirm_until = 0.0
            if not blocked:
                message = "Список блокировок уже пуст"
                clear_confirm_until = 0.0
                continue
            if clear_confirm_until <= now:
                clear_confirm_until = now + 3.0
                message = ""
                continue
            clear_confirm_until = 0.0
            try:
                message = clear_blocklist()
                blocked = set()
                last_refresh = 0.0
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:150]
            continue

        page_size = int(CUSTOM.get("device_page_size", 5))
        if key in tuple(str(i) for i in range(1, page_size + 1)):
            idx = page * page_size + int(key) - 1
            if 0 <= idx < len(devices):
                message = device_detail_menu(
                    term,
                    devices[idx],
                    traffic_tracker=traffic_tracker,
                ) or ""
                last_refresh = 0.0
                clear_confirm_until = 0.0
                kick_all_confirm_until = 0.0



def _effective_limit_for_monitor(mac, manual_limits):
    mac = normalize_mac(mac)
    manual = manual_limits.get(mac)
    auto = PRIORITY_LIMIT_OVERRIDES.get(mac)

    if manual is None:
        effective = auto
    elif auto is None:
        effective = manual
    else:
        effective = min(int(manual), int(auto))

    return manual, auto, effective


def render_owner_priority_monitor(controller, devices, traffic_tracker, message=""):
    width = ui_width()
    line = ui_line(width)
    status = controller.status()

    enabled = bool(status.get("enabled"))
    status_color = GREEN if enabled else RED
    state_text = "ВКЛ" if enabled else "ВЫКЛ"
    owner_mac = normalize_mac(status.get("owner_mac"))
    owner_name = status.get("owner_name") or owner_mac or "НЕ ОПРЕДЕЛЁН"

    owner_bps = max(0.0, float(status.get("owner_bps") or 0.0))
    other_bps = max(0.0, float(status.get("other_bps") or 0.0))
    total = owner_bps + other_bps
    mode = str(status.get("mode") or "?")
    if mode == "ОЖИДАНИЕ" or owner_bps < OwnerPriorityController.OWNER_ACTIVE_BPS:
        share = None
    else:
        share = (owner_bps / total * 100.0) if total > 0 else None

    cap_kb = status.get("cap_kb")
    cap_text = format_limit_label(cap_kb) if cap_kb is not None else "НЕТ"
    cap_color = YELLOW if cap_kb is not None else GREEN

    mode_color = (
        RED if mode == "ОШИБКА"
        else YELLOW if mode in ("ЗАЩИТА", "ПОИСК ХОЗЯИНА", "ХОЗЯИН НЕ В СЕТИ")
        else GREEN if mode in ("СВОБОДНО", "СТАБИЛЬНО", "ОСЛАБЛЕНИЕ")
        else CYAN
    )

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('МОНИТОР ПРИОРИТЕТА ХОЗЯИНА', WHITE, True)}",
        ansi(line, GRAY),
        f" STATUS:     {ansi(state_text, status_color, True)}",
        f" MODE:       {ansi(mode, mode_color, True)}",
        f" OWNER:      {ansi(owner_name, GREEN if owner_mac else YELLOW, True)}",
        f" DIRECTION:  {ansi(str(status.get('direction') or '?'), CYAN, True)}",
        f" OWNER RATE: {ansi(format_speed_human(owner_bps) or '0 B/s', WHITE, True)}",
        f" OTHERS:     {ansi(format_speed_human(other_bps) or '0 B/s', WHITE, True)}",
        (
            f" OWNER SHARE: "
            + (
                ansi(
                    f"{share:.1f}%",
                    GREEN if share >= 60 else YELLOW if share >= 40 else RED,
                    True,
                )
                if share is not None
                else ansi("—", GRAY, True)
            )
        ),
        f" AUTO LIMIT: {ansi(cap_text if cap_kb is not None else ('ОЖИДАНИЕ' if enabled else 'НЕТ'), cap_color if cap_kb is not None else GRAY, True)}",
        f" STACK:      {ansi('IPv4 + IPv6' if traffic_tracker.ipv6_supported else 'IPv4', GREEN if traffic_tracker.ipv6_supported else YELLOW, True)}",
        f" QOS IFACE:  {ansi(', '.join(QOS_RUNTIME.get('ifaces') or [WIFI_IFACE]), CYAN, True)}",
        ansi(line, GRAY),
        ansi(" УСТРОЙСТВА", CYAN, True),
    ]

    manual_limits = _load_limits()

    ordered = sorted(
        devices or [],
        key=lambda d: (
            0 if normalize_mac(d.get("mac")) == owner_mac else 1,
            (_device_display_name(d) or "").lower(),
        )
    )

    if not ordered:
        out.append(" Нет данных об устройствах.")
    else:
        for dev in ordered[:6]:
            mac = normalize_mac(dev.get("mac"))
            ip = str(dev.get("ip") or "").strip()
            name = _device_display_name(dev)
            stat = traffic_tracker.stat_for_device(dev)
            dl = format_speed_human(stat.get("dl")) or "--"
            ul = format_speed_human(stat.get("ul")) or "--"

            if mac == owner_mac:
                out.append(
                    f" {ansi('●', GREEN, True)} {ansi(name, GREEN, True)} "
                    f"{ansi('[ХОЗЯИН]', GREEN, True)}"
                )
                out.append(f"    DL: {dl}   UL: {ul}")
                if dev.get("ipv6"):
                    out.append(f"    IPv6: {len(dev.get('ipv6') or [])} адрес(а)")
                continue

            manual, auto, effective = _effective_limit_for_monitor(mac, manual_limits)

            manual_text = format_limit_label(manual)
            auto_text = format_limit_label(auto) if auto is not None else "НЕТ"
            effective_text = format_limit_label(effective)

            out.append(f" {ansi('●', CYAN, True)} {ansi(name, WHITE, True)}")
            addr_suffix = f"   IPv6: {len(dev.get('ipv6') or [])}" if dev.get("ipv6") else ""
            out.append(
                f"    DL: {dl}   UL: {ul}{addr_suffix}"
            )
            out.append(
                f"    РУЧНОЙ: {manual_text}   AUTO: {auto_text}   "
                f"ИТОГ: {ansi(effective_text, YELLOW if auto is not None else GREEN, True)}"
            )

    out.append(ansi(line, GRAY))
    out.append(ansi(" ПОСЛЕДНИЕ ДЕЙСТВИЯ", CYAN, True))

    history = list(status.get("history") or [])
    if history:
        for item in history[-int(CUSTOM.get("priority_history_count", 5)):]:
            out.append(" " + item)
    else:
        out.append(" Пока действий нет.")

    if status.get("error"):
        out.append(" " + ansi("ОШИБКА PRIORITY: " + str(status["error"]), RED, True))
    if QOS_RUNTIME.get("ipv6_error"):
        out.append(" " + ansi("ОШИБКА IPv6 QOS: " + str(QOS_RUNTIME["ipv6_error"]), RED, True))
    if traffic_tracker.last_error:
        out.append(" " + ansi("ОШИБКА TRAFFIC: " + str(traffic_tracker.last_error), RED, True))

    out.append(ansi(line, GRAY))
    out.append(
        f" {ansi('[P]', GREEN if enabled else RED, True)} "
        f"{'ВЫКЛЮЧИТЬ' if enabled else 'ВКЛЮЧИТЬ'} ПРИОРИТЕТ"
        f"   {ansi('[R]', CYAN, True)} ОБНОВИТЬ"
        f"   {ansi('[Q]', RED, True)} НАЗАД"
    )

    if message:
        color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(
            " AUTO временно меняет только эффективный лимит. "
            "Сохранённые ручные лимиты не переписываются."
        )

    out.append("")
    out.append(" UPDATED: " + time.strftime("%H:%M:%S"))

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def owner_priority_monitor_menu(term, controller, traffic_tracker):
    message = ""
    devices = []
    next_refresh = 0.0

    while True:
        now = time.monotonic()

        if now >= next_refresh:
            try:
                devices = fetch_connected_devices(timeout=1.5)
                traffic_tracker.update(devices)
                controller.update(devices, traffic_tracker)
                if message.startswith("✗ Обновление"):
                    message = ""
            except Exception as e:
                message = "✗ Обновление: " + str(e).replace("\n", " ")[:140]

            next_refresh = now + float(CUSTOM.get("device_refresh", 1.0))

        render_owner_priority_monitor(
            controller,
            devices,
            traffic_tracker,
            message,
        )

        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key in ("q", "0"):
            return message

        if key == "r":
            next_refresh = 0.0
            message = "Обновление…"
            continue

        if key == "p":
            try:
                if controller.enabled:
                    message = controller.disable(devices or None)
                else:
                    if not devices:
                        devices = fetch_connected_devices(timeout=2.0)
                        traffic_tracker.update(devices)
                    controller.enable(devices)
                    who = controller.owner_name or controller.owner_mac
                    if who:
                        message = f"✓ Приоритет включен: {who}"
                    else:
                        message = "✓ Приоритет включен, определяю хозяина…"
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:160]

            next_refresh = 0.0
            continue



def _custom_status_line(label, value, color=WHITE):
    return f" {label:<28} {ansi(str(value), color, True)}"


def render_customization_root(message=""):
    width = ui_width()
    line = ui_line(width)
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('КАСТОМИЗАЦИЯ', WHITE, True)}",
        ansi(line, GRAY),
        _custom_status_line("Файл настроек:", "~/.ax8_customization.json", GRAY),
        _custom_status_line("Тема:", str(CUSTOM.get("accent")).upper(), CYAN),
        _custom_status_line("Название:", ui_title(), WHITE),
        _custom_status_line(
            "Priority после рестарта:",
            "ВКЛ" if _load_priority_enabled() else "ВЫКЛ",
            GREEN if _load_priority_enabled() else RED,
        ),
        ansi(line, GRAY),
        f" {ansi('[1]', CYAN, True)} ТЕМА И ВНЕШНИЙ ВИД",
        f" {ansi('[2]', CYAN, True)} ГЛАВНЫЙ ЭКРАН",
        f" {ansi('[3]', CYAN, True)} УСТРОЙСТВА",
        f" {ansi('[4]', CYAN, True)} SMS И МОНИТОР",
        f" {ansi('[5]', CYAN, True)} ОБНОВЛЕНИЕ И СКОРОСТЬ",
        f" {ansi('[6]', YELLOW, True)} СБРОСИТЬ ВСЁ К СТАНДАРТУ",
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ]
    if message:
        color = GREEN if message.startswith("✓") else RED if message.startswith("✗") else YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(" Настройки сохраняются автоматически и применяются сразу.")
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def render_custom_theme_menu(message=""):
    width = ui_width()
    line = ui_line(width)
    sep_names = {"thin": "ТОНКАЯ", "double": "ДВОЙНАЯ", "ascii": "ASCII", "dots": "ТОЧКИ"}
    width_value = "AUTO" if int(CUSTOM.get("max_width", 78)) == 0 else str(CUSTOM.get("max_width"))
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('ТЕМА И ВНЕШНИЙ ВИД', WHITE, True)}",
        ansi(line, GRAY),
        f" {ansi('[1]', CYAN, True)} АКЦЕНТ: {ansi(str(CUSTOM.get('accent')).upper(), CYAN, True)}",
        f" {ansi('[2]', CYAN, True)} РАЗДЕЛИТЕЛЬ: {sep_names.get(CUSTOM.get('separator'), '?')}",
        f" {ansi('[3]', CYAN, True)} ШИРИНА: {width_value}",
        f" {ansi('[4]', CYAN, True)} ЖИРНЫЙ ТЕКСТ: {ansi(ui_on(CUSTOM.get('bold')), ui_bool_color(CUSTOM.get('bold')), True)}",
        f" {ansi('[5]', CYAN, True)} КОМПАКТНЫЙ РЕЖИМ: {ansi(ui_on(CUSTOM.get('compact')), ui_bool_color(CUSTOM.get('compact')), True)}",
        f" {ansi('[6]', CYAN, True)} ЦВЕТА СИГНАЛА: {ansi(ui_on(CUSTOM.get('signal_colors')), ui_bool_color(CUSTOM.get('signal_colors')), True)}",
        f" {ansi('[7]', CYAN, True)} ЦВЕТА БАТАРЕИ: {ansi(ui_on(CUSTOM.get('battery_colors')), ui_bool_color(CUSTOM.get('battery_colors')), True)}",
        f" {ansi('[8]', CYAN, True)} ЗЕЛЁНЫЙ BAT ОТ: {CUSTOM.get('battery_green_min')}%",
        f" {ansi('[9]', CYAN, True)} ЖЁЛТЫЙ BAT ОТ: {CUSTOM.get('battery_yellow_min')}%",
        f" {ansi('[T]', CYAN, True)} НАЗВАНИЕ СКРИПТА: {ui_title()}",
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ]
    if message:
        out.append(" " + ansi(message, GREEN if message.startswith("✓") else YELLOW, True))
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def custom_theme_menu(term):
    message = ""
    while True:
        render_custom_theme_menu(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()
        if key in ("q", "0"):
            return
        try:
            if key == "1":
                _cycle_setting("accent", ["cyan", "blue", "green", "magenta", "orange", "yellow", "white"])
            elif key == "2":
                _cycle_setting("separator", ["thin", "double", "ascii", "dots"])
            elif key == "3":
                _cycle_setting("max_width", [64, 72, 78, 90, 100, 0])
            elif key == "4":
                _toggle_setting("bold")
            elif key == "5":
                _toggle_setting("compact")
            elif key == "6":
                _toggle_setting("signal_colors")
            elif key == "7":
                _toggle_setting("battery_colors")
            elif key == "8":
                _cycle_setting("battery_green_min", [40, 50, 60, 70, 80])
                if CUSTOM["battery_yellow_min"] >= CUSTOM["battery_green_min"]:
                    CUSTOM["battery_yellow_min"] = max(0, CUSTOM["battery_green_min"] - 10)
                    _save_customization()
            elif key == "9":
                candidates = [10, 15, 20, 25, 30, 35, 40]
                candidates = [x for x in candidates if x < int(CUSTOM.get("battery_green_min", 50))]
                _cycle_setting("battery_yellow_min", candidates or [20])
            elif key == "t":
                changed = _set_text_setting(
                    term, "title", "НАЗВАНИЕ СКРИПТА", ui_title()
                )
                message = "✓ Название сохранено" if changed else "Изменение отменено"
                continue
            else:
                continue
            message = "✓ Сохранено"
        except Exception as e:
            message = "✗ " + str(e).replace("\n", " ")[:150]


def render_custom_main_menu(message=""):
    width = ui_width()
    line = ui_line(width)
    settings = [
        ("1", "BAND В ШАПКЕ", "show_header_band"),
        ("2", "BAT В ШАПКЕ", "show_header_battery"),
        ("3", "CONNECTED В ШАПКЕ", "show_header_connected"),
        ("4", "БЛОК SIGNAL", "show_signal"),
        ("5", "БЛОК CELL", "show_cell"),
        ("6", "БЛОК SPEED", "show_speed"),
        ("7", "UPDATED / ВРЕМЯ", "show_updated"),
    ]
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('ГЛАВНЫЙ ЭКРАН', WHITE, True)}",
        ansi(line, GRAY),
    ]
    for key, label, setting in settings:
        value = bool(CUSTOM.get(setting))
        out.append(
            f" {ansi('[' + key + ']', CYAN, True)} {label}: "
            f"{ansi(ui_on(value), ui_bool_color(value), True)}"
        )
    out.extend([
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ])
    if message:
        out.append(" " + ansi(message, GREEN if message.startswith("✓") else YELLOW, True))
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def custom_main_menu(term):
    mapping = {
        "1": "show_header_band",
        "2": "show_header_battery",
        "3": "show_header_connected",
        "4": "show_signal",
        "5": "show_cell",
        "6": "show_speed",
        "7": "show_updated",
    }
    message = ""
    while True:
        render_custom_main_menu(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()
        if key in ("q", "0"):
            return
        if key in mapping:
            _toggle_setting(mapping[key])
            message = "✓ Сохранено"


def render_custom_devices_menu(message=""):
    width = ui_width()
    line = ui_line(width)
    options = [
        ("1", "ПОКАЗЫВАТЬ IP", "show_device_ip"),
        ("2", "ПОКАЗЫВАТЬ MAC", "show_device_mac"),
        ("3", "ПОКАЗЫВАТЬ TIME", "show_device_time"),
        ("4", "ПОКАЗЫВАТЬ DL / UL", "show_device_speed"),
        ("5", "ПОКАЗЫВАТЬ ЛИМИТ", "show_device_limit"),
    ]
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('УСТРОЙСТВА', WHITE, True)}",
        ansi(line, GRAY),
    ]
    for key, label, setting in options:
        value = bool(CUSTOM.get(setting))
        out.append(
            f" {ansi('[' + key + ']', CYAN, True)} {label}: "
            f"{ansi(ui_on(value), ui_bool_color(value), True)}"
        )
    out.extend([
        f" {ansi('[6]', CYAN, True)} УСТРОЙСТВ НА СТРАНИЦЕ: {CUSTOM.get('device_page_size')}",
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ])
    if message:
        out.append(" " + ansi(message, GREEN if message.startswith("✓") else YELLOW, True))
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def custom_devices_menu(term):
    mapping = {
        "1": "show_device_ip",
        "2": "show_device_mac",
        "3": "show_device_time",
        "4": "show_device_speed",
        "5": "show_device_limit",
    }
    message = ""
    while True:
        render_custom_devices_menu(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()
        if key in ("q", "0"):
            return
        if key in mapping:
            _toggle_setting(mapping[key])
            message = "✓ Сохранено"
        elif key == "6":
            _cycle_setting("device_page_size", [3, 4, 5, 6, 7, 8, 9])
            message = "✓ Сохранено"


def render_custom_sms_monitor_menu(message=""):
    width = ui_width()
    line = ui_line(width)
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('SMS И МОНИТОР', WHITE, True)}",
        ansi(line, GRAY),
        f" {ansi('[1]', CYAN, True)} SMS НА СТРАНИЦЕ: {CUSTOM.get('sms_page_size')}",
        f" {ansi('[2]', CYAN, True)} ИСТОРИЯ PRIORITY: {CUSTOM.get('priority_history_count')} СТРОК",
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ]
    if message:
        out.append(" " + ansi(message, GREEN if message.startswith("✓") else YELLOW, True))
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def custom_sms_monitor_menu(term):
    message = ""
    while True:
        render_custom_sms_monitor_menu(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()
        if key in ("q", "0"):
            return
        if key == "1":
            _cycle_setting("sms_page_size", [3, 4, 5, 6, 7, 8, 9])
            message = "✓ Сохранено"
        elif key == "2":
            _cycle_setting("priority_history_count", [1, 3, 5, 6, 8])
            message = "✓ Сохранено"


def render_custom_refresh_menu(message=""):
    width = ui_width()
    line = ui_line(width)
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('ОБНОВЛЕНИЕ И СКОРОСТЬ', WHITE, True)}",
        ansi(line, GRAY),
        f" {ansi('[1]', CYAN, True)} ГЛАВНЫЙ ЭКРАН: {CUSTOM.get('main_refresh')} с",
        f" {ansi('[2]', CYAN, True)} УСТРОЙСТВА: {CUSTOM.get('device_refresh')} с",
        f" {ansi('[3]', CYAN, True)} SMS BADGE: {CUSTOM.get('sms_badge_refresh')} с",
        f" {ansi('[4]', CYAN, True)} ТОЧНОСТЬ KB/s: {CUSTOM.get('speed_kb_decimals')} знаков",
        f" {ansi('[5]', CYAN, True)} ТОЧНОСТЬ MB/s: {CUSTOM.get('speed_mb_decimals')} знаков",
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ]
    if message:
        out.append(" " + ansi(message, GREEN if message.startswith("✓") else YELLOW, True))
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def custom_refresh_menu(term):
    message = ""
    while True:
        render_custom_refresh_menu(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()
        if key in ("q", "0"):
            return
        if key == "1":
            _cycle_setting("main_refresh", [0.5, 1.0, 1.5, 2.0, 3.0])
        elif key == "2":
            _cycle_setting("device_refresh", [0.5, 1.0, 1.5, 2.0, 3.0])
        elif key == "3":
            _cycle_setting("sms_badge_refresh", [1.0, 3.0, 5.0, 10.0, 15.0])
        elif key == "4":
            _cycle_setting("speed_kb_decimals", [0, 1, 2, 3])
        elif key == "5":
            _cycle_setting("speed_mb_decimals", [0, 1, 2, 3])
        else:
            continue
        message = "✓ Сохранено"


def customization_menu(term):
    message = ""
    reset_confirm_until = 0.0

    while True:
        render_customization_root(message)
        key = term.read_key(0.08)
        if key is None:
            continue
        key = key.lower()

        if key in ("q", "0"):
            return message

        if key == "1":
            custom_theme_menu(term)
            message = ""
            continue
        if key == "2":
            custom_main_menu(term)
            message = ""
            continue
        if key == "3":
            custom_devices_menu(term)
            message = ""
            continue
        if key == "4":
            custom_sms_monitor_menu(term)
            message = ""
            continue
        if key == "5":
            custom_refresh_menu(term)
            message = ""
            continue

        if key == "6":
            now = time.monotonic()
            if now > reset_confirm_until:
                reset_confirm_until = now + 3.0
                message = "Нажми [6] ещё раз в течение 3 секунд для полного сброса"
                continue

            CUSTOM.clear()
            CUSTOM.update(CUSTOM_DEFAULTS)
            _save_customization()
            reset_confirm_until = 0.0
            message = "✓ Все настройки кастомизации сброшены"
            continue


def render_live_screen(info, message="", speed=None, clients=None, sms_count=None, sms_unread=None, priority=None):
    width = ui_width()
    line = ui_line(width)
    now = time.strftime("%H:%M:%S")

    band = info.get("band", "?")
    battery = info.get("battery", "?")

    if clients is None:
        connected = ansi("?", YELLOW, True)
    else:
        connected = ansi(str(clients), GREEN, True)

    header = [ansi(" " + ui_title(), CYAN, True)]
    if CUSTOM.get("show_header_band", True):
        header.append(f"BAND: {ansi(band, WHITE, True)}")
    if CUSTOM.get("show_header_battery", True):
        header.append(
            f"BAT: {ansi(str(battery) + '%' if str(battery) != '?' else '?', battery_color(battery), True)}"
        )
    if CUSTOM.get("show_header_connected", True):
        header.append(f"CONNECTED: {connected}")

    out = []
    out.append(" | ".join(header))
    out.append(ansi(line, GRAY))

    if CUSTOM.get("show_signal", True):
        out.append(ansi(" SIGNAL", CYAN, True))
        out.append(tui_metric("RSRP", "rsrp", info.get("rsrp", "?"), "dBm"))
        out.append(tui_metric("RSRQ", "rsrq", info.get("rsrq", "?"), "dB"))
        out.append(tui_metric("SINR", "sinr", info.get("sinr", "?"), "dB"))
        out.append(tui_metric("RSSI", "rssi", info.get("rssi", "?"), "dBm"))
        if not CUSTOM.get("compact", False):
            out.append("")

    if CUSTOM.get("show_cell", True):
        out.append(ansi(" CELL", CYAN, True))
        left_w = 28

        def two_col(left, right):
            return f" {left:<{left_w}}{right}"

        out.append(two_col(
            f"EARFCN: {info.get('earfcn', '?')}",
            f"PCI: {info.get('pci', '?')}"
        ))
        out.append(two_col(
            f"eNodeB: {info.get('enb', '?')}",
            f"CELL ID: {info.get('cell_id', '?')}"
        ))
        out.append(two_col(
            f"TX: {info.get('txpower', '?')}",
            f"PLMN: {info.get('plmn', '?')}"
        ))
        if not CUSTOM.get("compact", False):
            out.append("")

    if CUSTOM.get("show_speed", True):
        out.append(ansi(" SPEED:", ORANGE, True))

        if speed is None:
            download_mb = "?"
            upload_mb = "?"
        else:
            download_mb = speed.get("download_mb", "?")
            upload_mb = speed.get("upload_mb", "?")

        out.append(
            f" DL: {ansi(str(download_mb), WHITE, True)}"
            f"   UL: {ansi(str(upload_mb), WHITE, True)}"
        )

    out.append(ansi(line, GRAY))

    current_band = str(info.get("band", "?")).upper().lstrip("B")

    def direct_band_key(key_name, band_num):
        color = GREEN if current_band == str(band_num) else CYAN
        return f" {ansi('[' + key_name + ']', color, True)} BAND {band_num}"

    out.append(direct_band_key("1", 1))
    out.append(direct_band_key("2", 3))
    out.append(direct_band_key("3", 20))
    out.append(f" {ansi('[4]', CYAN, True)} AUTO BAND")
    out.append(f" {ansi('[B]', CYAN, True)} ВСЕ БЕНДЫ")
    out.append(f" {ansi('[D]', CYAN, True)} УСТРОЙСТВА")

    priority = priority or {}
    priority_enabled = bool(priority.get("enabled"))
    priority_color = GREEN if priority_enabled else RED
    priority_text = "ВКЛ" if priority_enabled else "ВЫКЛ"
    cap = priority.get("cap_kb")
    if priority_enabled and cap is not None:
        priority_text += f" [{format_limit_label(cap)}]"
    elif priority_enabled:
        priority_text += " [AUTO]"
    out.append(
        f" {ansi('[P]', priority_color, True)} ПРИОРИТЕТ ХОЗЯИНА: "
        f"{ansi(priority_text, priority_color, True)}"
    )
    out.append(f" {ansi('[O]', CYAN, True)} МОНИТОР ПРИОРИТЕТА")

    if sms_count is None:
        sms_count_text = "?"
    else:
        sms_count_text = str(max(0, int(sms_count)))

    sms_menu_line = (
        f" {ansi('[M]', MAGENTA, True)} SMS "
        f"{ansi('[' + sms_count_text + ']', WHITE, True)}"
    )
    if sms_unread is not None and int(sms_unread) > 0:
        sms_menu_line += " " + ansi("[NEW]", YELLOW, True)
    out.append(sms_menu_line)

    ppp_status = str(info.get("ppp_status", "") or "").strip().lower()
    if ppp_status == "ppp_connected":
        network_label = "ВКЛ"
        network_color = GREEN
    elif ppp_status in ("ppp_connecting", "connecting", "ppp_disconnecting", "disconnecting"):
        network_label = "..."
        network_color = YELLOW
    elif ppp_status:
        network_label = "ВЫКЛ"
        network_color = RED
    else:
        network_label = "?"
        network_color = YELLOW

    out.append(f" {ansi('[C]', CYAN, True)} ПЕРЕПОДКЛЮЧИТЬ СЕТЬ")
    out.append(
        f" {ansi('[N]', network_color, True)} СЕТЬ: "
        f"{ansi(network_label, network_color, True)}"
    )
    out.append(f" {ansi('[K]', CYAN, True)} КАСТОМИЗАЦИЯ")
    out.append(f" {ansi('[X]', YELLOW, True)} РЕСТАРТ СКРИПТА")
    out.append(f" {ansi('[R]', CYAN, True)} ОБНОВИТЬ")
    out.append(f" {ansi('[Q]', RED, True)} ВЫХОД")
    out.append(ansi(line, GRAY))

    if message:
        if message.startswith("✓"):
            out.append(" " + ansi(message, GREEN, True))
        elif message.startswith("✗"):
            out.append(" " + ansi(message, RED, True))
        else:
            out.append(" " + ansi(message, YELLOW, True))
    elif CUSTOM.get("show_updated", True):
        out.append(f" UPDATED: {now}")

    # Home + clear below, без постоянной прокрутки терминала.
    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def render_bands_menu(current_band, message=""):
    width = ui_width()
    line = ui_line(width)

    current = str(current_band or "").upper().lstrip("B")

    mapping = [
        ("1", 1),
        ("2", 3),
        ("3", 7),
        ("4", 8),
        ("5", 20),
        ("6", 28),
        ("7", 38),
        ("8", 40),
        ("9", 41),
    ]

    def band_key(key, band):
        color = GREEN if current == str(band) else CYAN
        return f" {ansi('[' + key + ']', color, True)} B{band}"

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi('БЕНДЫ', WHITE, True)}",
        ansi(line, GRAY),
    ]

    for key, band in mapping:
        out.append(band_key(key, band))

    out.extend([
        ansi(line, GRAY),
        f" {ansi('[Q]', RED, True)} НАЗАД",
        ansi(line, GRAY),
    ])

    if message:
        if message.startswith("✓"):
            color = GREEN
        elif message.startswith("✗"):
            color = RED
        else:
            color = YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(f" UPDATED: {time.strftime('%H:%M:%S')}")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def sms_preview(text, width):
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not text:
        return "(пустое сообщение)"
    return textwrap.shorten(text, width=max(12, width), placeholder="…")


def render_sms_list(messages, page=0, message=""):
    width = ui_width()
    line = ui_line(width)
    per_page = int(CUSTOM.get("sms_page_size", 5))
    pages = max(1, (len(messages) + per_page - 1) // per_page)
    page = max(0, min(page, pages - 1))
    start = page * per_page
    visible = messages[start:start + per_page]

    unread = sum(1 for m in messages if str(m.get("tag")) == "1")
    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | "
        f"{ansi('SMS', WHITE, True)} | "
        f"ВСЕ: {ansi(str(len(messages)), WHITE, True)} | "
        f"НОВЫЕ: {ansi(str(unread), YELLOW if unread else GREEN, True)}",
        ansi(line, GRAY),
    ]

    if not visible:
        out.append(" SMS не найдены.")
    else:
        for local_idx, sms in enumerate(visible, 1):
            is_new = str(sms.get("tag")) == "1"
            status = "NEW" if is_new else "   "
            status_color = YELLOW if is_new else GRAY
            sender = sms.get("number", "?")
            sms_id = sms.get("id", "?")
            out.append(
                f" {ansi('[' + str(local_idx) + ']', CYAN, True)} "
                f"{ansi(status, status_color, True)}  "
                f"#{sms_id}  {ansi(sender, WHITE, True)}"
            )
            preview_width = max(18, width - 7)
            out.append(
                f"     {sms_preview(sms.get('content', ''), preview_width)}"
            )

    out.append(ansi(line, GRAY))
    out.append(
        f" СТРАНИЦА: {page + 1}/{pages}   "
        f"{ansi('[1-' + str(min(9, per_page)) + ']', CYAN, True)} ОТКРЫТЬ"
    )
    nav = []
    if page > 0:
        nav.append(f"{ansi('[P]', CYAN, True)} НАЗАД")
    if page < pages - 1:
        nav.append(f"{ansi('[N]', CYAN, True)} ДАЛЕЕ")
    nav.append(f"{ansi('[R]', CYAN, True)} ОБНОВИТЬ")
    if messages:
        nav.append(f"{ansi('[D]', RED, True)} УДАЛИТЬ ВСЕ")
    nav.append(f"{ansi('[Q]', RED, True)} В МЕНЮ")
    out.append(" " + "   ".join(nav))
    out.append(ansi(line, GRAY))

    if message:
        if message.startswith("✓"):
            color = GREEN
        elif message.startswith("✗"):
            color = RED
        else:
            color = YELLOW
        out.append(" " + ansi(message, color, True))
    else:
        out.append(f" UPDATED: {time.strftime('%H:%M:%S')}")

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()
    return page


def render_sms_detail(sms, message=""):
    width = ui_width()
    line = ui_line(width)

    tag = str(sms.get("tag", ""))
    status_color = YELLOW if tag == "1" else GREEN
    body = str(sms.get("content", "") or "(пустое сообщение)")
    wrapped = textwrap.wrap(
        body,
        width=max(20, width - 3),
        replace_whitespace=True,
        drop_whitespace=True,
    ) or ["(пустое сообщение)"]

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | "
        f"{ansi('SMS #' + str(sms.get('id', '?')), WHITE, True)}",
        ansi(line, GRAY),
        f" ОТ:      {ansi(str(sms.get('number', '?')), WHITE, True)}",
        f" ДАТА:    {sms.get('date', '?')}",
        f" СТАТУС:  {ansi(str(sms.get('status', '?')), status_color, True)}",
        ansi(line, GRAY),
    ]

    for row in wrapped:
        out.append(" " + row)

    out.extend([
        ansi(line, GRAY),
        f" {ansi('[D]', RED, True)} УДАЛИТЬ   "
        f"{ansi('[Q]', CYAN, True)} НАЗАД",
        ansi(line, GRAY),
    ])

    if message:
        if message.startswith("✓"):
            color = GREEN
        elif message.startswith("✗"):
            color = RED
        else:
            color = YELLOW
        out.append(" " + ansi(message, color, True))

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def sms_detail_menu(term, sms, initial_message=""):
    message = initial_message

    while True:
        render_sms_detail(sms, message)
        key = term.read_key(0.08)
        if key is None:
            continue

        key = key.lower()
        if key in ("q", "0"):
            return False, ""

        if key != "d":
            continue

        confirm = f"Удалить SMS #{sms.get('id', '?')}? [Y] ДА  [N] НЕТ"
        render_sms_detail(sms, confirm)

        while True:
            answer = term.read_key(0.08)
            if answer is None:
                continue
            answer = answer.lower()
            if answer in ("n", "q", "0"):
                message = "Удаление отменено."
                break
            if answer != "y":
                continue

            try:
                delete_sms(sms.get("id", ""))
                return True, f"✓ SMS #{sms.get('id', '?')} удалено"
            except Exception as e:
                message = "✗ " + str(e).replace("\n", " ")[:160]
                break


def sms_menu(term):
    messages = []
    page = 0
    message = "Загрузка SMS…"

    def refresh():
        nonlocal messages, page, message
        try:
            messages = fetch_sms(mem_store=1, timeout=5)
            pages = max(1, (len(messages) + int(CUSTOM.get('sms_page_size', 5)) - 1) // int(CUSTOM.get('sms_page_size', 5)))
            page = min(page, pages - 1)
            message = ""
        except Exception as e:
            messages = []
            page = 0
            message = "✗ " + str(e).replace("\n", " ")[:160]

    refresh()

    while True:
        page = render_sms_list(messages, page, message)
        key = term.read_key(0.08)
        if key is None:
            continue

        key = key.lower()

        if key in ("q", "0"):
            return None

        if key == "r":
            message = "Обновление SMS…"
            render_sms_list(messages, page, message)
            refresh()
            continue

        if key == "d":
            if not messages:
                message = "SMS для удаления нет."
                continue

            total = len(messages)
            confirm = (
                f"Удалить ВСЕ SMS ({total})? "
                f"[Y] ДА  [N] НЕТ"
            )
            render_sms_list(messages, page, confirm)

            while True:
                answer = term.read_key(0.08)
                if answer is None:
                    continue

                answer = answer.lower()
                if answer in ("n", "q", "0"):
                    message = "Удаление всех SMS отменено."
                    break

                if answer != "y":
                    continue

                render_sms_list(
                    messages,
                    page,
                    f"Удаление всех SMS… 0/{total}"
                )

                deleted, failed = delete_all_sms(messages)

                # Сразу перечитываем роутер, чтобы список и badge обновились.
                time.sleep(0.2)
                refresh()

                if failed:
                    message = (
                        f"✗ Удалено: {deleted}/{total}; "
                        f"ошибка для ID: {', '.join(failed[:6])}"
                    )
                    if len(failed) > 6:
                        message += f" +{len(failed) - 6}"
                else:
                    message = f"✓ Удалены все SMS: {deleted}"

                break

            continue

        pages = max(1, (len(messages) + int(CUSTOM.get('sms_page_size', 5)) - 1) // int(CUSTOM.get('sms_page_size', 5)))
        if key == "n" and page < pages - 1:
            page += 1
            message = ""
            continue
        if key == "p" and page > 0:
            page -= 1
            message = ""
            continue

        if key not in tuple(str(i) for i in range(1, int(CUSTOM.get("sms_page_size", 5)) + 1)):
            continue

        local_idx = int(key) - 1
        absolute_idx = page * int(CUSTOM.get('sms_page_size', 5)) + local_idx
        if absolute_idx >= len(messages):
            continue

        selected_sms = messages[absolute_idx]
        was_unread = str(selected_sms.get("tag")) == "1"
        read_message = ""

        # Сам факт открытия карточки = прочтение. Помечаем SMS прочитанным
        # в самом роутере, чтобы статус переживал перезапуск скрипта/WebUI.
        if was_unread:
            try:
                mark_sms_read(selected_sms.get("id", ""))
                selected_sms["tag"] = "0"
                selected_sms["status"] = sms_status("0")
            except Exception as e:
                read_message = "✗ Не удалось отметить прочитанным: " + str(e).replace("\n", " ")[:110]

        deleted, detail_message = sms_detail_menu(
            term, selected_sms, initial_message=read_message
        )
        message = detail_message

        if deleted or was_unread:
            # После удаления или прочтения сразу перечитываем список,
            # чтобы NEW и счётчики изменились без задержки.
            time.sleep(0.2)
            refresh()
            if detail_message:
                message = detail_message


def render_action_screen(title, status_lines, message=""):
    width = ui_width()
    line = ui_line(width)

    out = [
        f"{ansi(' ' + ui_title(), CYAN, True)} | {ansi(title, WHITE, True)}",
        ansi(line, GRAY),
    ]

    for label, value, color in status_lines:
        out.append(
            f" {label:<18} {ansi(value, color, True)}"
        )

    out.append(ansi(line, GRAY))

    if message:
        if message.startswith("✓"):
            color = GREEN
        elif message.startswith("✗"):
            color = RED
        else:
            color = YELLOW
        out.append(" " + ansi(message, color, True))

    sys.stdout.write("\033[H\033[J" + "\n".join(out) + "\n")
    sys.stdout.flush()


def check_auth():
    try:
        return http_get("loginfo", timeout=2).get("loginfo") == "ok"
    except Exception:
        return False


def set_band_and_reboot(band):
    if band not in SUPPORTED_BANDS:
        raise RuntimeError(f"B{band} не поддерживается этим профилем.")

    ensure_auth()

    data = {
        "goformId": "SET_LOCK_LTE_BAND_MODE",
    }

    for b in ALL_API_BANDS:
        data[f"band{b}"] = "1" if b == band else "0"

    render_action_screen(
        f"BAND LOCK B{band}",
        [
            ("НАСТРОЙКА", f"B{band}", CYAN),
            ("ЗАПИСЬ", "ОТПРАВКА", YELLOW),
            ("ПРИМЕНЕНИЕ", "ОЖИДАНИЕ", GRAY),
            ("REBOOT", "ОЖИДАНИЕ", GRAY),
        ]
    )

    result = http_post(data, timeout=5)
    if result.get("result") != "success":
        raise RuntimeError(f"SET_LOCK_LTE_BAND_MODE: {result}")

    # Штатный WebUI опрашивает LteBandLockSet раз в 2 секунды.
    lock_state = ""
    for i in range(15):
        render_action_screen(
            f"BAND LOCK B{band}",
            [
                ("НАСТРОЙКА", f"B{band}", CYAN),
                ("ЗАПИСЬ", "SUCCESS", GREEN),
                ("ПРИМЕНЕНИЕ", lock_state or "WAITING", YELLOW),
                ("REBOOT", "ОЖИДАНИЕ", GRAY),
            ],
            f"Проверка {i + 1}/15"
        )

        time.sleep(2)

        try:
            lock_state = http_get(
                "LteBandLockSet",
                timeout=3
            ).get("LteBandLockSet", "")
        except Exception:
            lock_state = ""

        if lock_state == "LockBandSuc":
            break

        if lock_state == "LockBandFail":
            raise RuntimeError("Роутер вернул LockBandFail.")

    if lock_state != "LockBandSuc":
        raise RuntimeError(
            "LockBandSuc не получен. Перезагрузка отменена."
        )

    render_action_screen(
        f"BAND LOCK B{band}",
        [
            ("НАСТРОЙКА", f"B{band}", CYAN),
            ("ЗАПИСЬ", "SUCCESS", GREEN),
            ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
            ("REBOOT", "ЗАПУСК", YELLOW),
        ],
        "Перезагружаю AX8 Pro…"
    )

    try:
        result = http_post({"goformId": "REBOOT_DEVICE"}, timeout=5)
        if result.get("result") not in ("success", None):
            raise RuntimeError(f"REBOOT_DEVICE: {result}")
    except (urllib.error.URLError, TimeoutError):
        # Во время штатного reboot HTTP может оборваться раньше ответа.
        pass

    # Сначала ждём, чтобы устройство действительно ушло.
    went_offline = False
    for i in range(15):
        try:
            http_get("nv_band", timeout=1.2)
            online = True
        except Exception:
            online = False

        render_action_screen(
            f"BAND LOCK B{band}",
            [
                ("НАСТРОЙКА", f"B{band}", CYAN),
                ("ЗАПИСЬ", "SUCCESS", GREEN),
                ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
                ("REBOOT", "OFFLINE" if not online else "WAITING", YELLOW),
            ],
            "Ожидание отключения роутера…"
        )

        if not online:
            went_offline = True
            break

        time.sleep(1)

    # Ждём возвращения роутера и нового LTE band.
    last_band = "?"
    last_ppp = "?"

    for i in range(120):
        try:
            state = http_get(
                "ppp_status,nv_band,nv_arfcn,nv_pci",
                timeout=1.5
            )

            last_band = state.get("nv_band", "") or "?"
            last_ppp = state.get("ppp_status", "") or "?"

            band_ok = str(last_band) == str(band)
            ppp_ok = last_ppp == "ppp_connected"

            render_action_screen(
                f"BAND LOCK B{band}",
                [
                    ("НАСТРОЙКА", f"B{band}", CYAN),
                    ("ЗАПИСЬ", "SUCCESS", GREEN),
                    ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
                    ("ROUTER", "ONLINE", GREEN),
                    ("BAND", f"B{last_band}", GREEN if band_ok else YELLOW),
                    ("LTE", last_ppp, GREEN if ppp_ok else YELLOW),
                ],
                f"Ожидание сети… {i + 1}/120"
            )

            if band_ok and ppp_ok:
                time.sleep(1.2)
                # REBOOT сбрасывает WebUI-сессию. Восстанавливаем её сразу,
                # чтобы следующая команда не требовала браузера.
                try:
                    ensure_auth(force=True)
                except Exception:
                    # Не считаем смену Band неуспешной только из-за того,
                    # что WebUI ещё несколько секунд не готов к LOGIN.
                    pass
                return

        except Exception:
            render_action_screen(
                f"BAND LOCK B{band}",
                [
                    ("НАСТРОЙКА", f"B{band}", CYAN),
                    ("ЗАПИСЬ", "SUCCESS", GREEN),
                    ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
                    ("ROUTER", "OFFLINE", RED),
                    ("BAND", "?", GRAY),
                    ("LTE", "?", GRAY),
                ],
                f"Ожидание AX8 Pro… {i + 1}/120"
            )

        time.sleep(1)

    raise RuntimeError(
        f"За 120 секунд B{band} не подтверждён "
        f"(последнее: BAND={last_band}, PPP={last_ppp})."
    )



def set_auto_band_and_reboot():
    """
    AUTO BAND для AX8 Pro.

    Используется тот же штатный SET_LOCK_LTE_BAND_MODE, что и для ручного B1/B3/B20,
    но разрешаются все bands из SUPPORTED_BANDS. Остальные generic API-флаги
    оставляются 0, чтобы не включать bands, которых нет в профиле устройства.

    После reboot не ждём конкретный band: модем сам выбирает доступный.
    """
    ensure_auth()

    allowed = set(SUPPORTED_BANDS)
    data = {
        "goformId": "SET_LOCK_LTE_BAND_MODE",
    }
    for b in ALL_API_BANDS:
        data[f"band{b}"] = "1" if b in allowed else "0"

    auto_list = "/".join(f"B{b}" for b in SUPPORTED_BANDS)

    render_action_screen(
        "AUTO BAND",
        [
            ("РЕЖИМ", "AUTO", CYAN),
            ("РАЗРЕШЕНО", auto_list, CYAN),
            ("ЗАПИСЬ", "ОТПРАВКА", YELLOW),
            ("ПРИМЕНЕНИЕ", "ОЖИДАНИЕ", GRAY),
            ("REBOOT", "ОЖИДАНИЕ", GRAY),
        ]
    )

    result = http_post(data, timeout=5)
    if result.get("result") != "success":
        raise RuntimeError(f"SET_LOCK_LTE_BAND_MODE: {result}")

    lock_state = ""
    for i in range(15):
        render_action_screen(
            "AUTO BAND",
            [
                ("РЕЖИМ", "AUTO", CYAN),
                ("ЗАПИСЬ", "SUCCESS", GREEN),
                ("ПРИМЕНЕНИЕ", lock_state or "WAITING", YELLOW),
                ("REBOOT", "ОЖИДАНИЕ", GRAY),
            ],
            f"Проверка {i + 1}/15"
        )

        time.sleep(2)

        try:
            lock_state = http_get(
                "LteBandLockSet",
                timeout=3
            ).get("LteBandLockSet", "")
        except Exception:
            lock_state = ""

        if lock_state == "LockBandSuc":
            break

        if lock_state == "LockBandFail":
            raise RuntimeError("Роутер вернул LockBandFail.")

    if lock_state != "LockBandSuc":
        raise RuntimeError(
            "LockBandSuc не получен. Перезагрузка отменена."
        )

    render_action_screen(
        "AUTO BAND",
        [
            ("РЕЖИМ", "AUTO", CYAN),
            ("ЗАПИСЬ", "SUCCESS", GREEN),
            ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
            ("REBOOT", "ЗАПУСК", YELLOW),
        ],
        "Перезагружаю AX8 Pro…"
    )

    try:
        result = http_post({"goformId": "REBOOT_DEVICE"}, timeout=5)
        if result.get("result") not in ("success", None):
            raise RuntimeError(f"REBOOT_DEVICE: {result}")
    except (urllib.error.URLError, TimeoutError):
        pass

    # Ждём, пока роутер уйдёт в reboot.
    for _ in range(15):
        try:
            http_get("nv_band", timeout=1.2)
            online = True
        except Exception:
            online = False

        render_action_screen(
            "AUTO BAND",
            [
                ("РЕЖИМ", "AUTO", CYAN),
                ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
                ("REBOOT", "OFFLINE" if not online else "WAITING", YELLOW),
            ],
            "Ожидание отключения роутера…"
        )

        if not online:
            break
        time.sleep(1)

    # В AUTO конкретный band заранее неизвестен.
    last_band = "?"
    last_ppp = "?"

    for i in range(120):
        try:
            state = http_get(
                "ppp_status,nv_band,nv_arfcn,nv_pci",
                timeout=1.5
            )

            last_band = state.get("nv_band", "") or "?"
            last_ppp = state.get("ppp_status", "") or "?"
            ppp_ok = last_ppp == "ppp_connected"
            band_ok = str(last_band).strip() not in ("", "?")

            render_action_screen(
                "AUTO BAND",
                [
                    ("РЕЖИМ", "AUTO", CYAN),
                    ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
                    ("ROUTER", "ONLINE", GREEN),
                    ("BAND", f"B{last_band}", GREEN if band_ok else YELLOW),
                    ("LTE", last_ppp, GREEN if ppp_ok else YELLOW),
                ],
                f"Автовыбор сети… {i + 1}/120"
            )

            if band_ok and ppp_ok:
                time.sleep(1.2)
                try:
                    ensure_auth(force=True)
                except Exception:
                    pass
                return str(last_band)

        except Exception:
            render_action_screen(
                "AUTO BAND",
                [
                    ("РЕЖИМ", "AUTO", CYAN),
                    ("ПРИМЕНЕНИЕ", "LockBandSuc", GREEN),
                    ("ROUTER", "OFFLINE", RED),
                    ("BAND", "?", GRAY),
                    ("LTE", "?", GRAY),
                ],
                f"Ожидание роутера… {i + 1}/120"
            )

        time.sleep(1)

    raise RuntimeError(
        "За 120 секунд AUTO BAND не вышел в сеть "
        f"(последнее: BAND={last_band}, PPP={last_ppp})."
    )


def bands_menu(term, current_info):
    choices = {
        "1": 1,
        "2": 3,
        "3": 7,
        "4": 8,
        "5": 20,
        "6": 28,
        "7": 38,
        "8": 40,
        "9": 41,
    }

    message = ""
    current_band = str(
        current_info.get("band", "?")
    ).upper().lstrip("B")

    while True:
        render_bands_menu(current_band, message)
        key = term.read_key(0.08)

        if key is None:
            continue

        key = key.lower()

        if key in ("q", "0"):
            return None

        band = choices.get(key)
        if band is None:
            continue

        try:
            set_band_and_reboot(band)
            return f"✓ Установлен B{band}"
        except Exception as e:
            message = "✗ " + str(e).replace("\n", " ")[:120]


def main():
    info = normalized_info({})
    message = "Подключение к роутеру…"
    term = RawTerminal()

    last_refresh = 0.0
    next_refresh = 0.0
    speed_tracker = SpeedTracker()
    speed = {
        "download_mb": "0 B/s",
        "upload_mb": "0 B/s",
    }
    clients = None
    next_clients_refresh = 0.0
    next_auth_attempt = 0.0

    # Per-device traffic monitor stays alive for the whole script session.
    # On this AX8 Pro some established/accelerated flows may not start hitting
    # a newly inserted accounting chain. Keeping AX8_MON active continuously
    # makes later traffic visible before [D] УСТРОЙСТВА is opened.
    device_traffic_tracker = DeviceTrafficTracker()
    device_traffic_snapshot = []
    next_device_traffic_refresh = 0.0
    last_qos_signature = None

    owner_priority = OwnerPriorityController()

    # [P] is a persistent user preference. AUTO caps themselves are temporary.
    priority_should_restore = _load_priority_enabled()
    if priority_should_restore:
        owner_priority.enable([], persist=False)

    # Badge SMS в главном меню. None = ещё не удалось получить данные.
    sms_count = None
    sms_unread = None
    next_sms_refresh = 0.0

    def refresh_radio(force=False):
        nonlocal info, message, last_refresh, next_refresh, speed
        nonlocal clients, next_clients_refresh, next_auth_attempt
        nonlocal device_traffic_snapshot, next_device_traffic_refresh
        nonlocal last_qos_signature

        now = time.monotonic()
        if not force and now < next_refresh:
            return

        try:
            raw = http_get(RADIO_CMD, timeout=3)
            info = normalized_info(raw)
            speed = speed_tracker.update(raw)

            now2 = time.monotonic()

            # Если WebUI-сессия пропала/истекла, восстанавливаем её сами.
            # Backoff не даёт долбить LOGIN каждую секунду, пока роутер
            # загружается после reboot или временно недоступен.
            if not info.get("authorized") and now2 >= next_auth_attempt:
                try:
                    ensure_auth(force=True)
                    info["authorized"] = True
                    if message.startswith("✗ Авторизация"):
                        message = ""
                    next_auth_attempt = now2 + 30.0
                except Exception:
                    next_auth_attempt = now2 + 10.0

            if force or now2 >= next_clients_refresh:
                try:
                    clients = fetch_connected_clients(raw)
                except Exception:
                    pass
                next_clients_refresh = now2 + 2.0

            # Keep per-device iptables accounting active even while the user is
            # on the main screen. This prevents an already-active client flow
            # from appearing as 0 B/s only because [D] was opened later.
            if force or now2 >= next_device_traffic_refresh:
                try:
                    device_traffic_snapshot = fetch_connected_devices(timeout=1.5)
                    device_traffic_tracker.update(device_traffic_snapshot)
                    owner_priority.update(
                        device_traffic_snapshot,
                        device_traffic_tracker,
                    )

                    # Keep tc/ip(6)tables rules synchronized with changing
                    # IPv4/IPv6 addresses even outside [D] УСТРОЙСТВА.
                    qos_signature = _effective_qos_signature(device_traffic_snapshot)
                    if qos_signature != last_qos_signature:
                        if qos_signature or _load_limits() or PRIORITY_LIMIT_OVERRIDES:
                            _apply_tc_limits(device_traffic_snapshot)
                        last_qos_signature = qos_signature
                except Exception:
                    # Per-device accounting/priority must never break the main radio UI.
                    pass
                next_device_traffic_refresh = now2 + float(CUSTOM.get("device_refresh", 1.0))

            # Служебные сообщения исчезают после успешного обновления.
            if (
                message.startswith("✗ Нет связи")
                or message == "Подключение к роутеру…"
            ):
                message = ""

        except Exception:
            message = "✗ Нет связи с 192.168.150.1"

        last_refresh = time.monotonic()
        next_refresh = last_refresh + float(CUSTOM.get("main_refresh", 1.0))

    def refresh_sms_badge(force=False):
        nonlocal sms_count, sms_unread, next_sms_refresh

        now_m = time.monotonic()
        if not force and now_m < next_sms_refresh:
            return

        try:
            rows = fetch_sms(mem_store=1, timeout=3)
            sms_count = len(rows)
            sms_unread = sum(
                1 for row in rows if str(row.get("tag")) == "1"
            )
        except Exception:
            # Счётчик вторичен: при кратковременной ошибке сохраняем
            # последнее успешное значение, не ломая главный мониторинг.
            pass

        next_sms_refresh = time.monotonic() + float(CUSTOM.get("sms_badge_refresh", 3.0))

    try:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
        term.enable()

        # Автовход при каждом запуске скрипта. Если роутер ещё не готов,
        # основной цикл продолжит работу и сам повторит вход с backoff.
        try:
            ensure_auth(force=True)
            message = ""

            # If an earlier process was killed while [P] was active, tc rules can
            # outlive the script. Rebuild from persistent manual limits once.
            try:
                startup_devices = fetch_connected_devices(timeout=2.0)

                # Always remove any stale temporary priority caps left by a
                # previous killed/restarted process, then restore manual limits.
                _apply_tc_limits(startup_devices)

                # If [P] was ON before restart/exit, reactivate the controller.
                # No temporary cap is restored blindly; AUTO recalculates it
                # from fresh traffic after the first samples arrive.
                if priority_should_restore:
                    owner_priority.enable(startup_devices, persist=False)
            except Exception:
                pass
        except Exception:
            message = "Подключение к роутеру…"

        while True:
            refresh_radio()
            refresh_sms_badge()
            render_live_screen(
                info, message, speed=speed, clients=clients,
                sms_count=sms_count, sms_unread=sms_unread,
                priority=owner_priority.status(),
            )

            key = term.read_key(0.08)
            if key is None:
                continue

            key = key.lower()

            if key in ("q", "0"):
                break

            if key == "r":
                message = "Обновление…"
                render_live_screen(
                    info, message, speed=speed, clients=clients,
                    sms_count=sms_count, sms_unread=sms_unread,
                    priority=owner_priority.status(),
                )
                refresh_radio(force=True)
                refresh_sms_badge(force=True)
                message = ""
                continue

            if key == "k":
                message = customization_menu(term) or ""
                next_refresh = 0.0
                next_device_traffic_refresh = 0.0
                next_clients_refresh = 0.0
                next_sms_refresh = 0.0
                continue

            if key == "p":
                try:
                    if owner_priority.enabled:
                        message = owner_priority.disable(
                            device_traffic_snapshot or None
                        )
                    else:
                        if not device_traffic_snapshot:
                            device_traffic_snapshot = fetch_connected_devices(timeout=2.0)
                            device_traffic_tracker.update(device_traffic_snapshot)
                        owner_priority.enable(device_traffic_snapshot)
                        if owner_priority.owner_mac:
                            owner = owner_priority.owner_name or owner_priority.owner_mac
                            message = f"✓ Приоритет хозяина включен: {owner}"
                        else:
                            message = "✓ Приоритет включен, определяю устройство хозяина…"
                except Exception as e:
                    message = "✗ " + str(e).replace("\n", " ")[:160]
                next_refresh = 0.0
                next_device_traffic_refresh = 0.0
                continue

            if key == "o":
                message = owner_priority_monitor_menu(
                    term,
                    owner_priority,
                    device_traffic_tracker,
                ) or ""
                next_refresh = 0.0
                next_device_traffic_refresh = 0.0
                next_clients_refresh = 0.0
                continue

            if key == "d":
                devices_menu(term, traffic_tracker=device_traffic_tracker)
                next_refresh = 0.0
                next_device_traffic_refresh = 0.0
                next_clients_refresh = 0.0
                message = ""
                continue

            if key == "m":
                sms_menu(term)
                next_refresh = 0.0
                next_sms_refresh = 0.0
                # Сразу обновит [N] и [NEW] после прочтения/удаления.
                refresh_sms_badge(force=True)
                message = ""
                continue

            if key == "c":
                try:
                    message = reconnect_network()
                except Exception as e:
                    message = "✗ " + str(e).replace("\n", " ")[:140]
                speed_tracker.reset()
                next_refresh = 0.0
                continue

            if key == "n":
                # Текущее состояние берём из последнего ppp_status.
                # Если сеть подключена, выключаем; иначе включаем.
                enable = not bool(info.get("internet_connected"))
                try:
                    message = set_network_enabled(enable)
                except Exception as e:
                    message = "✗ " + str(e).replace("\n", " ")[:140]
                speed_tracker.reset()
                next_refresh = 0.0
                continue

            if key == "x":
                if owner_priority.enabled or PRIORITY_LIMIT_OVERRIDES:
                    try:
                        owner_priority.disable(
                            device_traffic_snapshot or None,
                            persist=False,
                        )
                    except Exception:
                        pass

                term.disable()
                sys.stdout.write("\033[2J\033[H")
                sys.stdout.flush()

                script_path = str(Path(__file__).resolve())
                os.execv(
                    sys.executable,
                    [sys.executable, script_path] + sys.argv[1:]
                )

            if key in ("1", "2", "3"):
                direct_bands = {
                    "1": 1,
                    "2": 3,
                    "3": 20,
                }
                band = direct_bands[key]

                try:
                    set_band_and_reboot(band)
                    message = f"✓ Установлен B{band}"
                except Exception as e:
                    message = "✗ " + str(e).replace("\n", " ")[:120]

                speed_tracker.reset()
                next_refresh = 0.0
                continue

            if key == "4":
                try:
                    selected_band = set_auto_band_and_reboot()
                    message = f"✓ AUTO BAND активен, выбран B{selected_band}"
                except Exception as e:
                    message = "✗ " + str(e).replace("\n", " ")[:140]

                speed_tracker.reset()
                next_refresh = 0.0
                continue

            if key == "b":
                result_message = bands_menu(term, info)
                speed_tracker.reset()
                next_refresh = 0.0
                message = result_message or ""
                continue

    finally:
        try:
            if owner_priority.enabled or PRIORITY_LIMIT_OVERRIDES:
                owner_priority.disable(
                    device_traffic_snapshot or None,
                    persist=False,
                )
        except Exception:
            pass
        try:
            device_traffic_tracker.close()
        except Exception:
            pass
        try:
            _ROUTER_SHELL.close()
        except Exception:
            pass
        term.disable()
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nВыход.")
