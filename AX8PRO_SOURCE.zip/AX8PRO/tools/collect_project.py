#!/usr/bin/env python3
"""XARKON AX8 Android project collector: make ZIP, then open its directory."""
import os
import sys
import subprocess
import zipfile
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
SKIP_DIRS={"dist", ".gradle", ".git", "build", ".idea", "__pycache__"}

def main():
    DIST.mkdir(exist_ok=True)
    target=DIST / f"XARKON_AX8_Control_SOURCES_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    with zipfile.ZipFile(target,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for file in ROOT.rglob("*"):
            if not file.is_file() or any(part in SKIP_DIRS for part in file.relative_to(ROOT).parts):
                continue
            z.write(file, arcname=f"XARKON_AX8_Control/{file.relative_to(ROOT).as_posix()}")
    print(f"Готово: {target} ({target.stat().st_size:,} байт)")
    try:
        if sys.platform == "win32": os.startfile(str(DIST))
        elif os.environ.get("PREFIX","").startswith("/data/data/com.termux"):
            subprocess.Popen(["termux-open", str(DIST)])
        elif sys.platform == "darwin": subprocess.Popen(["open",str(DIST)])
        else: subprocess.Popen(["xdg-open",str(DIST)])
    except Exception as e:
        print("Не удалось автоматически открыть папку; путь указан выше:",e)

if __name__ == "__main__": main()
